---
title: "Equivalence Partitioning Method"
source: "https://www.geeksforgeeks.org/software-engineering/equivalence-partitioning-method/"
author:
  - "[[GeeksforGeeks]]"
published: 2020-08-17
created: 2026-09-23
description: "Your All-in-One Learning Portal: GeeksforGeeks is a comprehensive educational platform that empowers learners across domains-spanning computer science and programming, school education, upskilling, commerce, software tools, competitive exams, and more."
tags:
  - "clippings"
---
Equivalence Partitioning (EP) is a [black-box testing](https://www.geeksforgeeks.org/software-testing/software-engineering-black-box-testing/) technique that divides input data into valid and invalid partitions. It helps reduce the number of test cases while ensuring effective test coverage.

- Divides input data into partitions, where each partition represents similar behavior
- Selects one representative value from each partition for testing
- Reduces test cases while maintaining good coverage
![[input_set.webp|input_set]]

Input-set

### Guidelines for EP

The way equivalence classes are defined depends on the type of input. Each input type has corresponding valid and invalid partitions.

| Input Type | Valid Class | Invalid Class(s) |
| --- | --- | --- |
| Range Input | Values within the range | Values below or above the range |
| Specific Value | Exact valid value | Values less than or greater than the valid value |
| Set of Values | Values in the set | Values not in the set |
| Boolean Input | Expected value (true/false) | Unexpected value |

## Steps of Equivalence Partitioning

Equivalence Partitioning is applied by dividing inputs into logical groups and selecting representative values. Following a structured approach helps ensure effective and efficient testing.

- ****Identify input fields****: Determine all input variables that need to be tested.
- ****Define input ranges or conditions****: Understand valid and invalid conditions for each input.
- ****Divide into equivalence classes****: Group inputs into valid and invalid partitions.
- ****Select representative values****: Choose one value from each partition for testing.
- ****Design test cases****: Create test cases using the selected values.
- ****Execute and validate results:**** Run the test cases and compare actual results with expected results.

## Limitations of EP

Equivalence Partitioning is useful for reducing test cases, but it has certain limitations. It may miss defects if partitions are not properly defined.

- May miss boundary defects if used alone without BVA.
- It depends on correct partitioning; incorrect grouping can lead to missed defects.
- Does not cover all combinations of inputs.
- Less effective for complex logic or interdependent inputs.

****Example:**** Consider a college admission form where the percentage field accepts values between 50% and 90% only.

Using Equivalence Partitioning, the input can be divided into three classes:

- Invalid Class 1: Percentage < 50%
- Valid Class: Percentage between 50% and 90%
- Invalid Class 2: Percentage > 90%

If a student enters a percentage outside the valid range, the application displays an error message. If the entered percentage is within 50%–90%, the input is accepted.

![[percentage.webp|percentage]]

College Admission Percentage

## Benefits of EP

Equivalence Partitioning helps simplify the testing process by reducing redundant test cases. It improves efficiency while still ensuring proper validation of system behavior.

- Reduces the number of test cases while maintaining good coverage
- Identifies valid and invalid inputs effectively
- Saves time and effort in testing large input domains
- Can be combined with BVA for more robust and effective testing

## Best Practices of EP Method

Equivalence Partitioning is most effective when input classes are defined accurately. Following best practices helps improve test coverage and defect detection.

- Define clear partitions based on requirements and input conditions
- Include both valid and invalid classes for complete testing
- Select proper representative values from each partition
- Avoid overlapping partitions to prevent confusion

Equivalence Partitioning mainly helps to:

- A
	Test internal code logic
- B
	Divide input data into valid and invalid classes
- C
	Increase the number of test cases
- D
	Perform performance testing

When an input range is given (e.g., 50–90%), how many equivalence classes are defined?

- A
	One valid only
- B
	Two valid only
- C
	One valid and two invalid
- D
	Two valid and one invalid

In a college admission system accepting percentages between 50% and 90%, which value belongs to a valid equivalence class?

When input is based on a specific set (e.g., valid product IDs), how many equivalence classes are formed?

Why is Equivalence Partitioning effective in black-box testing?

![[sucess-img 25.png|success]]

Quiz Completed Successfully

Score:0/5

Accuracy:0%