---
title: "Steps in Bottom Up Integration Testing"
source: "https://www.geeksforgeeks.org/software-engineering/steps-in-bottom-up-integration-testing/"
author:
  - "[[GeeksforGeeks]]"
published: 2020-07-04
created: 2026-09-23
description: "Your All-in-One Learning Portal: GeeksforGeeks is a comprehensive educational platform that empowers learners across domains-spanning computer science and programming, school education, upskilling, commerce, software tools, competitive exams, and more."
tags:
  - "clippings"
---
Bottom-Up Testing is an incremental [integration testing](https://www.geeksforgeeks.org/software-testing/software-engineering-integration-testing/) approach in which testing begins with lower-level modules and gradually moves upward to higher-level modules. It verifies the functionality and interaction of components from the bottom of the architecture to the top.

- Low-level modules are integrated and tested first, ensuring that core functionalities work correctly before testing higher-level modules.
- This approach simplifies defect detection, improves reliability, and supports systematic integration of software components.

> ****Example:**** In a banking application, modules such as database access and transaction processing are tested first. After they function correctly, higher-level modules like account management and user interfaces are integrated and tested.

## Steps of Bottom-Up Integration Testing

Following are the steps that are needed to be followed during the processing:

- ****Form Clusters:**** Low-level modules are combined into groups called clusters or builds, each responsible for specific functions.
- ****Create Drivers:**** Driver programs are developed to simulate higher-level modules and manage test inputs and outputs.
- ****Test the Clusters:**** Each cluster is tested thoroughly to verify the correct interaction and functionality of integrated low-level modules.
- ****Integrate Upward:**** Drivers are removed, and tested clusters are gradually integrated with higher-level modules until the complete system is formed.

## Example of Bottom-Up Integration Testing

Modules are combined to form clusters, and each cluster is tested using driver programs to verify its functionality. After testing, the drivers are removed and the clusters are integrated upward with higher-level modules to build the complete system.

![[Untitled-Diagram142.png|bottom-up-integration-testing]]

Bottom-Up Integration Testing

## Advantages

Bottom-Up Integration Testing offers a systematic way to test software by starting with lower-level modules and gradually integrating higher-level components.

- It is easy and simple to create and develop test conditions.
- It is also easy to observe test results.
- It is not necessary to know about the details of the structural design.
- Low-level utilities are also tested well and are also compatible with the object-oriented structure.

## Disadvantages

Despite its benefits, Bottom-Up Integration Testing has some limitations that can affect testing efficiency and system validation.

- Towards the top of the Hierarchy, it becomes very complicated.
- There is no concept regarding the early skeletal system.
- There will be an impact on sibling and higher-level unit tests due to changes.