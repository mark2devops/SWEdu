---
title: "Data Flow Testing"
source: "https://www.geeksforgeeks.org/software-testing/data-flow-testing/"
author:
  - "[[GeeksforGeeks]]"
published: 2019-10-23
created: 2026-09-23
description: "Your All-in-One Learning Portal: GeeksforGeeks is a comprehensive educational platform that empowers learners across domains-spanning computer science and programming, school education, upskilling, commerce, software tools, competitive exams, and more."
tags:
  - "clippings"
---
Data Flow Testing is a [white-box testing](https://www.geeksforgeeks.org/software-testing/software-engineering-white-box-testing/) technique that examines how data moves through a program. It focuses on tracking the lifecycle of variables, including where they are defined, used, and modified, to identify data-related defects.

- Analyzes the flow of variables throughout the program execution.
- Helps detect issues such as uninitialized variables, unused variables, and incorrect variable usage.
- Improves software reliability by ensuring proper handling of data within the code.

## Basic Concepts in Data Flow Testing

Data Flow Testing is based on tracking how variables are created, used, modified, and removed throughout a program. Understanding these concepts helps identify data-related defects and ensures correct variable usage.

- ****Definition (d):**** A definition occurs when a value is assigned to a variable or an existing value is updated. It marks the starting point of a variable's data flow.
- ****Use (u):**** A use occurs when a variable's value is accessed or referenced in the program. It represents the point where the stored data is utilized.
- ****Kill (k):**** A kill occurs when a variable's value is overwritten or becomes inaccessible. It signifies the end of the previous value's lifecycle.
- ****Computational Use (c-use):**** A computational use occurs when a variable is used in calculations, expressions, or assignment statements. It helps perform data processing and computations.
- ****Predicate Use (p-use):**** A predicate use occurs when a variable is used in a conditional statement such as `if`, `while`, or `for`. It influences the program's execution path and decision-making.

## Types of Data Flow Testing

Data Flow Testing can be classified based on the coverage criteria used to analyze the flow of variables from their definitions to their uses. Each type provides a different level of test coverage and defect detection.

- ****All-Defs Testing:**** This type of testing ensures that every variable definition in the program is covered by at least one path leading to a use. It verifies that all defined variables are actually utilized.
- ****All-Uses Testing:**** This testing ensures that every variable definition is tested against all its possible uses, including both computational uses (c-use) and predicate uses (p-use). It provides more detailed coverage than All-Defs.
- ****All DU-Paths Testing:**** This technique ensures that all possible definition-to-use paths are executed without any redefinition in between. It provides the most comprehensive level of data flow coverage.
- ****All P-Uses Testing:**** This type focuses on testing all predicate (decision-based) uses of variables. It ensures variables are correctly used in control flow conditions like `if`, `while`, and `for`.
- ****All C-Uses Testing:**** This type focuses on testing all computational uses of variables. It ensures variables are correctly used in calculations and expressions.
- ****DU Pairs Testing:**** This technique focuses on testing each specific definition-use pair of variables. It ensures that every valid link between a definition and its use is verified through test cases.

## Process of Data Flow Testing

Data Flow Testing is performed in a systematic way to analyze how variables are defined, used, and killed throughout the program. It helps in identifying data-related defects and ensuring correct variable usage.

- ****Analyze Source Code:**** The program code is examined to identify all variables, their definitions, uses, and control flow structure.
- ****Build Control Flow Graph (CFG):**** A Control Flow Graph is created to represent all possible execution paths in the program.
- ****Identify Definitions and Uses:**** Each variable’s definition (d), computational use (c-use), and predicate use (p-use) are identified.
- ****Create DU (Definition-Use) Chains:**** Relationships between variable definitions and their possible uses are established.
- S ****elect Test Criteria:**** Choose a coverage criterion such as All-Defs, All-Uses, or All DU-Paths based on testing requirements.
- ****Design Test Cases:**** Test cases are created to cover selected DU paths and ensure proper data flow execution.
- ****Execute Test Cases:**** The program is tested using the designed test cases to observe variable behavior.
- ****Detect and Report Anomalies:**** Any data flow anomalies such as uninitialized or unused variables are identified and reported for correction.

## Data Flow Anomalies

Data Flow Testing identifies anomalies that occur due to incorrect relationships between variable definitions and uses. These anomalies help detect logical and data-related errors in a program.

****Common Data Flow Anomalies include:****

- A variable is ****defined but never used****, which leads to wasted memory or unnecessary code.
- A variable is ****used without being defined****, which can cause runtime errors or unpredictable behavior.
- A variable is ****defined multiple times before being used****, which may indicate redundant or overwritten values.

## Data Flow Testing Example: Tracking Definitions and Uses of Variables

- `read x, y;` → ****x and y are defined (input)****
- `if (x > y)` → ****x, y are used (predicate use)****
- `a = x + 1` → ****a defined, x used (computational use)****
- `a = y - 1` → ****a defined, y used (computational use)****
- `print a` → ****a is used (output use)****

## Control flow graph of above example

![[pgogram-flow-graph.png]]

## Definition Use Analysis of Variables in the Above Program

| Variable | Defined at node | Used at node |
| --- | --- | --- |
| x | 1 | 2, 3 |
| y | 1 | 2, 4 |
| a | 3, 4 | 5 |

Above table shows that:

- Variables x and y are defined at the input statement and used in conditional and arithmetic expressions.
- Variable a is defined in both branches of the if–else statement and used in the output statement.

## Applications of Data Flow Testing

- Data Flow Testing is especially useful:
- During unit testing
- For logic-intensive modules
- When validating critical computations
- In safety-critical or high-reliability systems

## Advantages of Data Flow Testing

- Helps identify improper use of variables (use before definition)
- Detects data-related errors effectively
- Improves code reliability and correctness
- Ensures proper tracking of variable definitions and uses
- Useful for finding hidden bugs in complex programs

## Limitations of Data Flow Testing

Despite its benefits Data Flow Testing has some limitations:

- Does not detect all logic errors in the program
- Cannot identify missing functionality or missing paths
- Becomes very complex for large programs
- Suffers from path explosion problem (too many execution paths)