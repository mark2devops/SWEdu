---
title: "Software Quality - Software Engineering"
source: "https://www.geeksforgeeks.org/software-engineering/software-engineering-software-quality/"
author:
  - "[[GeeksforGeeks]]"
published: 2019-05-02
created: 2026-09-23
description: "Your All-in-One Learning Portal: GeeksforGeeks is a comprehensive educational platform that empowers learners across domains-spanning computer science and programming, school education, upskilling, commerce, software tools, competitive exams, and more."
tags:
  - "clippings"
---
Software quality is the degree to which a product meets specified requirements and user expectations. It is categorised by functional suitability and structural quality (how well it performs, scales, and maintains).

- It measures how reliable, efficient, and user-friendly a software product is.
- Functionally correct software can still be low quality if it has poor usability or user experience.
- High-quality software meets functional requirements, providing good usability and performance.
![[factors_of_software_quality.webp|factors_of_software_quality]]

Factors of Software Quality

Though “fitness of purpose” could be a satisfactory definition of quality for some products like an automobile, a table fan, a grinding machine, etc. for code products, “fitness of purpose” isn't a completely satisfactory definition of quality.

### Factors of Software Quality

The modern read of high-quality associates with software many quality factors like the following:

1. ****Portability:**** A software is claimed to be transportable, if it may be simply created to figure in several package environments, in several machines, with alternative code products, etc.
2. ****Usability:**** A software has smart usability if completely different classes of users (i.e. knowledgeable and novice users) will simply invoke the functions of the products.
3. ****Reusability:**** A software has smart reusability if completely different modules of the products will simply be reused to develop new products.
4. ****Correctness:**** Software is correct if completely different needs as laid out in the SRS document are properly enforced.
5. ****Maintainability:**** A software is reparable, if errors may be simply corrected as and once they show up, new functions may be simply added to the products, and therefore the functionalities of the products may be simply changed, etc
6. ****Reliability:**** Software is more reliable if it has fewer failures. Since software engineers do not deliberately plan for their software to fail, reliability depends on the number and type of mistakes they make. Designers can improve reliability by ensuring the software is easy to implement and change, by testing it thoroughly, and also by ensuring that if failures occur, the system can handle them or can recover easily.
7. ****Efficiency.**** The more efficient software is, the less it uses of CPU-time, memory, disk space, [network bandwidth](https://www.geeksforgeeks.org/computer-networks/introduction-to-bandwidth/), and other resources. This is important to customers in order to reduce their costs of running the software, although with today’s powerful computers, CPU time, memory and disk usage are less of a concern than in years gone by.

### Software Quality Management System

[Software Quality Management](https://www.geeksforgeeks.org/software-engineering/software-engineering-software-project-management-spm/) System contains the methods that are used by the authorities to develop products having the desired quality.

- ****Managerial Structure:**** Quality System is responsible for managing the structure as a whole. Every Organization has a managerial structure.
- ****Individual Responsibilities:**** Each individual present in the organization must have some responsibilities that should be reviewed by the top management and each individual present in the system must take this seriously.

****Quality System Activities:**** The activities which each quality system must have been

- Project Auditing.
- Review of the quality system.
- It helps in the development of methods and guidelines.

### Evolution of Quality Management System

Quality Systems are basically evolved over the past some years. The evolution of a Quality Management System is a four-step process.

![[file 1.webp|file]]

Evolution of Quality Management System

1. ****Inspection:**** Product inspection task provided an instrument for quality control (QC).
2. ****Quality Control:**** The main task of [quality control](https://www.geeksforgeeks.org/software-engineering/differences-between-quality-assurance-and-quality-control/) is to detect defective devices, and it also helps in finding the cause that leads to the defect. It also helps in the correction of bugs.
3. ****Quality Assurance:**** [Quality Assurance](https://www.geeksforgeeks.org/software-testing/software-engineering-software-quality-assurance/) helps an organization in making good quality products. It also helps in improving the quality of the product by passing the products through security checks.
4. ****Total Quality Management (TQM):**** [Total Quality Management(TQM)](https://www.geeksforgeeks.org/business-studies/what-is-total-quality-management-tqm-and-just-in-time-jit-kanban/) checks and assures that all the procedures must be continuously improved regularly through process measurements.