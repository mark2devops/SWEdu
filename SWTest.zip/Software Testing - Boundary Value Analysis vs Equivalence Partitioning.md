---
title: "Software Testing - Boundary Value Analysis vs Equivalence Partitioning"
source: "https://www.geeksforgeeks.org/software-testing/software-testing-boundary-value-analysis-vs-equivalence-partitioning/"
author:
  - "[[GeeksforGeeks]]"
published: 2022-07-20
created: 2026-09-23
description: "Your All-in-One Learning Portal: GeeksforGeeks is a comprehensive educational platform that empowers learners across domains-spanning computer science and programming, school education, upskilling, commerce, software tools, competitive exams, and more."
tags:
  - "clippings"
---
Software Testingis a process of finding bugs and verifying whether the developed software meets its end-user requirements or not. To do testing, testers write test cases (step-by-step procedure for how to test) which take test data values as input to check the behavior of a software. In some cases, there is a pool of input values to be tested, and writing test cases for all input data values becomes laborious and error-prone. To overcome such a situation, test case design techniques are used.

This article focuses on discussing the difference between two techniques, Boundary value analysis, and Equivalence partitioning. The following topics will be discussed here:

1. ****What is Boundary Value Analysis (BVA)?****
2. ****What is Equivalence Partitioning?****
3. ****BVA vs Equivalence Partitioning****

Let's start discussing each of these in detail.

### What is Boundary Value Analysis (BVA)?

[BVA](https://www.geeksforgeeks.org/software-engineering/boundary-value-analysis-triangle-problem/) is used to check the behavior of application using test data that exist at boundary values or in more easy words, for a range of input data values, boundary values (extreme end values) are used as input for testing. It is mostly used design technique as it is believed that software is most likely to fail at upper and lower limits of input data values.

****Example:**** A software allows people of age 20 to 50 years (both 20 and 50 are inclusive) to fill a form, for which the user has to enter his age in the age field option of the software.

The boundary values are 20 (min value) and 50 (max value).

| Invalid Value  (min-1) | Valid Value  (min, min+1, nominal value, max-1, max) | Invalid Value  (max+1) |
| --- | --- | --- |
| 19 | 20, 21, 30, 49, 50 | 51 |

In the above table, one can clearly identify all valid and invalid test values (values consider during testing the system).

1. ****Valid value:**** Test values at which the system does not fail and function properly as per user requirement.
2. ****Invalid Values:**** test values that do not meet the system requirement.

### What is Equivalence Partitioning (EP)?

It is also termed [****Equivalence Class Partitioning (ECP)****](https://www.geeksforgeeks.org/software-engineering/equivalence-partitioning-method/).It is a [Black Box Testing](https://www.geeksforgeeks.org/software-testing/software-engineering-black-box-testing/) technique, where a range of input values are divided into equivalence data classes. In this, the tester tests a random input value from the defined interval of equivalence data classes and if the output for that input value is valid, then the whole class interval is considered valid and vice-versa.

****Example****: An application allow the user to enter the password of length 8-12 numbers (minimum 8 and maximum 12 numbers).

| Invalid Equivalence Class | Valid Equivalence Class | Invalid Equivalence Class |
| --- | --- | --- |
| <8 | 8-12 | \>12 |

Let's consider some password values for valid and invalid class

1. 1234 is of length 4 which is an invalid password as 4<8.
2. 567890234 is of length 9 which is a valid password as 9 lies between 8-12
3. 4536278654329 is of length 13 which is an invalid password as 13>12.

### Boundary Value Analysis vs Equivalence Partitioning

Boundary Value Analysis (BVA) focuses on testing at the boundaries between partitions, while Equivalence Partitioning (EP) divides input data into equivalent classes to reduce test cases. Both methods aim to minimize test efforts while maximizing coverage.

Below are some of the differences between BVA and Equivalence Partitioning.

|  | Boundary Value Analysis | Equivalence Partitioning |
| --- | --- | --- |
| ****Uses**** | BVA considers the input data values from the defined boundaries. | Equivalence Partitioning examines input data values from the range of equivalence class intervals. |
| ****Testing Values**** | It considers min+1, min, min-1, nominal, max+1, max, and max-1 values as input test data values. | In Equivalence partitioning, valid and invalid ranges of equivalence classes are taken for testing developed applications. |
| ****Bug Identification**** | It identifies bugs at boundary values only. | It helps in identifying bugs in-between the partitioned equivalence data class. |
| ****Application Areas**** | It is a part of stress and negative testing. | It can be performed at any stage of software testing like unit testing. |
| ****Usage Condition**** | It is restricted to applications with close boundary values. | Correctness of Equivalence Partitioning is dependent on how correctly the tester identifies equivalence class. |

However, both Boundary Value Analysis and Equivalence Partitioning are used together as one helps in finding bugs at boundaries and another helps to determine bugs that exist between the defined range of input data values.