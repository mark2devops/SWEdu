---
title: "Keyword Driven Testing in Software Testing"
source: "https://www.geeksforgeeks.org/software-testing/keyword-driven-testing-in-software-testing/"
author:
  - "[[GeeksforGeeks]]"
published: 2021-09-10
created: 2026-09-23
description: "Your All-in-One Learning Portal: GeeksforGeeks is a comprehensive educational platform that empowers learners across domains-spanning computer science and programming, school education, upskilling, commerce, software tools, competitive exams, and more."
tags:
  - "clippings"
---
Keyword Driven Testing is a functional automation testing approach where test cases are designed using keywords that represent specific actions. Each keyword is mapped to a function or method, allowing testers to create structured and reusable automation scripts without focusing on underlying code.

- Separates test data, test steps, and object definitions for better maintainability.
- Uses a table or spreadsheet-based format to organize keywords and actions.
- Improves reusability, scalability, and readability of automation test cases.

### Example of Keyword Driven Framework

It uses external files and components to store keywords, test data, and reusable functions for automation.

- ****Excel Sheet:**** Stores keywords and test steps used for executing different test cases.
- ****Function Library:**** Contains reusable functions for business actions (e.g., login, button clicks).
- ****Data Sheets:**** Stores test data used in the application for multiple input combinations.
- ****Object Repository:**** Maintains object locators based on the chosen automation framework.
- ****Test Scripts:**** Contains driver scripts that execute test cases using keywords and data sources.

****Example scenario of Keyword Driven Testing in a login application:****

![[Keyword-Driven-Testing-example.webp|Example of  Keyword Driven Testing example]]

Example of Keyword Driven Testing

Login to “GeeksforGeeks” website – The keyword “Sign in” is used in automation to perform the login action and test the login functionality or related features.

## Need for Keyword Driven Testing

It is widely used in automation because it improves efficiency and reduces duplication in testing.

- Reduces maintenance cost by reusing keywords and test scripts across multiple test cases.
- Improves reusability and portability of test functions across different applications and tools.
- Enables structured automation by mapping low-level and high-level keywords to executable actions.
- Supports both manual and automated testing with better scalability and flexibility.

## Phases of Keyword Driven Testing

Keyword Driven Testing is divided into two main phases: Design & Development and Implementation, which together define the complete framework structure and execution flow.

### 1\. Design and Development Phase

In this phase, the complete framework structure is designed by identifying keywords and mapping them to specific actions or functions before execution begins.

- Keywords are identified and defined based on application functionality and test requirements.
- Each keyword is mapped to a corresponding function or method to perform a specific action.
- Test data, object locators, and reusable components are created and stored in external files.
- Overall test flow and execution structure are designed to ensure smooth automation.

### 2\. Implementation Phase

In this phase, the actual execution of test cases takes place using the prepared keywords, test data, and driver scripts.

- Driver script reads keywords and executes the mapped actions step by step in a controlled flow.
- Test cases are executed using external data sources such as Excel files or databases.
- Execution results are generated based on validation of expected and actual outcomes.
- Defects and failures are identified during execution and reported for further analysis.

## Advantages of Keyword Driven Testing

Keyword Driven Testing provides several benefits that make automation easier, more flexible, and scalable for testers and teams.

- Allows testers to design test automation early, even before the application is fully developed.
- Enables test case creation without requiring programming knowledge or coding skills.
- Reduces dependency on coding by allowing testers to work with reusable keywords instead of writing full automation scripts.
- Compatible with most automation tools, making it easy to integrate into different frameworks.

## Limitations of Keyword Driven Testing

Keyword Driven Testing has some limitations that can affect development time and flexibility in automation projects.

- Requires significant time and effort to design and develop keywords along with their corresponding functions and test logic.
- Initial framework setup becomes complex and time-consuming, especially for large and scalable automation projects.
- Can reduce flexibility for technical testers as they must strictly follow predefined keywords and structure.
- May limit the use of testers’ programming expertise and experience during test design and execution.

## Hybrid Automation Framework

In real-world automation projects, Keyword Driven Testing is often combined with other frameworks such as Data-Driven and Page Object Model (POM) to form a Hybrid Framework. This improves flexibility, scalability, and maintainability of test automation.

- Combines multiple automation approaches for better efficiency.
- Uses keywords along with external test data for flexibility.
- Improves reusability and reduces maintenance effort.
- Widely used in enterprise-level automation projects.

What is the main purpose of Keyword Driven Testing?

- A
	To define tests using reusable keywords
- B
	To store application databases
- C
	To replace automation tools completely
- D
	To perform only manual testing

Which component in a Keyword Driven Framework stores reusable business functions?

- A
	Data Sheets
- B
	Function Library
- C
	Object Repository
- D
	Driver Script

What is stored in the Object Repository in Keyword Driven Testing?

Which phase of Keyword Driven Testing focuses on identifying and defining keywords?

What is one major advantage of Keyword Driven Testing?

![[sucess-img 44.png|success]]

Quiz Completed Successfully

Score:0/5

Accuracy:0%