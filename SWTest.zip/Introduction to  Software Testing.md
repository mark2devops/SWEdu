---
title: "Introduction to  Software Testing"
source: "https://www.geeksforgeeks.org/software-testing/software-testing-basics/"
author:
  - "[[GeeksforGeeks]]"
published: 2017-08-08
created: 2026-09-23
description: "Your All-in-One Learning Portal: GeeksforGeeks is a comprehensive educational platform that empowers learners across domains-spanning computer science and programming, school education, upskilling, commerce, software tools, competitive exams, and more."
tags:
  - "clippings"
---
Software testing is the process of evaluating a software application to verify that it works as expected and meets specified requirements. It helps identify defects, errors, and missing functionalities before the software is delivered to users.

- Software testing ensures that an application is reliable, secure, and performs correctly.
- It helps improve software quality by detecting and fixing defects early in the development lifecycle.

> ****Real Life Example:**** Imagine an online banking application where users transfer money between accounts. If testing is not performed properly, a defect may cause incorrect transactions, leading to financial losses and customer dissatisfaction.m

## Types of Software Testing

[Types of Software Testing](https://www.geeksforgeeks.org/software-testing/types-software-testing/) mainly are mainly categorized into two domains, which are as follows:

### Manual Testing

[Manual testing](https://www.geeksforgeeks.org/software-testing/software-testing-manual-testing/) is a software testing technique in which testers execute test cases manually without using automation tools. It helps verify application functionality and identify defects by comparing actual results with expected results.

- Test cases are executed manually by testers.
- Defects are identified through result verification.

> ****Example:**** A tester manually checks whether a login page accepts valid credentials.

### Automation Testing

[Automation testing](https://www.geeksforgeeks.org/software-testing/automation-testing-software-testing/) is a software testing technique in which test cases are executed using scripts and automation tools. It helps automate repetitive tasks, improving testing speed, accuracy, and efficiency.

- Test cases are executed using automation tools.
- Reduces manual effort and saves testing time.

> ****Example:**** A Selenium script automatically tests the login functionality and verifies the result.

## Need for Software Testing

Software bugs can cause serious consequences, including financial loss, system failures, and even loss of life. Some real-world examples highlight its importance:

- ****1985:**** Therac-25 radiation machine malfunction caused deaths and injuries.
- ****1994:**** China Airlines crash due to a software bug killed 264 people.
- ****1996:**** U.S. bank error credited $920 million to 823 customers.
- ****1999:**** Software bug led to failure of a $1.2B military satellite launch.
- ****2015:**** F-35 fighter jet bug affected target detection.
- ****2015****: Bloomberg terminal crash disrupted 300,000 traders.
- ****Starbucks:**** POS failure shut down 60% of outlets in the U.S. and Canada.
- ****Nissan:**** Recalled 1 million cars due to airbag software issues.

> ****Note:**** These examples show that software testing is critical for ensuring reliability, safety, and performance.

## Important Terms in Software Testing

- [Test Case](https://www.geeksforgeeks.org/software-testing/what-is-a-test-case/): A set of inputs, conditions, and expected results used to verify whether a specific functionality of the software works correctly.
- [Test Suite](https://www.geeksforgeeks.org/software-testing/how-to-create-test-suite-in-testng/): A collection of multiple test cases grouped together to test different features of an application in various scenarios.
- [Test Plan:](https://www.geeksforgeeks.org/software-testing/test-plan-software-testing/) A document that defines the scope, objectives, resources, schedule, and approach for testing activities.
- [Defects/Bugs](https://www.geeksforgeeks.org/software-testing/software-testing-bug-vs-defect-vs-error-vs-fault-vs-failure/): Errors or issues in the software where actual results differ from expected results, affecting functionality or performance.
- [Regression Testing:](https://www.geeksforgeeks.org/software-engineering/software-engineering-regression-testing/) Testing performed after changes or updates to ensure existing features still work correctly and no new issues are introduced.

## Common Tools Used in Software Testing

- [Selenium](https://www.geeksforgeeks.org/software-testing/selenium-with-java-tutorial/): An open-source automation tool used for testing web applications. It supports multiple programming languages like Java, Python, and C#.
- [JIRA](https://www.geeksforgeeks.org/software-engineering/what-is-jira-software/): A popular tool for bug tracking, issue management, and project tracking. It helps teams manage defects efficiently.
- [TestNG](https://www.geeksforgeeks.org/software-testing/testng-tutorial/#what-is-testng): A testing framework used with Selenium for organizing test cases, generating reports, and managing test execution.
- [Postman](https://www.geeksforgeeks.org/software-testing/postman-tutorial/#what-is-postman): A tool used for API testing. It allows testers to send requests, validate responses, and automate API tests.
- [LoadRunner](https://www.geeksforgeeks.org/software-testing/software-testing-load-testing/): A performance testing tool used to simulate multiple users and analyze system behavior under load.
- [BrowserStack](https://www.geeksforgeeks.org/interview-experiences/browserstack-recruitment-process/): A cloud-based testing platform used for cross-browser and cross-device testing of web and mobile applications. It allows testing on real browsers, operating systems, and mobile devices without requiring a local setup.

Which type of software testing is performed without using automation tools?

- A
	Automation Testing
- B
	Manual Testing
- C
	Performance Testing
- D
	Regression Testing

Which type of testing checks whether the application works according to business requirements?

Which testing technique requires knowledge of the internal code structure?

Which software testing tool is mainly used for API testing?

What is the main purpose of Regression Testing?

![[sucess-img 39.png|success]]

Quiz Completed Successfully

Score:0/5

Accuracy:0%