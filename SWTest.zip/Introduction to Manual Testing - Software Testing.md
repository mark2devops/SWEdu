---
title: "Introduction to Manual Testing - Software Testing"
source: "https://www.geeksforgeeks.org/software-testing/software-testing-manual-testing/"
author:
  - "[[GeeksforGeeks]]"
published: 2019-05-07
created: 2026-09-23
description: "Your All-in-One Learning Portal: GeeksforGeeks is a comprehensive educational platform that empowers learners across domains-spanning computer science and programming, school education, upskilling, commerce, software tools, competitive exams, and more."
tags:
  - "clippings"
---
Manual Testing is a [software testing](https://www.geeksforgeeks.org/software-testing/software-testing-basics/) process in which testers execute test cases manually without using automation scripts. Testers interact with the application to verify its functionality, usability, and overall behavior from a user's perspective.

- Helps identify bugs, UI issues, and unexpected behavior.
- Allows testers to validate application functionality through direct interaction.
- Provides flexibility to adapt testing based on changing requirements.
![[when_to_perform_manual_testing.webp|when_to_perform_manual_testing]]

## Features of Manual Testing

Manual testing has several characteristics that make it useful for evaluating different aspects of a software application.

- Uses human observation and judgment during testing.
- Verifies application behavior using predefined test cases.
- Supports exploratory testing without strictly following predefined steps.
- Allows flexible test execution when requirements or application behavior change.
- Helps evaluate usability and the overall user experience.

## Testing Approaches in Manual Testing

Manual testing can follow different testing approaches depending on the tester's knowledge of the application's internal structure. The three main approaches are Black Box Testing, White Box Testing, and Gray Box Testing.

![[manual_testing.webp|manual_testing]]

Testing Approaches

- [Black Box Testing](https://www.geeksforgeeks.org/software-testing/software-engineering-black-box-testing/): Tests the application's functionality without knowledge of its internal code, focusing on inputs, outputs, and expected behavior.
- [White Box Testing](https://www.geeksforgeeks.org/software-testing/software-engineering-white-box-testing/): Tests the application's internal code, logic, and structure with knowledge of its implementation.
- [Gray Box Testing](https://www.geeksforgeeks.org/software-testing/gray-box-testing-software-testing/): Tests the application with partial knowledge of its internal structure, combining elements of Black Box and White Box Testing.

## Types of Testing Performed Manually

Manual testing can include different types of testing based on what needs to be evaluated. These are commonly grouped into Functional and Non-Functional Testing.

### Functional Testing

[Functional Testing](https://www.geeksforgeeks.org/software-testing/software-testing-functional-testing/) verifies what the application does by ensuring that its features and functionalities work according to specified requirements.

- [Smoke Testing](https://www.geeksforgeeks.org/software-engineering/smoke-testing-software-testing/): Performs basic checks on critical functionalities to ensure the application is stable for further testing.
- [Sanity Testing](https://www.geeksforgeeks.org/software-engineering/sanity-testing/): Verifies specific functionalities after minor changes or bug fixes to ensure they work as expected.
- [Integration Testing](https://www.geeksforgeeks.org/software-testing/software-engineering-integration-testing/): Tests the interaction between different modules to ensure they work together correctly.
- [System Testing](https://www.geeksforgeeks.org/software-testing/system-testing/): Tests the complete application as a whole to validate end-to-end functionality.
- [Regression Testing](https://www.geeksforgeeks.org/software-engineering/software-engineering-regression-testing/): Re-tests existing functionalities after changes or bug fixes to ensure no new defects are introduced.
- [User Acceptance Testing (UAT)](https://www.geeksforgeeks.org/software-testing/user-acceptance-testing-uat/): Conducted by end users or clients to verify that the software meets business requirements.

### Non-Functional Testing

[Non-Functional Testing](https://www.geeksforgeeks.org/software-testing/software-testing-non-functional-testing/) evaluates how well the application operates in areas such as usability, performance, security, and compatibility.

- [Usability Testing](https://www.geeksforgeeks.org/software-testing/usability-testing/): Evaluates the application's ease of use, user interface, and overall user experience.
- [Compatibility Testing](https://www.geeksforgeeks.org/software-engineering/compatibility-testing-in-software-engineering/): Verifies that the application works correctly across different browsers, devices, and operating systems.
- [Performance Testing](https://www.geeksforgeeks.org/software-testing/performance-testing-software-testing/): Measures the application's speed, responsiveness, stability, and behavior under different workloads.
- [Security Testing](https://www.geeksforgeeks.org/software-testing/security-testing/): Identifies vulnerabilities and ensures the protection of sensitive data and system resources.

## Manual Testing Process

The manual testing process follows a structured sequence of activities to ensure that the application is tested systematically.

![[requirement_analysis.webp|requirement_analysis]]

Manual Testing Process

- ****Requirement Analysis:**** Understand and analyze the project requirements, user expectations, and business needs to identify what needs to be tested.
- ****Test Plan Creation:**** Create a test plan that defines the testing scope, objectives, resources, schedule, and testing approach.
- ****Test Case Creation:**** Design detailed test cases with test steps, expected results, and test data to validate application functionality.
- ****Test Environment Setup:**** Prepare the required hardware, software, tools, and test data to simulate the production environment.
- ****Test Case Execution:**** Execute the test cases and compare actual results with expected results to identify any issues.
- ****Defect Logging:**** Record defects with complete details such as description, severity, reproduction steps, and supporting evidence.
- ****Defect Fix & Reverification:**** Verify that reported defects have been fixed correctly and confirm that the issue no longer exists.
- ****Regression Testing:**** Retest affected and related functionalities to ensure that recent changes have not introduced new defects.
- ****Test Closure Report:**** Prepare a final report summarizing testing activities, results, defect status, and key lessons learned.

## Tools Used for Manual Testing

Manual testing tools help teams manage test cases, track test execution, maintain traceability, and organize testing activities.

- ****TestRail:**** A test management tool used to organize, execute, and track manual test cases with detailed reporting features.
- ****Xray (for Jira):**** A Jira-integrated testing tool that supports manual test management, traceability, and defect tracking.
- ****Qase:**** A cloud-based test management platform that simplifies test case creation, execution, and team collaboration.
- ****Zephyr:**** A test management solution that helps manage manual testing activities with strong Jira integration and reporting.
- ****Tuskr:**** A lightweight cloud-based test management tool for creating, managing, and tracking manual test cases efficiently.

## Advantages of Manual Testing

Manual testing is particularly useful when human judgment and flexibility are important.

- Detects usability issues and unexpected behavior through human observation.
- Does not require programming knowledge to execute basic test cases.
- Supports exploratory testing and flexible test execution.
- Helps evaluate the application's interface and overall user experience.
- Can be cost-effective for small projects and frequently changing requirements.

## Limitations of Manual Testing

Manual testing can become challenging when applications are large or testing tasks are highly repetitive.

- Can be time-consuming because test cases must be executed manually.
- Is prone to human error, especially during repetitive tasks.
- Makes repeated regression testing inefficient and resource-intensive.
- Can be difficult to scale for large and complex applications.
- Generally takes longer to execute than automated testing.

What is the main purpose of Manual Testing?

- A
	To execute tests using automation tools
- B
	To test software manually without automation tools
- C
	To develop software applications
- D
	To manage databases

Which type of testing checks software functionality without knowing the internal code structure?

- A
	White Box Testing
- B
	Gray Box Testing
- C
	Black Box Testing
- D
	Unit Testing

Which document defines the scope, objectives, resources, and strategy for testing?

Which testing type ensures that new changes have not affected existing functionality?

What information is typically included while reporting a defect?

- A
	Only defect title
- B
	Only screenshots
- C
	Steps to reproduce, severity, and expected vs actual results
- D
	Only test case ID

![[sucess-img 42.png|success]]

Quiz Completed Successfully

Score:0/5

Accuracy:0%