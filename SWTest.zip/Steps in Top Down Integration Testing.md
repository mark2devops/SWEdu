---
title: "Steps in Top Down Integration Testing"
source: "https://www.geeksforgeeks.org/software-engineering/steps-in-top-down-integration-testing/"
author:
  - "[[GeeksforGeeks]]"
published: 2020-07-04
created: 2026-09-23
description: "Your All-in-One Learning Portal: GeeksforGeeks is a comprehensive educational platform that empowers learners across domains-spanning computer science and programming, school education, upskilling, commerce, software tools, competitive exams, and more."
tags:
  - "clippings"
---
Top-Down Testing is an incremental integration testing approach in which testing begins with high-level modules and gradually moves down to lower-level modules. It verifies system functionality by integrating components from top to bottom through the control flow.

- High-level modules are tested first, followed by the integration and testing of lower-level modules.
- Stubs are used to simulate the behavior of lower-level modules that are not yet developed or integrated.

> ****Example:**** In an online shopping system, the main order processing module is tested first. Lower-level modules such as payment processing and inventory management are then integrated and tested step by step.

## Steps of Top-Down Integration Testing

- ****Create Test Environment:**** The main control module (high-level module) is used as the test driver, while stubs simulate the behavior of lower-level modules.
- ****Test High-Level Modules:**** Testing begins with high-level modules in isolation to verify their functionality.
- ****Replace Stubs Gradually:**** Lower-level modules are integrated one at a time by replacing stubs using depth-first or breadth-first integration.
- ****Continue Integration:**** The process is repeated until all modules are integrated and tested successfully.
- ****Update Stubs:**** After each testing phase, stubs are replaced with actual modules to simulate real system behavior.
- ****Perform Regression Testing:**** Regression testing is conducted to ensure that newly integrated modules do not introduce defects or affect existing functionality.

## Shortcomings of Top Down Integration Testing

Top-Down Integration Testing has some limitations that can affect testing efficiency and coverage, especially for lower-level modules.

- High-level modules must be thoroughly tested before integrating lower-level modules to ensure reliable results.
- Since stubs replace lower-level modules, actual data flow may not be fully tested, which can delay defect detection.
- Stubs can become increasingly complex as more lower-level modules are replaced during testing.
- It may become difficult to maintain a clear relationship between specific test cases and individual modules.
- Lower-level modules and utilities may not receive adequate testing in the early stages of integration.
- High-level modules must be thoroughly tested before integrating lower-level modules to ensure reliable results.
- Since stubs replace lower-level modules, actual data flow may not be fully tested, which can delay defect detection.
- Stubs can become increasingly complex as more lower-level modules are replaced during testing.
- It may become difficult to maintain a clear relationship between specific test cases and individual modules.

## Example

In the top-down integration testing, if the depth-first approach is adopted then we will start integration from module M1. Then we will integrate M2, then M3, M4, M5, M6, and at last M7.

![[Untitled-Diagram140.png|top-down-example-of-integration-testing]]

Top-Down Integration Testing

In the top-down integration testing, if the breadth-first approach is adopted, then we will integrate module M1 first, then M2,and M6. Then we will integrate module M3, M4, M5, and at last M7.

## Advantages

Top-Down Integration Testing helps verify high-level functionality early and simplifies the identification of integration issues.

- There is no need to create separate driver programs for testing.
- Interface defects and integration errors can be detected at an early stage.
- Fault localization is easier because testing starts from the top-level modules.
- Test cases are easier to design once input and output functions are available.

## Disadvantages

Despite its advantages, this approach relies heavily on stubs and may not thoroughly test lower-level modules in the early stages.

- A large number of stubs and mock objects may be required.
- Creating realistic test cases for stubs can be difficult before actual modules are available.
- Important low-level utilities may not be tested thoroughly during the initial stages of testing.