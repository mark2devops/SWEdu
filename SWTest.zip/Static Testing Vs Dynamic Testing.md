---
title: "Static Testing Vs Dynamic Testing"
source: "https://www.geeksforgeeks.org/software-engineering/difference-between-static-and-dynamic-testing/"
author:
  - "[[GeeksforGeeks]]"
published: 2019-05-14
created: 2026-09-23
description: "Your All-in-One Learning Portal: GeeksforGeeks is a comprehensive educational platform that empowers learners across domains-spanning computer science and programming, school education, upskilling, commerce, software tools, competitive exams, and more."
tags:
  - "clippings"
---
Static Testing and Dynamic Testing are two important approaches used in software testing to ensure quality. Static testing evaluates software artifacts without executing the code, while dynamic testing validates the software by executing it. Both are essential for identifying defects at different stages of development.

## Static Testing

[Static Testing](https://www.geeksforgeeks.org/software-engineering/software-testing-static-testing/) is the process of evaluating software without executing the code. It focuses on reviewing documents, code, and design to find defects early.

- Done without running the program
- Includes reviews, inspections, and walkthroughs
- Detects defects early during requirements, design, and coding phases.

> ****Example:**** Reviewing requirement documents or code to identify mistakes before execution.

## Dynamic Testing

[Dynamic Testing](https://www.geeksforgeeks.org/software-engineering/software-testing-dynamic-testing/) is a software testing technique in which the application is executed to evaluate its behavior, functionality, and performance. It involves validating the actual output against expected results and helps identify defects during runtime.

- Involves actual execution of the software using Black Box, White Box, or Gray Box testing techniques.
- Helps identify runtime errors, functional defects, integration issues, and non-functional issues such as performance, security, and usability problems.
- Ensures the software meets both functional and non-functional requirements.

> ****Example:**** Testing a login feature by entering valid and invalid usernames and passwords to verify system behavior and response.

| Parameter | Static Testing | Dynamic Testing |
| --- | --- | --- |
| ****Definition**** | Testing performed without executing the software code. | Testing performed by executing the software application. |
| ****Objective**** | Identify defects early and prevent errors. | Identify defects during execution and validate functionality. |
| ****Stage**** | Performed during requirements, design, and coding phases. | Performed after code implementation when an executable build is available. |
| ****Code Execution**** | Not required. | Required. |
| ****Focus**** | Requirements, design documents, and source code. | Software behavior, functionality, and performance. |
| ****Techniques**** | Reviews, walkthroughs, inspections, and code reviews. | Functional testing, non-functional testing, Black Box Testing, White Box Testing, etc. |
| ****Defects Found**** | Requirement, design, documentation, and coding defects. | Runtime, functional, performance, and integration defects. |
| ****Test Basis**** | Documents, specifications, and source code. | Executable application and test cases. |
| ****Cost**** | Lower cost because defects are found early. | Generally higher cost because defects are identified later in the development cycle. |
| ****Time Required**** | Generally less time-consuming. | Usually more time-consuming due to test execution. |
| ****Tools Used**** | Review tools, static code analysis tools. | Test automation tools, performance testing tools, and defect tracking tools. |
| ****Process Type**** | Verification – "Are we building the product right?" | Validation – "Are we building the right product?" |
| ****Example**** | Reviewing a requirement document or source code. | Testing a login page by entering valid and invalid credentials. |

Which type of testing is performed without executing the software code?

- A
	Static Testing
- B
	Dynamic Testing
- C
	Load Testing
- D
	Regression Testing

Which testing technique analyzes the behavior of software by executing the code?

Which static testing technique uses a formal process and checklist to identify defects?

Which type of dynamic testing focuses on the internal logic and structure of the code?

Which testing type is mainly used to identify runtime errors and performance issues?

![[sucess-img 72.png|success]]

Quiz Completed Successfully

Score:0/5

Accuracy:0%