---
title: "Static Testing - Software Testing"
source: "https://www.geeksforgeeks.org/software-engineering/software-testing-static-testing/"
author:
  - "[[GeeksforGeeks]]"
published: 2019-05-13
created: 2026-09-23
description: "Your All-in-One Learning Portal: GeeksforGeeks is a comprehensive educational platform that empowers learners across domains-spanning computer science and programming, school education, upskilling, commerce, software tools, competitive exams, and more."
tags:
  - "clippings"
---
Static Testing is a type of [software testing](https://www.geeksforgeeks.org/software-testing/software-testing-tutorial/) where the application or code is reviewed without executing it. It is mainly used to detect errors in requirements, design documents, and source code at an early stage. This helps in improving software quality before actual execution begins.

- It does not involve running the program or executing code.
- It helps in identifying defects early in the Software Development Life Cycle (SDLC).
- It includes techniques like reviews, walkthroughs, and inspections.

## Static Testing Process

Static Testing is a verification process where software artifacts (like requirements, design documents, and code) are reviewed without executing the program. It helps detect defects early in the software development life cycle.

- ****Requirement Analysis:**** Requirement documents are reviewed to check clarity, completeness, and correctness before development begins.
- ****Design Review:**** Design documents are checked to ensure they meet requirements and follow proper system architecture.
- ****Code Review:**** Source code is examined without execution to find errors, coding issues, and violations of coding standards.
- ****Walkthrough:**** The author explains the document or code to peers to gather feedback and identify defects early.
- ****Inspection:**** A formal review process where documents are checked using checklists to detect defects systematically.
- ****Tool-Based Static Analysis:**** Automated tools analyze code to detect bugs, security issues, and standard violations without executing the program.

## Features Tested in Static Testing

Static testing focuses on verifying documents, code and artifacts to ensure completeness, correctness and adherence to standards. Key features tested include:

- ****Unit Test Cases:**** Ensure completeness and compliance with standards.
- ****Business Requirements Document (BRD):**** Verify all business requirements are clearly documented.
- ****Use Cases & Prototypes:**** Check that use cases and prototypes accurately reflect system functionality and user interactions.
- ****System Requirements & Test Data:**** Validate accuracy of system requirements and completeness of test data for all scenarios.
- ****Traceability Matrix:**** Confirm all requirements are mapped to corresponding test cases.
- ****Training Guides & Performance Scripts:**** Ensure documentation and test scripts reflect system functionality and critical performance aspects

## Types of Static Testing

There are mainly two types of techniques used in Static Testing:

![[static_testing.webp|static_testing]]

Types of Static Testing

### Review

Review is a manual process where software documents (requirements, design, code) are examined without executing the program to detect defects early.

- ****Informal Review:**** Informal discussion of documents for feedback and defect detection.
- ****Walkthrough:**** Author explains the document step-by-step to peers for understanding and defect identification.
- ****Peer Review:**** Team members review each other’s work to find defects.
- ****Inspection:**** A formal review process conducted using checklists and defined roles to identify defects in documents like SRS, design, or code.

### Static Analysis

Static analysis is the automated examination of source code using tools to detect defects, ensure coding standards, and improve code quality without executing the program.

- ****Data Flow Analysis:**** Checks how data is defined, used, and passed through the program.
- ****Control Flow Analysis:**** Examines the order in which instructions are executed in the program.
- ****Cyclomatic Complexity:**** Measures the number of independent paths in the code to determine testing effort and code complexity.

## Process of Static Testing

Static testing is performed systematically to detect defects early in the development lifecycle. The main steps include:

- ****Planning:**** Define the scope, objectives, and decide which documents or code will be reviewed, along with selecting appropriate techniques and tools.
- ****Prepare Artifacts:**** Collect all required documents such as requirements, design specifications, source code, and test-related artifacts needed for review.
- ****Review/Inspection:**** Perform manual examination of documents and code to identify defects using techniques like walkthroughs, peer reviews, or formal inspections.
- ****Static Analysis:**** Use automated tools to analyze source code for coding standard violations, security issues, and other quality-related defects without execution.
- ****Bug Reporting:**** Document all identified defects clearly in a tracking system so that developers can understand and fix them efficiently.
- ****Result Analysis:**** Evaluate the detected issues to assess software quality and identify improvements in development and testing processes.

## Artifacts Reviewed in Static Testing

Static testing is applied to various software documents and artifacts:

- Requirements documents (BRD, SRS)
- Design documents
- Source code
- Test cases
- Use cases and prototypes
- Traceability matrix
- Test scripts and performance documents

## Tools Used in Static Testing

Some of the most commonly used static testing tools are:

- ****SonarQube:**** A popular tool used to detect bugs, code smells, and security vulnerabilities in source code.
- ****Checkstyle:**** A tool used to check Java code for coding standard violations and formatting issues.
- ****PMD:**** A static analysis tool used to detect common coding problems like unused variables and empty blocks.
- ****ESLint:**** A tool used for JavaScript to identify errors and enforce coding best practices.
- ****SpotBugs (FindBugs):**** A tool used to analyze Java bytecode to find potential bugs without executing the program.
- ****Fortify Static Code Analyzer:**** A security tool used to detect vulnerabilities and weaknesses in application source code.

## Need for Static Testing

Static testing is required in the following situations during software development:

- ****Complex Software:**** Helps manage large codebases and detect hidden defects early.
- ****High Cost of Dynamic Testing:**** Reduces cost and effort by identifying issues before execution.
- ****Time Constraints:**** Speeds up the testing process by finding defects early.
- ****Improved Productivity:**** Reduces rework and improves overall development efficiency.

## Best Practices for Static Testing

To make static testing more effective, the following best practices should be followed:

- Define clear objectives before starting the review process.
- Use checklists to ensure consistency and coverage.
- Focus on high-risk modules and critical components.
- Train team members in tools and review techniques.
- Plan, schedule, and track review activities properly.
- Maintain a formal and structured review process.
- Regularly update and use static analysis tools.

## Limitations of Static Testing

Below are some of the limitations of static testing:

- ****Limited Defect Detection:**** Cannot identify runtime issues like memory leaks or performance problems.
- ****Reviewer Dependent:**** Effectiveness relies on the skill and experience of reviewers.
- ****Time-Intensive:**** Reviewing large or complex projects can take significant time.
- ****No Execution Environment:**** Since code isn’t run, some dynamic errors remain undetected.
- ****Prone to Human Error:**** Manual inspections may miss defects or introduce mistakes