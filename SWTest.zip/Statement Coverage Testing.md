---
title: "Statement Coverage Testing"
source: "https://www.geeksforgeeks.org/software-testing/statement-coverage-testing/"
author:
  - "[[GeeksforGeeks]]"
published: 2022-10-04
created: 2026-09-23
description: "Your All-in-One Learning Portal: GeeksforGeeks is a comprehensive educational platform that empowers learners across domains-spanning computer science and programming, school education, upskilling, commerce, software tools, competitive exams, and more."
tags:
  - "clippings"
---
Statement Coverage is a white-box testing technique used to verify that every executable statement in a program is executed at least once during testing. It helps ensure that the written code is properly tested and improves software reliability.

## Statement Coverage

Statement Coverage measures the percentage of executable statements that have been tested in a program. It checks whether each statement has been executed during the testing process.

### Formula

> Statement coverage = (Number of executed statements / Total number of statements in source code) \* 100

## How It Works

Consider this function:
```
def get_discount(price, is_member):
    discount = 0                          # S1
    if is_member:                         # S2
        discount = price * 0.10          # S3
    if price > 100:                       # S4
        discount += price * 0.05         # S5
    return price - discount              # S6
```
| Test Case | is\_member | price | Statements Hit |
| --- | --- | --- | --- |
| T1 | True | 150 | S1, S2, S3, S4, S5, S6 |
| T2 | False | 50 | S1, S2, S4, S6 |

With both tests, all 6 statements are covered 100% statement coverage.

### Step-by-Step Working

- Test cases are designed based on the internal code logic
- Each test case executes specific statements in the program
- Coverage is calculated by comparing executed statements with total statements
- Multiple test cases may be required to achieve 100% coverage

### What It Catches vs. Misses

****Catches:****

- Dead code (unreachable statements)
- Unexecuted branches due to missing tests
- Basic logic errors that crash execution

****Misses:****

- False conditions — an `if` branch being `False` doesn't need a test
- Logical errors in conditions (e.g., `>` vs `>=`)
- Combinations of conditions
- Missing `else` clauses

### Example 1:

> Read A  
> Read B  
> if A > B  
> Print “A is greater than B”  
> else  
> Print "B is greater than A"  
> endif

### Flowchart

![[statement_coverage_flow.webp|statement_coverage_flow]]

****Case 1:****

> If A = 7, B= 3
> 
> No of statements Executed= 5
> 
> Total statements= 7
> 
> Statement coverage= 5 / 7 \* 100  
> \= 71.00 %

****Case 2:****

> If A = 4, B= 8
> 
> No of statements Executed= 6
> 
> Total statements= 7
> 
> Statement coverage= 6 / 7 \* 100  
> \= 85.20 %

## Coverage Hierarchy

Statement coverage is the weakest in the hierarchy of code coverage techniques because it only checks whether each statement is executed. Higher coverage techniques provide more thorough testing of program logic and execution paths.

> Statement < Branch < Condition < Path Coverage
> 
> (Weakest) (Strongest)

| Level | What’s Measured |
| --- | --- |
| Statement Coverage | Each statement executes at least once |
| Branch Coverage | Each decision outcome (True/False) is tested |
| Condition Coverage | Each Boolean condition is evaluated |
| Path Coverage | Every possible execution path is tested |

## Advantages of Statement Coverage

- Easy to understand and implement
- Helps identify dead and unused code
- Improves overall code quality
- Useful during unit testing

## Limitations of Statement Coverage

- Does not test all decision or branch outcomes
- Cannot detect logical errors in conditions
- 100% statement coverage does not guarantee bug-free software
- Some execution paths may remain untested

## Usage of Statement Coverage

- During unit testing
- For small and medium-sized modules
- When analyzing test completeness
- In early stages of development