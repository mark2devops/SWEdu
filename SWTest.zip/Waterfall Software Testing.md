---
title: "Waterfall Software Testing"
source: "https://www.geeksforgeeks.org/software-engineering/waterfall-software-testing/"
author:
  - "[[GeeksforGeeks]]"
published: 2019-06-19
created: 2026-09-23
description: "Your All-in-One Learning Portal: GeeksforGeeks is a comprehensive educational platform that empowers learners across domains-spanning computer science and programming, school education, upskilling, commerce, software tools, competitive exams, and more."
tags:
  - "clippings"
---
Waterfall [Software Testing](https://www.geeksforgeeks.org/software-testing/software-testing-basics/) is a traditional testing approach in which testing is performed only after the development phase is completed. It follows a sequential process where each phase is completed step-by-step before moving to the next. This approach is suitable for projects with clear and stable requirements.

- Testing starts after development is completed.
- Follows a linear and structured process.
- Best suited for small and well-defined projects.

> ****Example:**** A company develops an e-commerce website completely first, and then the testing team tests all features together, leading to multiple defects being found at once.

![[waterfall_methodology 2.webp|waterfall_methodology]]

Waterfall Model

## Phases

This diagram shows the sequential flow of phases where testing begins after development is completed and moves level by level.

- ****Requirement Analysis:**** Requirements are gathered, analyzed, and documented to understand the needs and expectations of stakeholders.
- ****System Design:**** The system architecture and technical specifications are created based on the defined requirements.
- ****Implementation (Coding):**** Developers write the code and build the software according to the approved design.
- ****Testing:**** The completed software is tested to identify defects and ensure it meets the specified requirements.
- ****Deployment:**** The tested software is released to the production environment for end users.
- ****Maintenance:**** The software is monitored, updated, and fixed to ensure continued performance and reliability.

## Testing Levels in Waterfall Testing

Testing is performed in a structured sequence after development:

![[testing.webp|testing]]

Testing Levels

- [Unit Testing](https://www.geeksforgeeks.org/software-testing/unit-testing-software-testing/): Individual modules or components are tested separately to verify that they function correctly.
- [Integration Testing](https://www.geeksforgeeks.org/software-testing/software-engineering-integration-testing/): Multiple modules are combined and tested to ensure they interact and exchange data properly.
- [System Testing](https://www.geeksforgeeks.org/software-testing/system-testing/): The complete application is tested as a whole to validate functional and non-functional requirements.
- [Acceptance Testing](https://www.geeksforgeeks.org/software-engineering/acceptance-testing-software-testing/): The final product is tested by clients or end users to confirm it meets business requirements and is ready for release.

## Tools Used in Waterfall Testing

Various testing tools can be used in the Waterfall Model to support test planning, execution, defect tracking, and automation. The choice of tools depends on the project requirements and testing needs.

- ****Selenium:**** Used for automating web application testing.
- ****JUnit / TestNG:**** Used for unit testing Java applications.
- ****Postman:**** Used for API testing and validation.
- ****JIRA:**** Used for defect tracking and test management.
- ****HP ALM (Quality Center):**** Used for managing test cases, test execution, and defects.
- ****Bugzilla:**** Used for logging and tracking software defects.

## Advantages of Waterfall Testing

This approach offers a structured and predictable testing process with clear separation of responsibilities.

- Ensures a clear separation between development and testing, improving focus and accountability.
- Provides a well-defined and organized workflow, making it easy to understand and manage.
- Reduces interruptions during development since testing is performed after completion.
- Helps in identifying defects in the complete system rather than in isolated parts.
- Suitable for projects with fixed and well-defined requirements.

## Limitations of Waterfall Testing

Despite its simplicity, this approach has limitations due to its rigid and sequential nature.

- Delays defect detection since testing begins after development is completed.
- Fixing multiple defects at a later stage becomes time-consuming and costly.
- Lack of flexibility makes it difficult to handle changes in requirements.
- Increased workload on the testing team as all testing is done at once.
- Not suitable for large or dynamic projects where continuous feedback is required.

## Waterfall Testing vs Agile Testing

| Feature | Waterfall Testing | Agile Testing |
| --- | --- | --- |
| Approach | Sequential (phase-by-phase) | Iterative and incremental |
| Testing Time | After development is complete | Continuous testing from start |
| Flexibility | Low | High |
| Customer Involvement | Limited | Continuous |
| Delivery | Single final release | Multiple small releases |
| Documentation | Heavy | Lightweight |
| Defect Detection | Late | Early and continuous |
| Risk Level | High | Low |
| Suitability | Stable requirements | Changing requirements |

Waterfall Testing begins when:

- A
	Requirements are collected
- B
	Design phase starts
- C
	Development is fully completed
- D
	Unit testing starts

A key feature of Waterfall Testing is:

- A
	Continuous testing in iterations
- B
	Parallel development and testing
- C
	Testing as a separate phase
- D
	Daily user feedback

What happens if a test fails in Waterfall Testing?

Which is an advantage of Waterfall Testing?

A major disadvantage of Waterfall Testing is:

- A
	Immediate feedback in each phase
- B
	Low testing workload
- C
	Late detection of defects
- D
	Continuous collaboration

![[sucess-img 95.png|success]]

Quiz Completed Successfully

Score:0/5

Accuracy:0%