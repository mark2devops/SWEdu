---
title: "Verification Vs Validation"
source: "https://www.geeksforgeeks.org/software-engineering/differences-between-verification-and-validation/"
author:
  - "[[GeeksforGeeks]]"
published: 2019-04-18
created: 2026-09-23
description: "Your All-in-One Learning Portal: GeeksforGeeks is a comprehensive educational platform that empowers learners across domains-spanning computer science and programming, school education, upskilling, commerce, software tools, competitive exams, and more."
tags:
  - "clippings"
---
Verification and Validation are two important concepts in software testing used to ensure software quality. Both help in delivering a correct and reliable product, but they differ in approach and purpose. Verification focuses on checking processes, while validation focuses on checking the final product.

- Both are part of quality assurance and testing process
- Help ensure software correctness and reliability
- Used at different stages of development
![[file 2.webp|file]]

Verification Vs Validation

### Verification

Verification is the process of evaluating work products to ensure they meet specified requirements. It checks whether the software is being developed correctly according to design and standards.

- Focuses on process and documentation
- Done without executing the code (static testing)
- Includes reviews, inspections, and walkthroughs

> ****Example:**** Reviewing requirement and design documents of a banking app to ensure all features are correctly planned before development.

### Validation

Validation is the process of evaluating the final product to ensure it meets user needs and expectations. It checks whether the right product has been built.

- Focuses on final product behavior
- Done by executing the code (dynamic testing)
- Includes system testing, user acceptance testing

> ****Example:**** Testing a banking app to verify if users can successfully log in, transfer money, and view transactions.

| Features | Verification | Validation |
| --- | --- | --- |
| Definition | Ensures work products conform to specified requirements | Ensures the final product meets user and stakeholder needs |
| Focus | Requirements, design, and implementation correctness | Functional behavior and intended use |
| Nature | Often analytical and review-based | Typically evaluation- and execution-based |
| Execution | May or may not involve executing software | Usually involves executing the software |
| Methods Used | Methods used in verification are reviews, walkthroughs, inspections and desk-checking. | Functional testing, system testing, acceptance testing |
| Purpose | It checks whether the software conforms to specifications or not. | It checks whether the software meets the requirements and expectations of a customer or not. |
| Bug | Helps detect defects early by checking conformance to requirements and standards. | Detects defects during execution, including functional, usability, and integration issues. |
| Goal | The goal of verification is application and software architecture and specification. | The goal of validation is an actual product. |
| Responsibility | Involves developers, reviewers, QA, and engineers | Involves testers, users, QA teams, and stakeholders. |
| Timing | Performed throughout the software development lifecycle. | Performed throughout the lifecycle when the system or components are executable. |
| Lifecycle | Applied continuously across all lifecycle phases. | Applied iteratively as the system evolves and becomes usable. |
| Error Focus | Verification is for prevention of errors. | Validation is for detection of errors. |
| Stability | Based on defined criteria, standards, and expert judgment. | Based on observed system behavior and acceptance criteria. |

Verification primarily checks:

- A
	User satisfaction
- B
	Code execution results
- C
	Conformance to specifications
- D
	System performance under load

Which activity belongs to Validation?

How does Verification help reduce project cost?

When is Validation mainly performed?

- A
	Are we building the product right?
- B
	Is the code optimized?
- C
	Are we building the right product?
- D
	Is the database normalized?

![[sucess-img 91.png|success]]

Quiz Completed Successfully

Score:0/5

Accuracy:0%