---
title: "Error Handling Software Testing"
source: "https://www.geeksforgeeks.org/software-engineering/error-handling-software-testing/"
author:
  - "[[GeeksforGeeks]]"
published: 2019-07-26
created: 2026-09-23
description: "Your All-in-One Learning Portal: GeeksforGeeks is a comprehensive educational platform that empowers learners across domains-spanning computer science and programming, school education, upskilling, commerce, software tools, competitive exams, and more."
tags:
  - "clippings"
---
Error handling testing is a type of [software testing](https://www.geeksforgeeks.org/software-testing/software-testing-basics/) that is performed to check whether the system is capable of or able to handle the errors that may happen in future. This type of testing is basically performed with the help of both developers and the testers. Error handling testing not only focuses on the determination of error but also focuses on the exception handling. **Objective of Error Handling Testing:** The objective of error handling testing is:

- To check the system ability to handle errors.
- To check the system highest soak point.
- To make sure errors can be handles properly by the system in the future.
- To make system capable of exception handling also.

**Steps involved in the Error Handling testing:** Following are the steps involved in the error handling testing:  
![[Capture88881.jpg]]

1. **Test Environment Set Up:** Test environment is set according to the software testing technique so that the testing process can run smoothly. This step includes planning for the testing. System which is going to be tested is made sure have less significant data as there might be crash problem in the system during testing.
2. **Test Case Generation:** In this software testing test case generation is nothing but making different test cases which may cause error.Suppose a software operates on fractions then setting the denominator of the fractions as zero. Test case generation is associated with the developing team as without knowing the internal code, test cases can't be designed.
3. **Test Case Execution:** After the test case generation, real testing process begins. This is the most prominent part of the testing process. It includes the running the program over the test case generated.
4. **Result and Analysis:** After the execution of the test case, its result is analyzed. It includes the checking of the inconsistency in the expected output for the generated test case. There might be a chance of the program going into an infinite loop which may lead up to software failure.
5. **Re-test:** If the testing is failed then after the analysis once more all the above steps are performed to test the system. It also includes the testing of the system under new test cases generated recently.

**Advantages of Error handling testing:**

- It helps in construction of an error handling powered software.
- It makes the software ready for all circumstances.
- It developes the exception handling technique in the software.
- It helps is maintenance of the software.

**Disadvantages of the Error handling testing**

- It is costly as both the developing and testing team is involved.
- It takes lot of time to perform the testing operations.