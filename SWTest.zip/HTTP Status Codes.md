---
title: "HTTP Status Codes"
source: "https://www.geeksforgeeks.org/computer-networks/what-are-http-status-codes/"
author:
  - "[[GeeksforGeeks]]"
published: 2022-03-26
created: 2026-09-23
description: "Your All-in-One Learning Portal: GeeksforGeeks is a comprehensive educational platform that empowers learners across domains-spanning computer science and programming, school education, upskilling, commerce, software tools, competitive exams, and more."
tags:
  - "clippings"
---
HTTP status codes are standard responses returned by a server to indicate the result of a client’s request. They help developers quickly understand whether a request was successful or if an error occurred.

- Status codes are grouped into five categories (1xx–5xx) based on the type of response.
- They are essential for API testing, debugging, and error handling.
- Each code provides clear communication between the client and the server.
![[http_status_codes.webp|http_status_codes]]

HTTP Status Codes

## Types of HTTP Status Codes

HTTP status codes are categorized into five groups based on the type of response returned by the server. Each category helps quickly identify the result of a request.

### 1xx – Informational

- Indicates that the request has been received and is being processed.
- No final response yet; client should continue.

> Example: 100 Continue

### 2xx – Success

- The request was successfully received, understood, and processed.
- Confirms that the operation was completed correctly.

****Examples:****

> - 200 OK – Request successful
> - 201 Created – New resource created

### 3xx – Redirection

- Additional action required to complete the request.
- The client is redirected to another URL.

****Examples:****

> - 301 Moved Permanently – Resource permanently shifted
> - 302 Found – Temporary redirection

### 4xx – Client Error

- Errors caused by invalid requests from the client side.
- Needs correction before retrying.

****Examples:****

> - 400 Bad Request – Invalid syntax
> - 401 Unauthorized – Authentication required
> - 404 Not Found – Resource not available

### 5xx – Server Error

- The server fails to fulfill a valid request.
- “The issue lies on the server side.

****Examples:****

> - 500 Internal Server Error – Generic server failure
> - 503 Service Unavailable – Server overloaded or down

## Importance of HTTP Status Codes

HTTP status codes reduce the complexity of handling client and server errors. They are also one reason why microservices and HATEOAS are easier to define and implement.

![[wgomvomkwxJan21202152-300x281.webp|HTTP Status]]

HTTP Status

The initial line of the server response indicates the HTTP version and a three-digit status code. Servers provide default error messages such as 404 Not Found or 500 Internal Server Error. Each server (Tomcat, Red Hat, web servers) reserves certain HTTP status codes for built-in functionality. It is also possible to manually configure the status code.

## HTTP Response Status Codes

HTTP response status codes indicate the result of a client’s request and help identify whether the request was successful, redirected, or resulted in an error.

### Informational Responses

Informational response codes indicate that the server has received the request and is continuing to process it.

| Message | Description |
| --- | --- |
| 100 Continue | Indicates that the client should continue with the request. |
| 101 Switching Protocols | Indicates that the server is switching to another protocol. |
| 103 Early Hints | This is used with the Link header, where preloading of resources begins and the server prepares responses. |

### Success Response

Success response codes indicate that the client’s request was successfully received, understood, and processed by the server.

| Message | Description |
| --- | --- |
| 200 OK | Indicates a successful transaction. |
| 202 Accepted | The request has been accepted for processing, but the processing has not yet been completed. |
| 203 Non-Authoritative Information | The information returned is not from the original source of the request. |
| 204 No Content | The request was successful, but no content is returned in the response body. |
| 205 Reset Content | The browser should clear the form used for the transaction to allow new input. |
| 206 Partial Content | The server returns partial data based on the requested range. |

### Redirection Messages

Redirection status codes indicate that additional action is required to complete the request, usually by redirecting the client to another URL.

| Message | Description |
| --- | --- |
| 300 Multiple Choices | The requested URL refers to more than one resource. |
| 301 Moved Permanently | The requested resource has been permanently moved to a new URL. The new location is specified in the `Location` header, and all future requests should use the new URL. |
| 302 Found | The requested resource has been temporarily moved to another URL. |
| 304 Not Modified | The resource has not been modified since the specified date. Therefore, the response body is not sent, and the client should use its local cached copy. |
| 307 Temporary Redirect | The requested URL has moved, but only temporarily. |

### Client Error Responses

Client error status codes indicate that the request contains invalid syntax, missing information, or unauthorized access from the client side.

| Message | Description |
| --- | --- |
| 400 Bad Request | This response code indicates that the server detected a syntax error in the client’s request. |
| 401 Unauthorized | The request failed because proper authentication credentials, such as a username and password, were not provided. |
| 403 Forbidden | The request was denied for a reason that the server does not want to (or cannot) disclose to the client. |
| 404 Not Found | The document at the specified URL does not exist. |
| 405 Method Not Allowed | This code is given with the Allow header and indicates that the method used by the client is not supported  for this URL. |
| 409 Conflict | This code indicates that the request conflicts with another request or with the server’s configuration.  Information about the conflict should be returned in the data portion of the reply. For example, this response  code could be given when a client’s request would cause integrity problems in a database. |
| 429 Too Many Requests | This error occurs when too many requests are made within a certain period of time. |

### Server Error Responses

Server error status codes indicate that the server failed to process a valid request due to internal issues or temporary unavailability.

| Message | Description |
| --- | --- |
| 500 Internal Server Error | This code indicates that the server encountered an unexpected internal error. |
| 502 Bad Gateway | This code indicates that the server (or proxy) encountered invalid responses from another server (or proxy). |
| 503 Service Unavailable | This code means that the service is temporarily unavailable, but should be restored in the future. |
| 504 Gateway Time-out | This code indicates that the server did not receive a timely response from an upstream server or gateway. |

Which category of HTTP status codes indicates that the client must take additional action to complete the request?

- A
	Redirection
- B
	Success
- C
	Client Error
- D
	Server Error

Which HTTP status code is returned when a resource is successfully created on the server?

- A
	200 OK
- B
	201 Created
- C
	204 No Content
- D
	404 Not Found

Which HTTP status code indicates that authentication is required before accessing the resource?

Which HTTP status code indicates that the requested resource could not be found on the server?

Which HTTP status code represents a server-side failure while processing a valid request?

![[sucess-img 35.png|success]]

Quiz Completed Successfully

Score:0/5

Accuracy:0%