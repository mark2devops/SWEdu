---
title: "Cause Effect Graphing in Software Engineering"
source: "https://www.geeksforgeeks.org/software-engineering/cause-effect-graphing-in-software-engineering/"
author:
  - "[[GeeksforGeeks]]"
published: 2020-03-26
created: 2026-09-23
description: "Your All-in-One Learning Portal: GeeksforGeeks is a comprehensive educational platform that empowers learners across domains-spanning computer science and programming, school education, upskilling, commerce, software tools, competitive exams, and more."
tags:
  - "clippings"
---
Cause–Effect Graphing is a [black-box testing](https://www.geeksforgeeks.org/software-testing/software-engineering-black-box-testing/) technique that identifies test cases by showing the relationship between input conditions (causes) and output results (effects). It helps ensure better test coverage and accurate validation of software requirements.

- Represents logical relationships between inputs and outputs.
- Helps generate effective and systematic test cases.
- Reduces missing and duplicate test cases.

### Significance of Cause–Effect Graphing Technique

- Converts software requirements into logical relationships between inputs and outputs.
- Helps understand dependencies among multiple input conditions.
- Supports systematic and structured test case generation.
- Simplifies testing of complex decision-based systems.
- Improves the overall software testing process.

### Cause–Effect Graphing Process

- ****Division of Specification:**** Divide large and complex software requirements into smaller, manageable sections for easier analysis.
- ****Identification of Causes and Effects:**** Identify all input conditions as causes and expected outputs or system actions as effects.
- ****Constructing the Cause–Effect Graph:**** Draw the graph by connecting causes and effects using logical operators such as AND, OR, and NOT, while representing their relationships clearly.
- ****Applying Constraints:**** Add constraints to eliminate invalid or impossible combinations of causes and effects.
- ****Conversion to Decision Table:**** Convert the completed cause–effect graph into a decision table, where each column represents a unique rule.
- ****Deriving Test Cases:**** Generate test cases from each rule in the decision table and verify the expected outputs for every valid input combination.

## Basic Boolean Notations Used in Cause–Effect Graphs

**`**In cause–effect graphs, c represents the cause (input condition) and e represents the effect (output or system behavior)**`******.****

****Identity Function:**** if c is 1, then e is 1. Else e is 0. ![[1406-3.png]]

****NOT Function:**** if c is 1, then e is 0. Else e is 1. ![[223-1.png]]

****OR Function:**** if c1 or c2 or c3 is 1, then e is 1. Else e is 0. ![[3164-1.png]]

****AND Function:**** if both c1 and c2 and c3 is 1, then e is 1. Else e is 0. ![[4108-1.png]]

## Constraints Used in Cause–Effect Graphing

****Exclusive constraint**** or ****E-constraint:**** This constraint exists between causes. It states that either c1 or c2 can be 1, i.e., c1 and c2 cannot be 1 simultaneously. ![[580-1.png]]

****Inclusive constraint**** or ****I-constraint:**** This constraint exists between causes. It states that atleast one of c1, c2 and c3 must always be 1, i.e., c1, c2 and c3 cannot be 0 simultaneously. ![[685.png]]

****One and Only One constraint**** or ****O-constraint:**** This constraint exists between causes. It states that one and only one of c1 and c2 must be 1. ![[757.png]]

****Requires constraint**** or ****R-constraint:**** This constraint exists between causes. It states that for c1 to be 1, c2 must be 1. It is impossible for c1 to be 1 and c2 to be 0. ![[842.png]]

****Mask constraint**** or ****M-constraint:**** This constraint exists between effects. It states that if effect e1 is 1, the effect e2 is forced to be 0.

![[936.png]]

### Example: Online Loan Approval System

****Requirement:**** A loan is approved only if the applicant has sufficient income, a good credit score, and all required documents are verified.

****Causes (Input Conditions)****

- ****c1:**** Income is sufficient
- ****c2:**** Credit score is good
- ****c3:**** Documents are verified

****Effects (Output Conditions)****

- ****e1:**** Loan approved
- ****e2:**** Loan rejected

****Logical Relationship****

- e1 = c1 AND c2 AND c3
- e2 = NOT (c1 AND c2 AND c3)

> ****Explanation:**** The cause–effect graph models the relationship between input conditions and expected outputs using Boolean operators. It is then converted into a decision table to generate comprehensive test cases.

## Tools Used for Cause–Effect Graphing

- ****Microsoft Visio:**** Used to create cause–effect graphs, flowcharts, and logical decision diagrams.
- ****Lucidchart:**** A cloud-based tool for collaboratively designing cause–effect graphs and process diagrams.
- ****draw.io (diagrams.net):**** A free, open-source diagramming tool for creating cause–effect graphs and decision tables.
- ****EdrawMax:**** Provides ready-made templates for creating logical diagrams, flowcharts, and decision models.
- ****IBM Rational Quality Manager:**** Supports test design, test case management, and requirement traceability using graphical models.
- ****TestLink:**** An open-source test management tool used to organize and manage test cases created from cause–effect graph analysis.

## Modern Relevance and Technology

- Widely used in Agile and DevOps projects to validate complex business rules efficiently.
- Supports test automation by helping create logical and comprehensive automated test cases.
- Useful for API testing to verify different input combinations and expected responses.
- Applied in web and mobile application testing for validating workflows and user inputs.
- Helps test AI/ML-based applications by validating decision logic and rule-based outcomes.
- Commonly used in banking, healthcare, insurance, and e-commerce applications where business rules are complex.

## Advantages of Cause–Effect Graphing

- Ensures systematic test case design by mapping input conditions to expected outputs.
- Improves test coverage by validating all important cause-effect relationships.
- Helps identify missing, ambiguous, or conflicting requirements early.
- Reduces redundant test cases by focusing on logical combinations.
- Simplifies testing of complex business rules and decision logic.
- Improves defect detection by testing logical conditions effectively.

## Limitations of Cause–Effect Graphing

- Becomes complex and difficult to manage when there are many input conditions.
- Creating and maintaining the graph can be time-consuming.
- Requires clear, complete, and accurate requirements to be effective..
- Converting large graphs into Decision Tables can be challenging.
- Does not effectively test performance, usability, or other non-functional requirements.
- Requires testers to understand logical relationships and graph construction.

## Symbols Used in Cause–Effect Graph

| Symbol | Meaning | Description |
| --- | --- | --- |
| ****Cause (C)**** | Input Condition | Represents an input or condition that affects the system. |
| ****Effect (E)**** | Output/Action | Represents the result or response produced by the system. |
| ****AND (∧)**** | Logical AND | The effect occurs only when all connected causes are true. |
| ****OR (∨)**** | Logical OR | The effect occurs when at least one connected cause is true. |
| ****NOT (¬)**** | Logical NOT | Reverses the condition; the effect occurs when the cause is false. |
| ****Exclusive OR (XOR)**** | Either One | Only one of the connected causes can be true at a time. |