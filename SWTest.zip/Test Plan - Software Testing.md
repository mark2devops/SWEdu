---
title: "Test Plan - Software Testing"
source: "https://www.geeksforgeeks.org/software-testing/test-plan-software-testing/"
author:
  - "[[GeeksforGeeks]]"
published: 2022-03-22
created: 2026-09-23
description: "Your All-in-One Learning Portal: GeeksforGeeks is a comprehensive educational platform that empowers learners across domains-spanning computer science and programming, school education, upskilling, commerce, software tools, competitive exams, and more."
tags:
  - "clippings"
---
A [****test plan****](https://www.geeksforgeeks.org/software-engineering/software-testing-test-plan-estimates-and-strategy/) is a project-level document that defines what will be tested, how testing will be conducted, and who will perform the testing. It serves as a blueprint for the QA team.

- Prepared by the Test Manager before testing begins
- Guides and coordinates all testing activities
- Shared with stakeholders like BAs, PMs, and the Development Team

## Types of Test Plan

There are three main types of test plans, each focusing on different levels and aspects of testing:

![[master_test_plan.webp|master_test_plan]]

Types of Test Plan

- ****Master Test Plan:**** Defines the overall testing approach for the entire project, including scope, strategy, resources, schedule, and test deliverables.
- ****Specific Test Plan:**** Describes detailed test planning for a particular feature, module, or testing type with focused test objectives and cases.
- ****Phase Test Plan:**** Defines the testing activities for a specific phase of the testing lifecycle such as system testing, integration testing, or user acceptance testing.

## Test Planning Process

Below are the eight steps that can be followed to [write a test plan](https://www.geeksforgeeks.org/software-testing/test-case/)****:****

![[analyze_the_product.webp|analyze_the_product]]

Test Plan creation process

- ****Analyze the Product:**** Study the product requirements to understand its features, functionality, and user expectations before planning testing activities.
- ****Design Test Strategy:**** Define the overall testing approach including testing types, tools, resources, and testing methods.
- ****Design Test Objectives:**** Identify what needs to be tested and define the goals that should be achieved through testing.
- ****Design Test Criteria:**** Set entry and exit conditions to decide when testing can start and when it is considered complete.
- ****Resource Planning:**** Identify and allocate required resources such as testers, tools, devices, and environments for testing.
- ****Plan Test Environment:**** Set up the required hardware, software, and network configuration needed to execute test cases.
- ****Schedule & Estimation:**** Define the timeline for testing activities and estimate the effort required for completion.
- ****Determine Test Deliverables:**** Identify all documents and reports to be produced such as test cases, defect reports, and test summary reports.

## Components and Attributes of Test Plan

A standard test plan typically includes the following components:

![[test_plan_atributes.webp|test_plan_atributes]]

Components and Attributes of Test Plan

- ****Objective:**** Defines testing goals and quality targets.
- ****Scope:**** Specifies in-scope and out-of-scope features.
- ****Test Strategy & Approach:**** Describes testing types, techniques, and execution flow.
- ****Assumptions & Risks:**** Lists assumptions and potential risks with mitigation plans.
- ****Roles & Responsibilities:**** Defines duties of team members involved in testing.
- ****Schedule & Estimation:**** Specifies timelines and effort required.
- ****Test Environment:**** Details hardware, software, and configurations needed.
- ****Defect Management:**** Explains defect tracking and reporting process.
- ****Entry & Exit Criteria:**** Defines conditions to start and complete testing.
- ****Test Automation Plan:**** Identifies scope and tools for automation.
- ****Test Deliverables:**** Lists outputs like test cases, reports, and logs.
- ****Templates & Standards:**** Ensures consistency in documentation.

## Suspension Criteria Workflow in Software Testing

This diagram shows the test suspension and resumption process in software testing. It explains when testing should be paused and when it should be resumed or completed.

![[define_suspension_criteria.webp|define_suspension_criteria]]

Example of Test Plan

- ****Define Suspension Criteria:**** Before testing starts, conditions are defined that determine when testing should be paused (e.g., critical bugs, environment failure).
- ****Execute Test Cases:**** Test cases are run as part of the normal testing process.
- ****Suspension Criteria Met?**** – A decision point checks whether the defined suspension conditions have occurred.  
	No -> Loop back to Execute Test Cases (testing continues normally).  
	Yes -> Move to Suspend the Testing (testing is halted due to blocking issues).
- ****Developer Fix the Fail Cases?:**** A decision point checking whether developers have resolved the defects that triggered suspension.  
	No -> Loop back to Suspend the Testing (testing remains paused).  
	Yes -> Loop back to Execute Test Cases (testing resumes).
- ****Finish the Testing:**** Reached only when suspension criteria are never triggered, meaning testing is completed successfully without blocking issues.

## Roles and Responsibilities in Test Plan

- ****Test Manager / Test Lead:**** Prepares and manages the test plan, defines strategy, scope, and ensures proper allocation of resources and timelines.
- ****Test Engineer / QA Tester:**** Executes test cases, reports defects, and verifies fixes to ensure the application meets quality standards.
- ****Business Analyst:**** Provides detailed requirements and helps design test scenarios based on business needs and user expectations.
- ****Developer:**** Fixes reported defects, supports testers in resolving technical issues, and performs unit testing before release.
- ****Project Manager:**** Monitors project progress, coordinates between teams, and ensures timely delivery within scope and schedule.
- ****Client / Stakeholder:**** Reviews and approves the test plan and validates the product during UAT to ensure it meets business requirements.

## Best Practices

- ****Understand Requirements:**** Clearly analyze functional and non-functional needs with stakeholder input.
- ****Define Objectives and Scope:**** Specify testing goals and clearly mark in-scope and out-of-scope areas.
- ****Develop a Test Strategy:**** Choose appropriate testing types, techniques, and tools.
- ****Create Strong Test Cases:**** Cover all major scenarios and maintain requirement traceability.
- ****Prepare Test Environment:**** Ensure proper setup that mirrors production.
- ****Plan Data and Reporting:**** Use realistic test data and establish clear reporting and defect tracking processes.

## Test Strategy vs Test Plan

| Test Strategy | Test Plan |
| --- | --- |
| High-level document defining overall testing approach and objectives. | Detailed document defining specific testing activities for a project. |
| Explains what and why of testing. | Explains how, when, and who will test. |
| Organization-wide and broad in scope. | Project-specific and focused in scope. |
| Conceptual and methodology-oriented. | Practical and execution-oriented. |
| Created by senior management or test architects. | Created by Test Manager or Test Lead. |
| Long-term and relatively stable. | Short-term and updated as project progresses. |
| Provides general testing guidelines. | Includes detailed test cases, schedule, and resources. |
| Reviewed by stakeholders and senior management. | Used by QA team, developers, and project team. |

Who typically prepares the Test Plan for a project?

- A
	Developer
- B
	End User
- C
	Test Manager
- D
	Database Admin

Which section defines conditions to stop or complete testing?

- A
	Risk Analysis
- B
	Entry and Exit Criteria
- C
	Test Deliverables
- D
	Assumptions

What is the main purpose of defining “In-Scope” and “Out-of-Scope” in a Test Plan?

Which document is considered a high-level testing roadmap for the entire project?

In a Test Plan, risk mitigation mainly focuses on:

- A
	Ignoring possible failures
- B
	Reducing testing time
- C
	Preparing backup solutions for potential issues
- D
	Increasing manual testing

![[sucess-img 83.png|success]]

Quiz Completed Successfully

Score:0/5

Accuracy:0%