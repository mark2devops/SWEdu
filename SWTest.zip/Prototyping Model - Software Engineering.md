---
title: "Prototyping Model - Software Engineering"
source: "https://www.geeksforgeeks.org/software-engineering/software-engineering-prototyping-model/"
author:
  - "[[GeeksforGeeks]]"
published: 2018-04-05
created: 2026-09-23
description: "Your All-in-One Learning Portal: GeeksforGeeks is a comprehensive educational platform that empowers learners across domains-spanning computer science and programming, school education, upskilling, commerce, software tools, competitive exams, and more."
tags:
  - "clippings"
---
****Prototyping Model**** is a way of developing software where an early version, or prototype, of the product is created and shared with users for feedback.

The Prototyping Model concept is described below:

Table of Content

## What is Prototyping Model?

The Prototyping Model is one of the most popularly used [****Software Development Life Cycle Models (SDLC models)****](https://www.geeksforgeeks.org/software-engineering/software-development-life-cycle-sdlc/). This model is used when the customers do not know the exact project requirements beforehand.

In this model, a prototype of the end product is first developed, tested, and refined as per customer feedback repeatedly till a final acceptable prototype is achieved which forms the basis for developing the final product.

![[prototype-model-concepts.gif|prototype-model-concepts]]

Prototyping Model-Concept

In this process model, the system is partially implemented before or during the analysis phase thereby allowing the customers to see the product early in the life cycle. The process starts by interviewing the customers and developing the incomplete high-level paper model.

This document is used to build the initial prototype supporting only the basic functionality as desired by the customer. Once the customer figures out the problems, the prototype is further refined to eliminate them. The process continues until the user approves the prototype and finds the working model to be satisfactory.

## Phases of Prototyping Model

Prototyping Model has six phases as follows:

![[prototyping-model-phases.gif|prototyping-model-phases]]

Prototyping Model Phases

### 1\. Requirements gathering and analysis

Requirement analysis is the first step in developing a prototyping model. During this phase, the system’s desires are precisely defined. During the method, system users are interviewed to determine what they expect from the system.

### 2\. Quick design

The second phase could consist of a preliminary design or a quick design. During this stage, the system’s basic design is formed. However, it is not a complete design. It provides the user with a quick overview of the system. The rapid design aids in the development of the prototype.

### 3\. Build a Prototype

During this stage, an actual prototype is intended to support the knowledge gained from quick design. It is a small low-level working model of the desired system.

### 4\. Initial user evaluation

The proposed system is presented to the client for preliminary testing at this stage. It is beneficial to investigate the performance model’s strengths and weaknesses. Customer feedback and suggestions are gathered and forwarded to the developer.

### 5\. Refining prototype

If the user is dissatisfied with the current model, you may want to improve the type that responds to user feedback and suggestions. When the user is satisfied with the upgraded model, a final system based on the approved final type is created.

### 6\. Implement Product and Maintain

The final system was fully tested and distributed to production after it was developed to support the original version. To reduce downtime and prevent major failures, the programmer is run on a regular basis.

## Types of Prototyping Models

There are four types of Prototyping Models, which are described below.

### 1\. Rapid Throwaway Prototyping

- This technique offers a useful method of exploring ideas and getting customer feedback for each of them.
- In this method, a developed prototype need not necessarily be a part of the accepted prototype.
- Customer feedback helps prevent unnecessary design faults and hence, the final prototype developed is of better quality.

### 2\. Evolutionary Prototyping

- In this method, the prototype developed initially is incrementally refined based on customer feedback till it finally gets accepted.
- In comparison to Rapid Throwaway Prototyping, it offers a better approach that saves time as well as effort.
- This is because developing a prototype from scratch for every iteration of the process can sometimes be very frustrating for the developers.

### 3\. Incremental Prototyping

- In this type of incremental prototyping, the final expected product is broken into different small pieces of prototypes and developed individually.
- In the end, when all individual pieces are properly developed, then the different prototypes are collectively merged into a single final product in their predefined order.
- It's a very efficient approach that reduces the complexity of the development process, where the goal is divided into sub-parts and each sub-part is developed individually.
- The time interval between the project's beginning and final delivery is substantially reduced because all parts of the system are prototyped and tested simultaneously.
- Of course, there might be the possibility that the pieces just do not fit together due to some lack of ness in the development phase – this can only be fixed by careful and complete plotting of the entire system before prototyping starts.

### 4\. Extreme Prototyping

This method is mainly used for web development. It consists of three sequential independent phases:

- In this phase, a basic prototype with all the existing static pages is presented in HTML format.
- In the 2nd phase, Functional screens are made with a simulated data process using a prototype services layer.
- This is the final step where all the services are implemented and associated with the final prototype.

This Extreme Prototyping method makes the project cycling and delivery robust and fast and keeps the entire developer team focused and centralized on product deliveries rather than discovering all possible needs and specifications and adding necessitated features.

## Advantages of Prototyping Model

- The customers get to see the partial product early in the life cycle. This ensures a greater level of customer satisfaction and comfort.
- New requirements can be easily accommodated as there is scope for refinement.
- Missing functionalities can be easily figured out.
- Errors can be detected much earlier thereby saving a lot of effort and cost, besides enhancing the quality of the software.
- The developed prototype can be reused by the developer for more complicated projects in the future.
- Flexibility in design.
- Early feedback from customers and stakeholders can help guide the development process and ensure that the final product meets their needs and expectations.
- Prototyping can be used to test and validate design decisions, allowing for adjustments to be made before significant resources are invested in development.
- Prototyping can help reduce the risk of project failure by identifying potential issues and addressing them early in the process.
- Prototyping can facilitate communication and collaboration among team members and stakeholders, improving overall project efficiency and effectiveness.
- Prototyping can help bridge the gap between technical and non-technical stakeholders by providing a tangible representation of the product.

## Disadvantages of the Prototyping Model

- Costly concerning time as well as money.
- There may be too much variation in requirements each time the prototype is evaluated by the customer.
- Poor Documentation due to continuously changing customer requirements.
- It is very difficult for developers to accommodate all the changes demanded by the customer.
- There is uncertainty in determining the number of iterations that would be required before the prototype is finally accepted by the customer.
- After seeing an early prototype, the customers sometimes demand the actual product to be delivered soon.
- Developers in a hurry to build prototypes may end up with sub-optimal solutions.
- The customer might lose interest in the product if he/she is not satisfied with the initial prototype.
- The prototype may not be scalable to meet the future needs of the customer.
- The prototype may not accurately represent the final product due to limited functionality or incomplete features.
- The focus on prototype development may shift away from the final product, leading to delays in the development process.
- The prototype may give a false sense of completion, leading to the premature release of the product.
- The prototype may not consider technical feasibility and scalability issues that can arise during the final product development.
- The prototype may be developed using different tools and technologies, leading to additional training and maintenance costs.
- The prototype may not reflect the actual business requirements of the customer, leading to dissatisfaction with the final product.

## Applications of Prototyping Model

- The Prototyping Model should be used when the requirements of the product are not clearly understood or are unstable.
- The prototyping model can also be used if requirements are changing quickly.
- This model can be successfully used for developing user interfaces, high-technology software-intensive systems, and systems with complex algorithms and interfaces.
- The prototyping Model is also a very good choice to demonstrate the technical feasibility of the product.

## Conclusion

****Prototyping Model**** plays an important role in developing and redesign the product with clear understanding, for more understanding about all models do refer " [Top SDLC models](https://www.geeksforgeeks.org/software-engineering/top-8-software-development-models-used-in-industry/) ".