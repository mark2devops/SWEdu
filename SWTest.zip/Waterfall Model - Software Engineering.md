---
title: "Waterfall Model - Software Engineering"
source: "https://www.geeksforgeeks.org/software-engineering/waterfall-model/"
author:
  - "[[GeeksforGeeks]]"
published: 2018-03-18
created: 2026-09-23
description: "Your All-in-One Learning Portal: GeeksforGeeks is a comprehensive educational platform that empowers learners across domains-spanning computer science and programming, school education, upskilling, commerce, software tools, competitive exams, and more."
tags:
  - "clippings"
---
Waterfall Model is a traditional software development approach that follows a linear, step-by-step process where each phase is completed before moving to the next. Its features are:

- Follows a sequential approach where each phase is completed before the next begins.
- Emphasises detailed documentation at every stage of development.
- Ensures quality through proper testing and verification in each phase.
- Involves thorough planning of scope, schedule, and deliverables.
![[waterfall_methodology 1.webp|waterfall_methodology]]

Phases of Waterfall Model

## Phases of Waterfall Model

Classical Waterfall Model divides the life cycle into a set of phases. The development process can be considered as a sequential flow in the waterfall. The different sequential phases of the classical waterfall model are as follows:

### 1\. Requirements Analysis and Specification

The first stage focuses on clearly understanding and documenting the customer’s needs.

- ****Requirement Gathering and Analysis:**** Customer requirements are collected and carefully examined to remove errors, confusion, and inconsistencies.
- ****Requirement Specification:**** The approved requirements are documented in the [Software Requirement Specification (SRS)](https://www.geeksforgeeks.org/software-engineering/software-requirement-specification-srs-format/), which serves as a formal agreement between the customer and the development team.

### 2\. Design

The requirements specified in the SRS are converted into a system design that can be implemented in code.

- ****High-Level Design (HLD):**** Defines the overall system architecture, major components, and their interactions.
- ****Low-Level Design (LLD):**** Provides detailed design of each component, including logic and data flow, to guide developers during coding.
- All designs are documented in the [Software Design Document (SDD)](https://www.geeksforgeeks.org/software-engineering/design-documentation-in-software-engineering/).

### 3\. Development

This phase involves converting the design into actual working software.

- Developers write source code based on the design documents.
- Suitable programming languages and tools are used.
- [Unit testing](https://www.geeksforgeeks.org/software-testing/unit-testing-software-testing/) is performed to verify that each module works correctly on its own.

### 4\. Testing and Deployment

It is ensured that the integrated software functions correctly and is successfully delivered for real world use.

****Testing:**** After unit testing, software modules are integrated and integration testing is performed. Once integration is complete, system testing is carried out to verify the entire system.

- [****Alpha Testing****](https://www.geeksforgeeks.org/software-testing/alpha-testing-software-testing/)****:**** Performed by the development team.
- [****Beta Testing****](https://www.geeksforgeeks.org/software-engineering/beta-testing-software-testing/)****:**** Performed by selected end users.
- [****Acceptance Testing****](https://www.geeksforgeeks.org/software-engineering/acceptance-testing-software-testing/)****:**** Performed by the customer to approve the software.

****Deployment:**** After successful testing, the software is deployed to a live environment for end users. This phase includes environment setup, user training, and final checks to ensure smooth operation in real world conditions.

### 5\. Maintenance

Maintenance ensures the software continues to function effectively after deployment.

- ****Corrective Maintenance:**** Fixes errors found after release.
- ****Perfective Maintenance:**** Enhances features based on user needs.
- ****Adaptive Maintenance:**** Adapts software to new environments.
- ****Preventive Maintenance:**** Prevents future issues through improvements.

## Use Cases

- ****Well-Defined Requirements:**** Requirements are clear, stable, and fully documented before development begins.
- ****Minimal Changes Expected:**** The project scope is unlikely to change during development.
- ****Small to Medium-Sized Projects:**** Suitable for projects with limited complexity and a clear development path.
- ****Predictable and Low Risk:**** Risks are known, manageable, and can be addressed early in the development cycle.
- ****Strict Regulatory Compliance:**** Ideal when detailed documentation and adherence to standards or regulations are mandatory.
- ****Client Prefers a Sequential Approach:**** Best when the client wants a step-by-step, linear development process.
- ****Limited Resources:**** Works well when resources are limited and need careful planning and allocation.

### Example of Waterfall Model

A real-world example of the Waterfall Model using an Online Food Delivery System.

1. ****Analysis:**** Customer and business requirements are gathered. This includes understanding features such as user registration, restaurant listing, menu display, order placement, payment methods, delivery tracking, and customer support.
2. ****Design:**** Based on the requirements, the system design is created. This includes deciding the app architecture, database design, user interface layout, payment gateway integration, and security measures. The goal is to ensure smooth ordering, fast performance, and secure transactions.
3. ****Development****: Modules such as login, restaurant search, order processing, payment, and notifications are developed. Each feature is built exactly as planned in earlier phases.
4. ****Testing:**** Once development is complete, the system is tested to ensure everything works correctly. This includes testing order placement, payment processing, delivery tracking, and app performance. Bugs and errors are identified and fixed before release.
5. ****Maintenance:**** After deployment, the app is maintained to fix issues, improve performance, and add minor updates. This may include adding new restaurants, improving delivery tracking, updating security features, or supporting new payment methods.

## Advantages

- Easy to understand and simple to follow.
- Follows a clear step-by-step development process.
- Well-defined stages reduce confusion.
- Clear milestones make progress tracking easier.
- Strong documentation throughout the project.
- Encourages disciplined development practices.
- Suitable for small projects with stable requirements.

Which best describes the Waterfall Model?

- A
	Iterative and flexible
- B
	Random development process
- C
	Linear and sequential development
- D
	Prototype-based development

Which phase of the Waterfall Model focuses on understanding and documenting user needs?

Which document is created during the Design phase?

Which testing is performed by end users before final acceptance?

The Waterfall Model is best suited for which type of project?

![[sucess-img 94.png|success]]

Quiz Completed Successfully

Score:0/5

Accuracy:0%