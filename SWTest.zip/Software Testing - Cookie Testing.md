---
title: "Software Testing - Cookie Testing"
source: "https://www.geeksforgeeks.org/software-testing/software-testing-cookie-testing/"
author:
  - "[[GeeksforGeeks]]"
published: 2022-08-21
created: 2026-09-23
description: "Your All-in-One Learning Portal: GeeksforGeeks is a comprehensive educational platform that empowers learners across domains-spanning computer science and programming, school education, upskilling, commerce, software tools, competitive exams, and more."
tags:
  - "clippings"
---
Cookie testing is the type of software testing that checks the cookie created in the web browser. A cookie is a small piece of information that is used to track where the user navigated throughout the pages of the website.

The following topics of cookie testing will be discussed here:

1. **What are Cookies?**
2. **Where cookies are stored?**
3. **Why do we Need Cookie Testing?**
4. **How to test cookies on the website?**
5. **Plugin to test cookies**
6. **Cookie Modification**
7. **Cookie vs session**
8. **Test cases for web application cookie testing**

### What are Cookies?

Cookies are small text files with a unique ID stored on your system by a website. Cookies are a storage facility of web browsers, it stores- browsing details like preferences, customizations, login ID, etc. specific to that website. A cookie enables websites to provide a customized experience.

There are two types of cookies:

- **Session Cookies:** These are the cookies that are valid only till the session last. This means they are active only till the time the browser that triggered them remains open.
- **Persistent Cookies:** These cookies are valid beyond the current session. These are written permanently on the user's machine and remain there for months or years.

### Where are Cookies Stored?

Cookies are stored in different locations, depending upon the browser and operating system but generally, cookies are stored in browser cache memory. When a user visits the cookie-enabled website, the website drops cookies into the browser to collect data. For example, Google Chrome stores cookies in **%LocalAppData%\\Google\\Chrome\\User Data\\Default\\cookies**.

### Why Do We Need Cookie Testing?

Below are some of the reasons why we need cookie testing:

- Cookie testing is required to check if data is being sent back to the server or not.
- Cookies should be tested as they store very important information within them.
- Cookie plays an essential role in website functioning.

### How to Test Cookies in Website?

Below are the steps to test cookies in website:

![[Screenshot36-768x429.png]]

1. **Disable Cookies:** Check website functionality by disabling the cookies. Sometimes the website will crash or perform weirdly. By disabling the cookies, there should not be any page crashes and users should be able to access the website without crashes or data corruption so that users can access the website even after disabling cookies.
2. **Corrupting cookies:** Check the behavior of web applications by manually corrupting the cookies. This scenario is valid when cookies store information like user names, passwords, etc. Edit the cookies in notepad, and change the parameters to some other values like cookie expiry date, cookie content, cookie name, etc. After editing, an alert message should be displayed to the user and the user should not be able to access other users' accounts. This test is important from the point of view of banking, financial, and investment applications.
3. **Rejecting Cookies:** Delete the cookies completely. After removing the cookies, test the website. If there is not any error then it is perfectly okay else there is a need to improve cookies. The browser should work as expected and provide all the information as always. Cookies are not always mandatory.
4. **Cross Browser testing:** A cookie when stored on one browser should not work on any other browser. It should be operated only on the browser where it was created.
5. **Access to cookies:** Cookies written by one website should not be accessible by others.
6. **Encryption of Cookies:** All sensitive information stored in the cookies file of the website should be encrypted.
7. **Testing with different browser settings:** Testing should be done properly to check that website is working well with different browser settings.
8. **Categorize cookies separately:** Cookies should not be kept in the same category as viruses, spam, or spyware.

### Plugin to Test Cookies

There are multiple extensions or plugins that can be used to test or edit cookies. The most popular plugins are:

- **EditThisCookie:** Cookies editor and a google chrome extension.
- **Check my cookies:** Checks cookies and tells whether the website is safe or not.

### Cookie Modification

One can modify the cookies of any website of any browser. Here is an attempt to modify the cookies of the GeeksforGeeks website on the chrome browser. Following are the steps to modify or edit the cookie using the "EditThisCookie" plugin for Chrome:

**Step 1:** Download EditThisCookie extension from chrome web store

![[abc-660x363.png|Download extension on chrome]]

**Step 2:** Open "GeeksforGeeks Data Structure" and make sure you have logged in(You can open any website). Now click on the cookie icon

![[abc12-660x372.jpg|GeeksforGeeks Page]]

**Step 3:** To edit or delete any cookie, click on the cookie

![[abc2-660x372.png|Click on cookie]]

**Step 4:** Now you can delete the cookie or edit the value of the cookie

![[abc2-660x372.jpg|Delete/ Edit cookie]]

### Cookie vs Session

Below are some of the differences between Cookie and Session:

| **Cookie** | **Session** |
| --- | --- |
| Cookies are stored in the browser as a text file that contains user information | Sessions are stored on the server side which contains user information |
| Cookie ends, depending on the lifetime you set for it. | A session ends when a user closes his browser |
| We can access cookies values easily, so it is less secure | We can't access session values easily, so it is highly secure |
| The official maximum cookie size is 4KB | There is no limit on the size of the session |
| Cookies are not dependent on the session | The session is dependent on cookie |
| Cookies can only store string | Session stores object |
| There is no function name unsetcookie() | There is a function session\_destroy() that is used to destroy all registered data or unset some registered data |
| The setcookie() function must appear before the \<html> tag | The session\_start() function must be there before any \<html> tag |

### Test cases for web application Cookie testing

1. Cookies should be stored at different locations for different browsers.
2. Cookies stored by one website should not be accessible by other websites.
3. As a cookie privacy policy, cookies should not store any personal or sensitive data like credit card numbers, or login credentials.
4. No overuse of cookies.
5. Websites should ask for explicit consent by providing options to accept cookies "I accept" and reject cookies "Reject". If a user rejects cookies, only necessary cookies and trackers can be placed by the website.
6. Users must have an easy option to withdraw their consent to cookies at any time.
7. Websites should inform users about the purpose of tracking cookies before they give consent. Explain, in a clear and comprehensive manner, how cookies work and what you use them for.