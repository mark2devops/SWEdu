---
title: "Severity in Testing Vs Priority in Testing"
source: "https://www.geeksforgeeks.org/software-testing/severity-in-testing-vs-priority-in-testing/"
author:
  - "[[GeeksforGeeks]]"
published: 2019-08-07
created: 2026-09-23
description: "Your All-in-One Learning Portal: GeeksforGeeks is a comprehensive educational platform that empowers learners across domains-spanning computer science and programming, school education, upskilling, commerce, software tools, competitive exams, and more."
tags:
  - "clippings"
---
Severity and Priority help software teams evaluate defects and decide the most effective approach for fixing them. These concepts support efficient defect management, improve release planning, and ensure that critical issues are resolved at the right time.

- Helps classify defects based on their impact and urgency.
- Supports better defect management and release planning.
- Ensures critical issues are addressed before less important ones.

## Severity

Severity defines the impact of a defect on the application's functionality. The greater the impact on the system, the higher the severity. It is typically assigned by the QA or Test Engineer.

### Types of Severity

- ****Critical:**** System crash or complete failure; further testing cannot continue.
- ****Major:**** A major feature fails, but the rest of the application remains usable.
- ****Medium:**** A functional issue with a temporary workaround available.
- ****Low:**** A minor issue with little or no impact on functionality.

## Priority

Priority defines the urgency of fixing a defect. It determines the order in which defects should be resolved and is usually assigned by the Project Manager, Product Owner, or Business Team.

### Types of Priority

- ****High:**** Must be fixed immediately because it significantly affects business functionality or user experience.
- ****Medium:**** Should be fixed during the normal development cycle.
- ****Low:**** Can be fixed in a future release with minimal business impact.

## Severity Vs Priority

The following table compares Severity and Priority based on their purpose, impact, and usage in software testing.

| Basis | Severity | Priority |
| --- | --- | --- |
| Definition | Severity refers to the impact of a defect on the system functionality. | Priority refers to how quickly a defect should be fixed. |
| Focus | Focuses on system functionality and technical impact. | Focuses on business needs and urgency. |
| Decided By | Usually determined by the QA/Test Engineer. | Usually determined by the Project Manager or Business Team. |
| Concerned With | Degree of damage caused by the defect. | Order in which the defect should be resolved. |
| Types | Critical, Major, Medium, Low | High, Medium, Low |
| Effect on Application | Measures how badly the application is affected. | Measures the importance of fixing the issue quickly. |
| Relation to Users | May or may not directly affect users immediately. | Mostly based on customer or business impact. |
| Example | Application crashes during payment processing. | Typo on homepage logo before product launch. |