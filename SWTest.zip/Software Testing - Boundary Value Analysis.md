---
title: "Software Testing - Boundary Value Analysis"
source: "https://www.geeksforgeeks.org/software-testing/software-testing-boundary-value-analysis/"
author:
  - "[[GeeksforGeeks]]"
published: 2022-03-23
created: 2026-09-23
description: "Your All-in-One Learning Portal: GeeksforGeeks is a comprehensive educational platform that empowers learners across domains-spanning computer science and programming, school education, upskilling, commerce, software tools, competitive exams, and more."
tags:
  - "clippings"
---
Boundary Value Analysis (BVA) is a [black-box testing technique](https://www.geeksforgeeks.org/software-testing/software-engineering-black-box-testing/) that focuses on testing the boundary values (edges) of valid and invalid input ranges. It helps identify errors that commonly occur at the limits of input conditions.

- BVA focuses on boundary values of valid and invalid input ranges.
- It tests values at the minimum, just above minimum, maximum, just below maximum, and sometimes outside the valid range.
- It is commonly used with Equivalence Partitioning to improve test coverage.

## For Each Input Variable, BVA Tests

For each input variable, Boundary Value Analysis (BVA) tests values at and around the boundary limits to ensure that the system behaves correctly under edge conditions.

- Minimum boundary value
- Just above the minimum value
- Maximum boundary value
- Just below the maximum value
- Invalid values outside the valid range
![[419253543.webp|419253543]]

### Example

Consider a system that accepts ages from 18 to 56.

- Valid Test Cases: Valid test cases include values between 18 and 56.
- Invalid Test Cases: It include values less than 18 or greater than 56.

<table><thead><tr><th colspan="3"><p>Boundary Value Analysis ( Age accepts values from 18 to 56 )</p></th></tr></thead><tbody><tr><td><p>Invalid</p><p>(min-1)</p></td><td><p>Valid</p><p>(min, min + 1, nominal, max - 1, max)</p></td><td><p>Invalid</p><p>(max + 1)</p></td></tr><tr><td><p>17</p></td><td><p>18, 19, 37, 55, 56</p></td><td><p>57</p></td></tr></tbody></table>

## Types of BVA

Boundary Value Analysis (BVA) is a testing technique that focuses on checking values at the boundaries of input ranges. It helps detect errors that commonly occur at the edges of valid input limits.

### Normal BVA

Tests only valid boundary values within the specified input range, ensuring that the system behaves correctly at the minimum, maximum, and values just inside the acceptable limits.

- Covers minimum, maximum, and values just inside the valid range to ensure correct system behavior.
- Focuses on verifying that the application works properly for all valid boundary conditions.

### Robust BVA

Tests both valid and invalid boundary values around the limits, including values just below the minimum and just above the maximum, to verify how the system handles out-of-range inputs.

- Includes values just below minimum and above maximum to check system response for invalid inputs.
- Helps identify errors and exceptions that occur due to out-of-range values.

### Worst Case BVA

Tests combinations of boundary values for multiple input variables, ensuring that the system can handle different boundary conditions together and behave correctly under combined input scenarios.

- Considers all possible combinations of minimum and maximum values across inputs.
- Ensures the system can handle multiple boundary conditions simultaneously without failure.

### Robust Worst Case BVA

Combines worst case and robust testing approaches to achieve maximum coverage by testing both valid and invalid boundary value combinations across multiple input variables.

- Tests combinations including both valid and invalid boundary values across inputs.
- Provides thorough validation by covering extreme and out-of-bounds scenarios.

## Single Fault Assumption

Single Fault Assumption is a concept used in Boundary Value Analysis where only one input variable is tested at its boundary values while all other variables are kept at normal (nominal) values.

It is based on the assumption that most defects occur due to a single faulty condition at a time.

- Reduces number of test cases
- Focuses on one variable at a time
- Other variables remain nominal
- Formula: 4n + 1 test cases

****Example:**** Consider a program for determining the previous date.

Input: Day: 1–31, Month: 1–12, Year: 1900–2000

Taking the year as a Single Fault Assumption i.e. year will be having values varying from 1900 to 2000 and others will have nominal values.

| ****Test Cases**** | ****Month**** | ****Day**** | ****Year**** | ****Output**** |
| --- | --- | --- | --- | --- |
| 1 | 6 | 15 | 1900 | 14 June 1900 |
| 2 | 6 | 15 | 1901 | 14 June 1901 |
| 3 | 6 | 15 | 1960 | 14 June 1960 |
| 4 | 6 | 15 | 1999 | 14 June 1999 |
| 5 | 6 | 15 | 2000 | 14 June 2000 |

Taking Day as Single Fault Assumption i.e. Day will be having values varying from 1 to 31 and others will have nominal values.

| ****Test Case**** | ****Month**** | ****Day**** | ****Year**** | ****Output**** |
| --- | --- | --- | --- | --- |
| 6 | 6 | 1 | 1960 | 31 May 1960 |
| 7 | 6 | 2 | 1960 | 1 June 1960 |
| 8 | 6 | 30 | 1960 | 29 June 1960 |
| 9 | 6 | 31 | 1960 | Invalid day |

Taking Month as Single Fault Assumption i.e. Month will be having values varying from 1 to 12 and others will have nominal values.

| ****Test Case**** | ****Month**** | ****Day**** | ****Year**** | ****Output**** |
| --- | --- | --- | --- | --- |
| 10 | 1 | 15 | 1960 | 14 Jan 1960 |
| 11 | 2 | 15 | 1960 | 14 Feb 1960 |
| 12 | 11 | 15 | 1960 | 14 Nov 1960 |
| 13 | 12 | 15 | 1960 | 14 Dec 1960 |

For n variables, a maximum of 4n + 1 test cases are required. Therefore, for n = 3, the maximum number of test cases is: 4 × 3 + 1 = 13.

## Real-World Applications

Boundary Value Analysis is widely used to detect errors at input limits and verify system behavior at boundary conditions.

- It is used for checking input fields such as age, password length, and phone numbers.
- It helps validate product quantity limits and price ranges in e-commerce systems.
- It is useful for testing transaction limits and account balance boundaries in banking applications.
- It is used to verify username and password length constraints in login systems.

## Advantages of BVA

Boundary Value Analysis (BVA) is an effective testing technique used to identify errors at the boundaries of input values. It improves testing efficiency by focusing on critical edge cases.

- Detects boundary errors where defects are most likely to occur.
- Reduces the number of test cases compared to exhaustive testing.
- Improves test coverage by focusing on edge values.
- Simple and easy to apply in most testing scenarios.

## Best Practices for Effective BVA

Boundary Value Analysis is most effective when the input boundaries are clearly identified and tested properly. It helps detect errors at edge values and improves overall test coverage.

- Identify the correct minimum and maximum input limits.
- Test both valid and invalid values around the boundaries.
- Include values just inside and just outside the valid range.

Boundary Value Analysis mainly targets:

- A
	Internal code structure
- B
	Middle values of input range
- C
	Edge values of input partitions
- D
	Database performance

For an input range 18 to 56, which value represents an invalid boundary test case?

- A
	18
- B
	37
- C
	56
- D
	57

According to the Single Fault Assumption, the maximum number of test cases for 3 variables is:

- A
	9
- B
	10
- C
	13
- D
	15

Why are defects more likely at boundary values?

Combining Equivalence Partitioning with BVA mainly helps to:

- A
	Increase documentation
- B
	Eliminate automation
- C
	Reduce test cases without losing effectiveness
- D
	Avoid invalid inputs

![[sucess-img 62.png|success]]

Quiz Completed Successfully

Score:0/5

Accuracy:0%