---
title: "Designing Authentication System | System Design"
source: "https://www.geeksforgeeks.org/system-design/designing-authentication-system-system-design/"
author:
  - "[[GeeksforGeeks]]"
published: 2024-01-19
created: 2026-09-23
description: "Your All-in-One Learning Portal: GeeksforGeeks is a comprehensive educational platform that empowers learners across domains-spanning computer science and programming, school education, upskilling, commerce, software tools, competitive exams, and more."
tags:
  - "clippings"
---
Designing an Authentication System means building a secure system that verifies a user's identity and controls access to applications or services. In an interview, the main focus is on secure login, session management, token handling, and protecting user credentials.

- Users should be able to register, log in, log out, and securely access protected resources.
- The system should support secure password storage, sessions or tokens, multi-factor authentication, and protection against common authentication attacks.

## 1\. Problem Statement

We need to design an Authentication System that securely verifies users before allowing them to access protected services. The system should work reliably across web and mobile applications and support a large number of login requests.

- The system should support registration, login, logout, password reset, and session management.
- It should securely store credentials, prevent unauthorized access, and handle expired, stolen, or invalid sessions correctly.

## 2\. System Requirements

Before designing the Authentication System, we need to identify its functional and non-functional requirements. These requirements define what authentication features the system should provide and how securely and reliably they should work.

### Functional Requirements

- Users should be able to register using email, phone number, or username.
- Users should be able to log in using valid credentials.
- Users should be able to log out from the current session.
- The system should support password reset and account recovery.
- The system should securely manage user sessions or authentication tokens.
- Users should be able to enable Multi-Factor Authentication (MFA).
- The system should support email or phone verification.
- Users should be able to view and revoke active sessions from other devices.
- The system should lock or temporarily block accounts after multiple failed login attempts.
- The system should support role-based access such as `USER`, `ADMIN`, or other application-specific roles.

### Non-Functional Requirements

- ****Security:**** Passwords, tokens, and sensitive authentication data must be protected using strong encryption and hashing.
- ****Availability:**** Authentication services should remain available because users cannot access the application if login fails.
- ****Scalability:**** The system should handle millions of users and large numbers of concurrent login requests.
- ****Low Latency:**** Login and token validation should complete quickly.
- ****Reliability:**** Sessions and authentication states should remain consistent even during server failures.
- ****Fault Tolerance:**** Failure of one authentication server should not make the complete system unavailable.
- ****Auditability:**** Important events such as login attempts, password changes, MFA changes, and suspicious activities should be recorded.
- ****Privacy:**** Personal and authentication-related information should only be accessible to authorized services.

## 3\. Capacity Estimation

Before designing the Authentication System, we estimate the expected number of users, login requests, active sessions, and storage. These estimates help us decide the number of authentication servers, cache size, and database capacity.

### Assumptions

| ****Parameter**** | ****Assumption**** |
| --- | --- |
| Registered Users | 100 Million |
| Daily Active Users | 20 Million |
| Login Requests per Day | 50 Million |
| Peak Login Requests | 10,000 requests/sec |
| Average User Record Size | 2 KB |
| Average Session Size | 1 KB |
| Concurrent Active Sessions | 10 Million |

### 3.1 Login Request Rate

Assume the system handles around ****50 million login requests per day****.

> Average Login RPS = 50 Million / 86,400  
> ≈ 580 requests/second

During peak hours:

> Peak Login RPS ≈ 10,000 requests/second

The system should be designed with additional capacity for traffic spikes.

### 3.2 User Data Storage

Assume each user record requires around ****2 KB****.

> Storage = 100 Million × 2 KB  
> ≈ 200 GB

This includes basic profile information, password hash, verification status, and security settings.

### 3.3 Session Storage

Assume there are around ****10 million active sessions**** and each session requires ****1 KB****.

> Session Storage = 10 Million × 1 KB  
> ≈ 10 GB

A distributed cache such as Redis can be used to store active session information for fast access.

### 3.4 Authentication Server Estimation

Assume one authentication server can handle around 1,000 authentication requests per second.

> Servers Required = 10,000 / 1,000  
> ≈ 10 Servers

In practice, additional servers should be deployed for redundancy, failover, and sudden traffic spikes.

### 3.5 Token Validation Traffic

Protected APIs may validate authentication tokens much more frequently than users log in.

For this reason:

- JWT validation can be performed locally by backend services using public keys.
- Session-based authentication can use Redis for fast session lookup.
- Frequently accessed authentication metadata can be cached.
- Token validation should avoid hitting the main user database for every request.

## 4\. High Level Design

The High-Level Design (HLD) shows how different software components of the Authentication System work together to provide secure user authentication, authorization, session management, multi-factor authentication, token management, and security monitoring.

![[frame_3645.webp|frame_3645]]

Authentication System Architecture

### Core Components

- ****Client:**** Web or mobile application used by users to register, log in, log out, reset passwords, and manage security settings.
- ****API Gateway:**** Receives authentication requests and routes them to the appropriate backend services.
- ****Load Balancer:**** Distributes incoming requests across multiple application server instances to improve availability and scalability.
- ****Rate Limiter:**** Limits excessive authentication requests and helps prevent brute-force attacks.
- ****Authentication Service:**** Orchestrates login, logout, credential verification, and the overall authentication flow.
- ****User Service:**** Manages user accounts, profile information, verification status, and account state.
- ****Password Service:**** Securely hashes passwords during registration or password changes and verifies submitted passwords during login.
- ****Token Service:**** Generates, validates, refreshes, and revokes access and refresh tokens.
- ****Session Service:**** Creates, validates, manages, and revokes user sessions.
- ****MFA Service:**** Handles second-factor authentication such as OTPs and authenticator-app codes.
- ****Notification Service:**** Handles security-related notifications such as OTPs, email verification, password resets, and login alerts.
- ****Redis Cache:**** Stores temporary and frequently accessed authentication data such as sessions, OTPs, rate-limit counters, and token-related data.
- ****User Database:**** Stores user account information, password hashes, security settings, and verification status.
- ****Message Queue:**** Asynchronously queues notification and other background tasks, improving reliability and reducing request latency.
- ****Email/SMS Provider:**** Delivers OTPs, verification messages, password-reset notifications, and security alerts.
- ****Audit Log Service:**** Records security events such as login attempts, password changes, token revocations, MFA events, and suspicious activities.
- ****Audit Store:**** Persistently stores audit logs for security monitoring, investigation, and compliance purposes.

### Request Flow

![[frame_3642.webp|frame_3642]]

Authentication System - Request Flow Diagram

- The user sends login credentials from the client.
- The request reaches the API Gateway and passes through the Rate Limiter.
- The Authentication Service retrieves the user's authentication information.
- The Password Service compares the submitted password with the stored password hash.
- If MFA is enabled, the MFA Service performs an additional verification step.
- After successful authentication, the Token Service or Session Service creates the authentication state.
- An access token or session ID is returned to the client.
- The client sends the token or session ID with future protected API requests.
- Backend services validate the token or session before allowing access.
- Login and security events are recorded by the Audit Log Service.

### Data Flow

- User credentials and account security settings are stored in the User Database.
- Passwords are never stored directly; only secure password hashes are stored.
- Active sessions can be stored in Redis for fast validation and revocation.
- Short-lived access tokens can be validated by backend services without querying the main database on every request.
- Refresh tokens are used to generate new access tokens after the current access token expires.
- OTPs and temporary verification codes are stored with short expiration times.
- Authentication events are sent to the Audit Log Service for security monitoring and investigation.

## 5\. Technology Stack

Before designing the data model, we identify the technologies that can be used for different components of the Authentication System.

| ****Component**** | ****Technology**** |
| --- | --- |
| Client Communication | REST API, HTTPS |
| API Gateway | NGINX, Kong, AWS API Gateway |
| Load Balancer | NGINX, HAProxy, AWS ELB |
| Authentication Service | Java, Go, Node.js |
| User Database | PostgreSQL, MySQL |
| Session Store | Redis |
| Password Hashing | Argon2, bcrypt |
| Access Tokens | JWT |
| Refresh Tokens | Secure Random Tokens, JWT |
| MFA / OTP | TOTP, SMS OTP, Email OTP |
| Notification Service | AWS SES, Twilio, Firebase |
| Rate Limiting | Redis, API Gateway |
| Message Queue | Kafka, RabbitMQ |
| Audit Logging | Elasticsearch, OpenSearch |
| Monitoring | Prometheus, Grafana |
| Secret Management | HashiCorp Vault, AWS Secrets Manager |
| Containerization | Docker |
| Orchestration | Kubernetes |

## 6\. Data Model Design

The data model defines how the Authentication System stores users, credentials, sessions, tokens, MFA settings, and security events. The main goal is to keep authentication data secure, consistent, and easy to validate.

- Identify the core entities required for authentication and session management.
- Define relationships between users, credentials, sessions, tokens, and MFA methods.
- Store sensitive authentication data securely and avoid storing plain-text passwords or tokens.

### Core Entities

The Authentication System consists of the following core entities:

![[frame_3644.webp|frame_3644]]

Authentication System - ER Diagram

- ****User:**** Stores user ID, email, phone number, username, account status, and verification status.
- ****Credential:**** Stores password hash, hashing algorithm, password updated time, and failed login information.
- ****Session:**** Stores session ID, user ID, device information, IP address, creation time, and expiration time.
- ****RefreshToken:**** Stores refresh token identifier, associated user/session, expiry time, and revocation status.
- ****PasswordResetToken:**** Stores temporary password-reset token information and expiration time.
- ****Role:**** Stores user roles and permissions such as `USER`, `ADMIN`, or application-specific roles.

### Database Selection

A combination of SQL Database and Redis can be used for the Authentication System.

- ****SQL Database:**** PostgreSQL or MySQL can store users, credentials, roles, MFA settings, and long-term authentication records.
- ****Redis:**** Can store active sessions, OTPs, rate-limit counters, temporary verification data, and revoked-token information.
- ****Audit Store:**** Elasticsearch, OpenSearch, or another log store can be used for large-scale security and authentication logs.
- ****Sensitive Data:**** Passwords should only be stored as secure hashes using algorithms such as Argon2 or bcrypt.
- ****Tokens:**** Refresh tokens should preferably be stored in hashed form so leaked database data cannot directly be used to authenticate.

## 7\. API Design

The API design defines how users and applications interact with the Authentication System for registration, login, logout, token refresh, password reset, MFA, and session management.

- Use secure HTTPS APIs for all authentication-related communication.
- Keep access tokens short-lived and use refresh tokens for obtaining new access tokens.
- Apply rate limiting on sensitive APIs such as login, OTP, and password reset.

### Authentication APIs

| ****Method**** | ****Endpoint**** | ****Description**** |
| --- | --- | --- |
| POST | `/api/v1/auth/register` | Register a new user |
| POST | `/api/v1/auth/login` | Authenticate user credentials |
| POST | `/api/v1/auth/logout` | Logout from the current session |
| POST | `/api/v1/auth/refresh` | Generate a new access token |
| POST | `/api/v1/auth/verify-email` | Verify user's email address |

### Password APIs

| ****Method**** | ****Endpoint**** | ****Description**** |
| --- | --- | --- |
| POST | `/api/v1/auth/forgot-password` | Request password reset |
| POST | `/api/v1/auth/reset-password` | Reset password using a valid token |
| PUT | `/api/v1/auth/change-password` | Change password for a logged-in user |

### MFA APIs

| ****Method**** | ****Endpoint**** | ****Description**** |
| --- | --- | --- |
| POST | `/api/v1/auth/mfa/setup` | Enable and configure MFA |
| POST | `/api/v1/auth/mfa/verify` | Verify OTP or MFA code |
| DELETE | `/api/v1/auth/mfa` | Disable MFA |

### Session APIs

| ****Method**** | ****Endpoint**** | ****Description**** |
| --- | --- | --- |
| GET | `/api/v1/auth/sessions` | Get all active user sessions |
| DELETE | `/api/v1/auth/sessions/{sessionId}` | Revoke a specific session |
| DELETE | `/api/v1/auth/sessions` | Logout from all devices |

### Sample Login Request

****POST**** `/api/v1/auth/login`

> `{  "email": "user@example.com",  "password": "user-password"}`

### Sample Login Response

> `{`  
> `  "userId": "usr_101",`  
> `  "accessToken": "access_token_value",`  
> `  "refreshToken": "refresh_token_value",`  
> `  "expiresIn": 900`  
> `}`

### Sample MFA Response

If MFA is enabled, the login response can first return:

> `{`  
> `  "mfaRequired": true,`  
> `  "challengeId": "mfa_501"`  
> `}`

The user then submits the OTP or authenticator code to complete authentication.

## 8\. Low Level Design

The Low-Level Design (LLD) defines the main classes inside the Authentication System and explains how they interact during registration, login, token generation, MFA verification, and session management.

### Core Classes

The Authentication System can be designed using the following core classes:

![[frame_3643.webp|frame_3643]]

Authentication System - UML Class Diagram

- ****User:**** Stores user ID, email, phone number, username, account status, and verification status.
- ****Credential:**** Stores password hash, failed login count, and password update information.
- ****Session:**** Represents a logged-in user session and stores device, IP address, creation time, and expiry time.
- ****Role:**** Represents user roles and associated permissions.
- ****AuthenticationService:**** Handles registration, login, logout, and credential verification.
- ****TokenService:**** Generates, validates, refreshes, and revokes authentication tokens.
- ****PasswordService:**** Handles password hashing, verification, reset, and password policy checks.

### SOLID Principles

- ****Single Responsibility Principle (SRP):**** AuthenticationService handles authentication, TokenService handles tokens, and MFAService handles MFA logic.
- ****Open/Closed Principle (OCP):**** New authentication methods such as passkeys, social login, or hardware keys can be added without changing existing core logic.
- ****Liskov Substitution Principle (LSP):**** Different authentication providers should work through common interfaces.
- ****Interface Segregation Principle (ISP):**** Services should depend only on the authentication operations they need.
- ****Dependency Inversion Principle (DIP):**** High-level authentication logic should depend on interfaces instead of specific databases, token libraries, or OTP providers.

### Design Patterns

| ****Design Pattern**** | ****Usage**** |
| --- | --- |
| ****Strategy**** | Support different authentication methods such as password, OTP, passkey, or social login |
| ****Factory**** | Create different token, MFA, or authentication provider implementations |
| ****Observer**** | Trigger audit logs, alerts, or notifications after authentication events |
| ****Chain of Responsibility**** | Process authentication steps such as password check → MFA → risk check → token generation |
| ****State**** | Manage account states such as ACTIVE, LOCKED, DISABLED, or UNVERIFIED |

## 9\. Scalability & Performance

Scalability and performance ensure that the Authentication System can handle millions of users and a very high number of login and token-validation requests without becoming slow or unavailable.

![[frame_3641.webp|frame_3641]]

Authentication System - Scalability Architecture

- ****Horizontal Scaling:**** Run multiple Authentication Service instances behind a load balancer.
- ****Stateless Authentication Servers:**** Keep authentication servers stateless so requests can be handled by any server instance.
- ****JWT Validation:**** Backend services can validate short-lived access tokens locally using public keys, reducing database calls.
- ****Redis Session Store:**** Store active sessions, OTPs, rate-limit counters, and temporary authentication data in Redis.
- ****Database Replication:**** Use read replicas for profile, role, and account-status queries.
- ****Database Sharding:**** Partition user data when the number of accounts becomes very large.
- ****Caching:**** Cache frequently accessed user roles, permissions, and authentication metadata.
- ****Rate Limiting:**** Limit repeated login, OTP, and password-reset requests to protect the system from abuse.
- ****Asynchronous Processing:**** Send emails, SMS, audit logs, and security notifications through message queues.
- ****Token Key Rotation:**** Support multiple signing keys so access tokens can continue to be validated safely during key rotation.
- ****Connection Pooling:**** Reuse database and Redis connections to reduce authentication latency.
- ****Auto Scaling:**** Increase authentication-service instances automatically during traffic spikes.
- ****Multi-Region Deployment:**** Deploy authentication services across regions for better availability and lower latency.

## 10\. Bottlenecks & Improvements

This section discusses the major challenges an Authentication System may face at scale and the techniques used to improve security, reliability, and performance.

### Common Bottlenecks

- ****Login Traffic Spikes:**** Sudden increases in login requests can overload authentication servers.
- ****Database Bottleneck:**** Every login request may require reading user credentials and account information.
- ****Session Store Overload:**** A large number of active sessions can put heavy load on Redis or other session stores.
- ****Brute-Force Attacks:**** Attackers may repeatedly try different passwords for the same account.
- ****Token Theft:**** Stolen access or refresh tokens may be used to access user accounts.
- ****OTP Abuse:**** Repeated OTP requests can increase cost and create security risks.
- ****Single Point of Failure:**** Failure of the authentication service can prevent users from accessing the entire application.
- ****Password Hashing Cost:**** Secure password hashing is intentionally expensive and can consume significant CPU during high login traffic.
- ****Token Revocation:**** Revoking JWT access tokens immediately can be difficult because they are normally validated without a database lookup.
- ****Multi-Region Consistency:**** Password changes, logout events, and token revocations must propagate correctly across regions.

### Possible Improvements

- ****Horizontal Scaling:**** Run multiple authentication servers behind load balancers.
- ****Rate Limiting:**** Limit login, OTP, password-reset, and token-refresh attempts per user, IP, or device.
- ****Account Lockout:**** Temporarily lock or slow down authentication after repeated failed login attempts.
- ****Short-Lived Access Tokens:**** Keep access-token lifetime short to reduce the impact of token theft.
- ****Refresh Token Rotation:**** Generate a new refresh token after every refresh and invalidate the previous one.
- ****Token Revocation List:**** Maintain revoked sessions or tokens in Redis when immediate revocation is required.
- ****Secure Password Hashing:**** Use Argon2 or bcrypt with proper configuration and unique salts.
- ****MFA:**** Add another verification factor for sensitive accounts or suspicious login attempts.
- ****Caching:**** Cache frequently accessed roles, permissions, and authentication metadata.
- ****Asynchronous Processing:**** Move audit logging, emails, SMS, and security notifications to message queues.
- ****Database Replication & Sharding:**** Scale user data across multiple database nodes.
- ****Fraud Detection:**** Detect suspicious logins using IP address, device information, location changes, and unusual behavior.
- ****Audit Logging:**** Record important authentication events for monitoring and security investigation.
- ****Multi-Region Deployment:**** Deploy redundant authentication services and synchronize critical security state across regions.