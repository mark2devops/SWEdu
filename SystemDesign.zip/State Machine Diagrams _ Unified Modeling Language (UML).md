---
title: "State Machine Diagrams | Unified Modeling Language (UML)"
source: "https://www.geeksforgeeks.org/system-design/unified-modeling-language-uml-state-diagrams/"
author:
  - "[[GeeksforGeeks]]"
published: 2017-10-27
created: 2026-09-23
description: "Your All-in-One Learning Portal: GeeksforGeeks is a comprehensive educational platform that empowers learners across domains-spanning computer science and programming, school education, upskilling, commerce, software tools, competitive exams, and more."
tags:
  - "clippings"
---
A State Machine Diagram is a behavioral UML diagram used to represent how an object or system changes its state in response to events over time. It models the lifecycle of an object by showing different states and the transitions between them.

- Represents dynamic behavior of a system using states, events, and transitions
- Helps visualize how an object reacts to external inputs and moves from one state to another
- State Machine diagrams are also known as State Diagrams and State-Chart Diagrams. These both terms can be used interchangeably.

> ****Example:**** In the ATM verification process shown in the diagram, the system moves from Waiting for PIN to PIN Verification when the user enters the PIN. If the PIN is authenticated successfully, the system transitions to the User Identified state.

![[2056958194.webp|2056958194]]

## Basic Components and Notations of a State Machine Diagram

The basic components and their notations of a State Machine Diagram are:

### 1\. Initial state

We use a black filled circle represent the initial state of a System or a Class.

![[2056958187.webp|2056958187]]

### 2\. Transition

We use a solid arrow to represent the transition or change of control from one state to another. The arrow is labelled with the event which causes the change in state.

![[2056958186.webp|2056958186]]

### 3\. State

We use a rounded rectangle to represent a state. A state represents the conditions or circumstances of an object of a class at an instant of time.

![[2056958188.webp|2056958188]]

### 4\. Fork

We use a rounded solid rectangular bar to represent a Fork notation with incoming arrow from the parent state and outgoing arrows towards the newly created states. We use the fork notation to represent a state splitting into two or more concurrent states.

![[2056958190.webp|2056958190]]

### 5\. Join

We use a rounded solid rectangular bar to represent a Join notation with incoming arrows from the joining states and outgoing arrow towards the common goal state. We use the join notation when two or more states concurrently converge into one on the occurrence of an event or events.

![[2056958191.webp|2056958191]]

### 6\. Self transition

We use a solid arrow pointing back to the state itself to represent a self transition. There might be scenarios when the state of the object does not change upon the occurrence of an event. We use self transitions to represent such cases.

![[2056958253.webp|2056958253]]

### 7\. Composite state

We use a rounded rectangle to represent a composite state also. We represent a state with internal activities using a composite state.

![[2056958192.webp|2056958192]]

### 8\. Final State

We use a filled circle within a circle notation to represent the final state in a state machine diagram.

![[2056958189.webp|2056958189]]

## Draw a State Machine diagram in UML

Below are the steps on how to draw the State Machine Diagram in UML

![[1232.webp|1232]]

### Step 1: Identify the System

- Understand what your diagram is representing.
- Whether it's a machine, a process, or any object, know what different situations or conditions it might go through.

### Step 2: Identify Initial and Final States

- Figure out where your system starts (initial state) and where it ends (final state).
- These are like the beginning and the end points of your system's journey.

### Step 3: Identify Possible States

- Think about all the different situations your system can be in.
- These are like the various phases or conditions it experiences.
- Use boundary values to guide you in defining these states.

### Step 4: Label Triggering Events

- Understand what causes your system to move from one state to another.
- These causes or conditions are the events.
- Label each transition with what makes it happen.

### Step 5: Draw the Diagram with appropriate notations

- Now, take all this information and draw it out.
- Use rectangles for states, arrows for transitions, and circles or rounded rectangles for initial and final states.
- Be sure to connect everything in a way that makes sense.

## Example: Online Order System

Let's understand State Machine diagram with the help of an example, ie for an Online Order

![[2056958193.webp|2056958193]]

The UML diagrams we draw depend on the system we aim to represent. Here is just an example of how an online ordering system might look like:

- On the event of an order being received, we transition from our initial state to Unprocessed order state.
- The unprocessed order is then checked.
- If the order is rejected, we transition to the Rejected Order state.
- If the order is accepted and we have the items available we transition to the fulfilled order state.
- However if the items are not available we transition to the Pending Order state.
- After the order is fulfilled, we transition to the final state. In this example, we merge the two states i.e. Fulfilled order and Rejected order into one final state.

> ****Note:**** Here we could have also treated fulfilled order and rejected order as final states separately.

## Applications of State Machine Diagram

The main use cases of state machine diagram are:

- State Machine Diagrams are very useful for modeling and visualizing the dynamic behavior of a system.
- They are also used in UI design where they help to illustrate how the interface changes in response to user actions, helping designers to create a better use experience.
- In game design, state machine diagrams can help model the behavior of characters or objects, detailing how they change states based on player interactions or game events
- In embedded systems, where hardware interacts with software to perform tasks, State Machine Diagrams are valuable for representing the control logic and behavior of the system.

## Differences between a State Machine Diagram and a Flowchart

| ****State Machine Diagram**** | ****Flowchart**** |
| --- | --- |
| Represents different states of a system/object and transitions between them | Represents the step-by-step flow of a process or algorithm |
| Focuses on state changes caused by events | Focuses on execution flow and decision-making steps |
| Behavioral UML diagram | Process/algorithm representation diagram |
| Used for modeling dynamic behavior and object lifecycle | Used for modeling workflows and business processes |
| Uses states, transitions, events, and initial/final states | Uses process blocks, decision symbols, and arrows |
| Shows how an object behaves over time in different states | Shows how control moves from one step to another |
| Best suited for complex state-dependent systems | Best suited for simple procedural workflows |
| ****Example:**** ATM states like Card Inserted -> PIN Verification -> Authenticated | ****Example:**** ATM process like Insert Card -> Enter PIN -> Validate PIN -> Show Menu |