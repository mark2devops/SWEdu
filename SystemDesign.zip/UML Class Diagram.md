---
title: "UML Class Diagram"
source: "https://www.geeksforgeeks.org/system-design/unified-modeling-language-uml-class-diagrams/"
author:
  - "[[GeeksforGeeks]]"
published: 2018-08-30
created: 2026-09-23
description: "Your All-in-One Learning Portal: GeeksforGeeks is a comprehensive educational platform that empowers learners across domains-spanning computer science and programming, school education, upskilling, commerce, software tools, competitive exams, and more."
tags:
  - "clippings"
---
A UML class diagram shows the structure of a system by displaying its classes, their attributes, methods, and the relationships between them. It helps the team understand how the system is organized and how components interact.

- Represents classes, attributes, methods, and relationships within a system.
- Helps developers understand, communicate, and document the software structure more effectively.
![[animal.webp|animal]]

Class Diagram

## UML Class Notation

Classes are depicted as boxes, each containing three compartments for the class name, attributes, and methods.

![[car.webp|car]]

UML Class Notation

- ****Class Name:**** The name of the class is typically written in the top compartment of the class box and is centered and bold.
- ****Attributes:**** Attributes, also known as properties or fields, represent the data members of the class. They are listed in the second compartment of the class box and often include the visibility (e.g., public, private) and the data type of each attribute.
- ****Methods:**** Methods, also known as functions or operations, represent the behavior or functionality of the class. They are listed in the third compartment of the class box and include the visibility (e.g., public, private), return type, and parameters of each method.

### Visibility Notation

Visibility notations indicate the access level of attributes and methods. Common visibility notations include:

- `+` for public (visible to all classes)
- `-` for private (visible only within the class)
- `#` for protected (visible to subclasses)
- `~` for package or default visibility (visible to classes in the same package)

### Parameter Directionality

- In class diagrams, parameter directionality refers to the indication of the flow of information between classes through method parameters.
- It helps to specify whether a parameter is an input, an output, or both. This information is crucial for understanding how data is passed between objects during method calls.
![[car2.webp|car2]]

There are three main parameter directionality notations used in class diagrams:

- ****In (Input):**** A parameter sent from the caller to the method being executed.
- ****Out (Output):**** A parameter sent from the method back to the caller after execution.
- ****InOut (Input and Output):**** A parameter that is sent to the method and also returns back to the caller.

## Relationships between classes

In class diagrams, relationships between classes describe how classes are connected or interact with each other within a system. Here are some common types of relationships in class diagrams:

![[class_diagram_relationships.webp|class_diagram_relationships]]

Class Diagram Relationship

- ****Association:**** Represents a relationship between two classes where their objects are connected, usually shown by a solid line.
- ****Directed Association:**** Represents a relationship between two classes with a specific direction, showing that one class is associated with another.
- ****Aggregation:**** Represents a weak whole-part relationship where the part can exist independently of the whole, shown by a hollow diamond.
- ****Composition:**** Represents a strong whole-part relationship where the part cannot exist independently of the whole, shown by a filled diamond.
- ****Generalization (Inheritance):**** Represents an is-a relationship where a subclass inherits properties and behaviors from a superclass.
- ****Realization (Interface Implementation):**** Represents a relationship where a class implements the features or operations defined by an interface.
- ****Dependency Relationship:**** Represents a weak relationship where one class depends on another class for some functionality.
- ****Usage (Dependency) Relationship:**** Represents a dependency where one class uses the services or functionality provided by another class.

## Advantages of UML Class Diagram

- Helps in faster and more efficient system design and analysis.
- Improves understanding of object-oriented programming (OOP) concepts.
- Enhances communication between developers, designers, and stakeholders.
- Supports forward and reverse engineering during software development.
- Provides proper documentation of the system structure and components.

## Applications of UML Class Diagram

- Used in software design and system architecture planning.
- Helps in database modeling and representing data structures.
- Useful for system documentation and maintenance.
- Widely used in object-oriented analysis and design.
- Commonly used in enterprise and large-scale application development.