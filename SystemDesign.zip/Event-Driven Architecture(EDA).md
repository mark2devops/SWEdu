---
title: "Event-Driven Architecture(EDA)"
source: "https://www.geeksforgeeks.org/system-design/event-driven-architecture-system-design/"
author:
  - "[[GeeksforGeeks]]"
published: 2024-01-31
created: 2026-09-23
description: "Your All-in-One Learning Portal: GeeksforGeeks is a comprehensive educational platform that empowers learners across domains-spanning computer science and programming, school education, upskilling, commerce, software tools, competitive exams, and more."
tags:
  - "clippings"
---
Event-Driven Architecture (EDA) is a software design approach where system components communicate by producing and responding to events, such as user actions or system state changes. Components are loosely coupled, allowing them to operate independently while reacting to events in real time.

- Enables real-time responsiveness, scalability, and modularity while improving system flexibility.
- Components work independently without being tightly linked, and when an event occurs, relevant components respond accordingly.

> ****Example:**** In an [e-commerce system](https://www.geeksforgeeks.org/system-design/event-driven-architecture-in-an-e-commerce-system/), when a customer places an order, an Order Placed event is generated. Different services like payment processing, inventory management, and email notifications don’t constantly check the order system; instead, they independently respond when the event occurs.

![[event_broker.webp|event_broker]]

In the diagram

- Event Source 1 and Event Source 2 publish events (A and B) to a central Event Broker.
- The Event Broker receives, filters, and routes events based on subscriptions.
- Subscribers get only the events they subscribed to, such as A, B, or A + B.

## Real World Applications

Event-Driven Architecture (EDA) is widely used across industries where real-time processing, scalability, and system integration are important.

- ****Financial Services:**** Used for real-time transaction processing, fraud detection, and market data updates where events like payments or trades trigger immediate responses.
- ****E-commerce:**** Helps manage order processing, inventory updates, and payment workflows with real-time event handling and seamless integration with external services.
- ****Telecommunications:**** Supports network monitoring, call processing, and dynamic load handling through event-driven communication between network components.
- ****Online Gaming:**** Enables real-time player interactions, game state updates, and event handling for smooth multiplayer experiences.
- ****Real-Time Applications:**** Ideal for systems that need instant response to user actions or data changes.

## Importance

Event-Driven Architecture (EDA) holds significant importance in system design for several reasons:

- ****Flexibility and Responsiveness:**** Systems can quickly adjust to changing situations thanks to EDA. The system may adapt to new information dynamically by initiating operations based on events, guaranteeing its agility and responsiveness.
- ****Scalability****: Because EDA is scalable, components can be added or removed without affecting the current configuration. It is easier to modify the system in response to changing demands because of its flexibility.
- ****Real-time Processing****: EDA is ideal for scenarios requiring real-time processing. Events are handled as they happen, enabling the system to efficiently manage time-sensitive tasks.
- ****Decentralized Communication****: Components communicate through events rather than direct connections, which reduces the need for point-to-point interactions. This decentralized approach enhances reliability and simplifies system maintenance.

## Events in Event-Driven Architecture

Events are crucial components of Event-Driven Architecture (EDA) that denote significant events or system modifications. Below are the key points about events in EDA:

- ****Triggering****: Various sources, such as user actions or data changes, can trigger events.
- ****Asynchronicity****: EDA often uses asynchronous communication, allowing components to work independently and in parallel.
- ****Publish-Subscribe Model****: A publish-subscribe model is used to manage events, with individuals who produce them publishing them and interested parties subscribing to them.
- ****Event Types****: By purpose, events are grouped together, such as "UserLoggedIn" or "OrderPlaced."
- ****Payload****: Events often include extra information, or payload, that provides context (e.g., a "PaymentReceived" event might detail the payment amount).
- ****Event Handling****: Components have specific handlers that dictate their response to events.

## Components

Event-Driven Architecture (EDA) has several key elements that helps in facilitating communication and respond to events. The following are the main components of an event-driven architecture:

### 1\. Event Source

An event source is any component that generates events when a significant action or state change occurs.

- Can be user interfaces, sensors, databases, or external systems.
- Acts as the starting point of the event flow.

### 2\. Event

An event represents a meaningful occurrence or change in the system state.

- Serves as the core unit of communication in EDA.
- Contains relevant data describing what happened.
- Event is immutable once created.

### 3\. Event Broker / Event Bus

The event broker acts as a central hub for managing event communication.

- Receives events from publishers.
- Filters and routes events to appropriate subscribers.

### 4\. Publisher

A publisher is responsible for emitting events to the event bus.

- Converts system actions or changes into events.
- Sends events asynchronously.
- Does not need to know who will consume the events.

### 5\. Subscriber

A subscriber registers interest in specific types of events.

- Listens for relevant events on the event bus.
- Reacts dynamically when events occur.

## Supporting Patterns

These are additional roles and patterns that help in processing and managing events effectively but are not core components of Event-Driven Architecture.

### 1\. Event Handler

An event handler contains the logic for processing received events.

- Defines the actions taken in response to an event.
- Implements business rules or workflows.

### 2\. Dispatcher

The dispatcher controls how events are delivered within the system.

- Routes events to the correct event handlers.
- Manages the event processing flow.

### 9\. Listener

A listener actively monitors the event bus for specific events.

- Detects events of interest.
- Triggers processing as soon as events are received.

## Challenges

While Event-Driven Architecture (EDA) has many benefits, it also comes with some challenges that are worth considering.

- ****Increased Complexity****: As more events and components are added, EDA systems can get complicated. It can be tough to manage how events flow and to keep everything coordinated.
- ****Event Order and**** [****Consistency****](https://www.geeksforgeeks.org/system-design/consistency-in-system-design/): Keeping events in the right order and making sure the system remains consistent can be tricky. Handling events that come in out of sequence or ensuring that actions are completed as a group can require extra effort
- ****Debugging and Tracing****: Finding and fixing issues in a distributed and asynchronous setup can be harder than in traditional systems. It might take more time to track down problems.
- ****Event Latency****: Because events are processed individually, there can be delays between when an event occurs and when it gets responded to. This lag might be an issue in situations that require quick reactions.

### Related Article

> [Event-Driven Architecture in an E-commerce System](https://www.geeksforgeeks.org/system-design/event-driven-architecture-in-an-e-commerce-system/)

What is the primary concept behind Event-Driven Architecture (EDA)?

- A
	Components communicate by directly calling each other’s APIs
- B
	Services must run in a single process
- C
	All components share the same database for communication
- D
	Components communicate by producing and reacting to events

What is the role of an Event Broker in an Event-Driven Architecture?

- A
	Acts as a central hub that receives and routes events to subscribers
- B
	Stores all application data permanently
- C
	Executes business logic for all services
- D
	Replaces the event source in the system

Why is asynchronous communication commonly used in Event-Driven Architecture?

- A
	To allow components to operate independently without waiting for responses
- B
	To ensure all components run in the same process
- C
	To eliminate the need for event brokers
- D
	To guarantee that events are processed in a fixed order

What is the main responsibility of a subscriber in Event-Driven Architecture?

- A
	Generating new events in the system
- B
	Listening for specific events and responding when they occur
- C
	Storing events permanently in the database
- D
	Routing events to multiple services

Why is Event-Driven Architecture suitable for real-time applications?

What is one major challenge of Event-Driven Architecture systems?

- A
	They cannot support real-time processing
- B
	Events cannot contain additional data
- C
	Managing event order and debugging distributed asynchronous systems can be difficult
- D
	Components cannot scale independently

![[sucess-img 10.png|success]]

Quiz Completed Successfully

Score:0/6

Accuracy:0%