---
title: "Redundancy in System Design"
source: "https://www.geeksforgeeks.org/system-design/redundancy-system-design/"
author:
  - "[[GeeksforGeeks]]"
published: 2023-09-29
created: 2026-09-23
description: "Your All-in-One Learning Portal: GeeksforGeeks is a comprehensive educational platform that empowers learners across domains-spanning computer science and programming, school education, upskilling, commerce, software tools, competitive exams, and more."
tags:
  - "clippings"
---
Redundancy is the practice of adding backup components, resources, or processes to a system to ensure it continues operating even when failures occur. It improves system reliability, availability, and fault tolerance by minimizing downtime.

- Backup servers, network links, or storage systems can take over when the primary component fails.
- Duplicate copies of data help prevent data loss and ensure recovery during hardware or software failures.

> ****Example:**** A website may use a secondary server that automatically handles requests if the main server crashes. Similarly, cloud services often store multiple copies of data across different locations to ensure availability.

## Types of Redundancies

### 1\. Hardware Redundancy

In order to guarantee system availability in the event of a failure, hardware redundancy involves replicating essential hardware components.

> ****Example:**** Data is redundantly stored on several hard drives in a RAID (Redundant Array of Independent Disks) setup. Data can still be recovered from the other drives in the event that one fails.

### 2\. Software Redundancy

In order to guarantee continuous operation, software redundancy depends on several instances of an application or service running concurrently.

> ****Example:**** Software load balancers are frequently used by web servers to split up incoming requests among several server instances. The load balancer reroutes traffic to servers that are in good condition in the event that one fails.

### 3\. Data Redundancy

Data Redundancy involves storing the same data in multiple locations or using replication techniques to ensure data availability.

> ****Example:**** Database Replication creates redundant copied of database across multiple servers. If one servers fails, another can continue serving the same data.

### 4\. Network Redundancy

Network Redundancy provides multiple network paths or connections to ensure network availability and fault tolerance.

> ****Example:**** BGP (Border Gateway Protocol) routing uses multiple network paths to reroute traffic in case of network failures, ensuring data can still flow.

### 5\. Geographic Redundancy

In order to guard against natural disasters or outages that are unusual to a given region, geographic redundancy involves setting up redundant systems or data centers in various geographic regions.

> ****Example:**** A global cloud service provider maintains data centers in multiple continents to ensure service availability even in the event of a regional disaster.

## Active and Passive Redundancy

### 1\. Active Redundancy

When two or more entities are performing the same task simultaneously, this is known as active redundancy. To keep things going smoothly, the others step in immediately if one of them is unable to perform the task.

> ****Example:**** Think of a website with two servers working together. They both show the website to people. If one server has a problem, the other sever quickly takes over to make sure the website keeps running without any issues.

### 2\. Passive Redundancy

Passive redundancy is similar to having a backup that is inactive until it is required. It remains silent in the background, just ready to jump in and assist when an issue arises.

> ****Example:**** In computer networks, you can have a spare or backup router. The backup doesn't do any work until main router has a problem. When main one fails, the spare router starts working to keep the network connected.

## Role of Load Balancing in Redundancy

[Load Balancing](https://www.geeksforgeeks.org/system-design/what-is-load-balancer-system-design/) plays a crucial role in Redundancy by ensuring that multiple servers or resources are utilized effectively. This helps enhance [reliability](https://www.geeksforgeeks.org/system-design/reliability-in-system-design/) and ensures that if ones server fails, other can seamlessly take over, keeping the system operational and reducing downtime.

****Examples:****

- A web application distributing user requests across multiple web servers.
- A DNS server using round-robin load balancing algorithm to distribute requests to multiple IP addresses for a single domain.

## Failover Mechanisms

[Failover Mechanisms](https://www.geeksforgeeks.org/system-design/failover-mechanisms-in-system-design/) are essential for ensuring uninterrupted service, when a component within a redundancy system fails. These mechanisms automatically detect failures and switch to a redundant component.

****Example:****

- ****Sever Failover:**** When a web server fails, a load balancer redirects traffic to a backup server.
- ****Database Failover:**** In database clusters, a primary database server failure triggers the promotion of standby server to primary role.

## Testing and Validation for Redundancy

Testing and Validation are critical to ensure that redundancy mechanisms work as expected. These include:

- ****Redundancy Testing:**** Simulating failures to verify that redundant components and failover mechanisms function correctly.
- ****Validation Testing:**** Ensuring the data synchronization and consistency are maintained in redundant systems.
- ****Load Testing:**** Assessing how the system performs under heavy loads to identify potential bottlenecks and ensure that load balancing is effective.

## Metrics for measuring Redundancy

Measuring the effectiveness of redundancy and fault tolerance is crucial. Common metrics include:

### 1\. Mean Time Between Failures (MTBF)

Measures the average time between component failures.

MTBF = Total Operating Time / Number of Failures

> ****Example:**** Let's say you have a server that has been running continuously for 1,000 hours, and it has experienced 2 failures during that time.  
> MTBF = 1,000 hours / 2 failures = 500 hours per failure

So, the MTBF for this server is 500 hours per failure. This means that, on average, you can expect this server to operate for approximately 500 hours before it encounters a failure. It's a measure of the system's reliability. The higher the MTBF, the more reliable the system.

### 2\. Mean Time to Recovery (MTTR)

Measures the average time it takes to recover from a failure.

MTTR = Total Downtime / Number of Failures

> ****Example:**** Suppose you have a network router that experienced downtime of 4 hours due to a failure, and this happened 2 times in a month.  
> MTTR = 4 hours / 2 failures = 2 hours per recovery.

This means that, on average, it takes 2 hours to restore the network router to full operational status each time it encounters a failure. A lower ****MTTR**** indicates that system can recover more quickly.

### 3\. Availability:

[Availability](https://www.geeksforgeeks.org/system-design/availability-in-system-design/) represents the percentage of time a system is operational.

Availability = (Total Uptime / Total Time) \* 100%

> ****Example:**** In a year, a data center was operation for 8,760 hours and had 50 hours of downtime.  
> Availability = (8,760 hours / (8,760 hours + 50 hours)) \* 100 % = 99.43%

So, the availability of the data center is approximately 99.43%. Highly availability is usually desirable for critical systems because it indicates that they are reliable and accessible to users for the majority of the time.

### 4\. Resource Utilization:

Evaluates the efficiency of resource usage in redundant components.

Resource Utilization = (Resource Usage / Total Available Resources) \* 100%

> ****Example:**** Let's say a redundant set of servers collectively uses 200 GB out of 500 GB if available storage space.  
> Resource Utilization = (200 GB / 500 GB) \* 100 % = 40%

The resource utilization for this storage system is 40%.

## Real-life Applications of Redundancy

Redundancy is widely used in critical industries to ensure continuous operation, reliability, and protection against failures.

- ****Finance:**** Banks use redundant servers and backup systems to ensure that banking services remain available even during hardware failures or system outages.
- ****Healthcare:**** Hospitals implement data backups and replication mechanisms to keep patient records accessible and recoverable in case of data loss or corruption.
- ****Aviation:**** Aircraft use redundant components, such as backup fuel pumps and ignition systems, to maintain safe operation if a primary system fails.
- ****Telecommunications:**** Telecom providers deploy redundant network paths and load-balancing systems to ensure uninterrupted communication services during network failures.

## Difference between Redundancy and Replication

Both redundancy and replication improve system reliability and availability, but they achieve this in different ways.

| ****Redundancy**** | ****Replication**** |
| --- | --- |
| Adds backup hardware, software, or resources to handle failures. | Creates identical copies of data or systems across multiple locations. |
| Primarily focuses on improving system reliability and fault tolerance. | Primarily focuses on improving data availability, consistency, and scalability. |
| Backup components become active when the primary component fails. | Multiple copies can be accessed simultaneously by users or applications. |
| ****Example:**** Multiple power supplies in a server. | ****Example:**** A database replicated across several servers. |