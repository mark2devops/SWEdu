---
title: "Amazon Low Level Design(LLD)"
source: "https://www.geeksforgeeks.org/system-design/amazon-low-level-designlld/"
author:
  - "[[GeeksforGeeks]]"
published: 2024-09-02
created: 2026-09-23
description: "Your All-in-One Learning Portal: GeeksforGeeks is a comprehensive educational platform that empowers learners across domains-spanning computer science and programming, school education, upskilling, commerce, software tools, competitive exams, and more."
tags:
  - "clippings"
---
The [low-level design (LLD)](https://www.geeksforgeeks.org/system-design/what-is-low-level-design-or-lld-learn-system-design/) concepts and architectural elements that support Amazon's wide range of services and systems are covered in detail in this article. Important topics covered include system architecture, service interactions, API design, [scalability](https://www.geeksforgeeks.org/system-design/what-is-scalability/), [availability](https://www.geeksforgeeks.org/system-design/availability-in-system-design/), and [reliability](https://www.geeksforgeeks.org/system-design/reliability-in-system-design/) techniques, as well as functional and non-functional requirements. The article's goal is to provide readers with an understanding of these design features in order to shed light on the reliable and effective infrastructure that allows Amazon to distribute its goods and services throughout the world. Software architects, system designers, and developers who want to learn from Amazon's tried-and-true design methodology may find this material useful.

![Amazon-Low-Level-Design](https://media.geeksforgeeks.org/wp-content/uploads/20240910120727/Amazon-Low-Level-Design.webp)

Amazon Low Level Design(LLD)

Table of Content

## 1\. Amazon's Systems and Services

Amazon manages purchaser debts, payments, orders, and search on its big e-trade platform. From video and tune streaming to logistics and achievement, a huge range of services are powered by using its highly scalable AWS cloud computing talents. Other offerings inclusive of advertising, robots, and Alexa spotlight Amazon's numerous technological talents.

- ****Prime and Music:****
	- Two streaming services that provide music and video content (movies, TV series) are Amazon Prime Video and Amazon Music. For the purpose of efficiently delivering material to users worldwide, these services rely on extensive content delivery networks (CDNs) and data storage services.
- ****Online shopping Platform:****
	- The main service provided by Amazon, with millions of products available in various categories. The platform has elements for customer support, order management, payment processing, recommendation engines, and user management.
- ****Amazon Web Services:****
	- A cloud computing carrier that gives greater than 200 completely useful services, such as system getting to know (SageMaker), databases (RDS, DynamoDB), storage (S3), processing power (EC2), and more. Amazon and hundreds of thousands of other businesses round the world depend on AWS to gasoline their operations.
- ****Logistical and Completion:****
	- With a network of warehouses, fulfillment centers, and delivery methods, Amazon boasts one of the most advanced logistics systems in the world. Demand forecasting, inventory control, and last-mile delivery services like Amazon Prime are all included in the system
- ****Amazon Alexa:****
	- ****A**** n assistant with voice activation built into a variety of smart gadgets. Alexa serves as a primary hub for the Internet of Things by processing voice instructions, interacting with other Amazon services, and controlling smart home devices.

## 2\. Functional and Non-Functional Requirements

Below are the functional and Non-Functional Requirements for the Amazon:

### 2.1 Functional requirements:

The particular functions and features that customers must be able to access from any Amazon service is said to be ****Functional requirements****.

> Amazon's diverse range of services, such as e-commerce, cloud computing, digital content, and logistics, each have their unique set of core functional requirements.

- For the e-commerce platform, key features include product search, shopping cart management, secure payments, order tracking, and personalized recommendations.
- Thecloud computing service****,**** AWS, must provide the provisioning of compute, storage, and networking resources, as well as database and application management capabilities.
- Digital content services like Prime Video and Amazon Music require content discovery, seamless streaming, user authentication, and personalized suggestions.
- The logistics operations need to handle inventory management, order fulfillment, package tracking, and returns processing.
- Across all these services, the functional requirements define the essential features and user experiences that shape the underlying system design and implementation.

### 2.2 Non-functional requirements:

The qualities that the systems need to have, like:

- ****Scalability**** refers to the capacity to manage growing user numbers and transaction volumes.
- ****Providing**** steady and constant service delivery is what reliability is all about.
- ****Availability**** Ensuring less downtime and maximum uptime.
- ****Performance**** delivering user experiences that are quick and responsive.

The qualities that Amazon's systems must have—like scalability to accommodate increasing user loads, high availability and dependability to guarantee continuous service delivery, and robust security to safeguard user data—are outlined in non-functional criteria. Performance, scalability, reliability, availability, and security are just a few of the non-functional requirements that have a significant impact on how Amazon's engineering teams design and build the system as a whole.

## 3\. Interaction Between Services and Components

Below are the interactions between services and components:

- ****Data Flow and Integration****
	- From consumer inputs (search queries, orders) to backend processing, records movements thru some of structures before accomplishing person outputs.
		- Real-time processing and data consistency are ensured by using element integration
- [****Microservices****](https://www.geeksforgeeks.org/system-design/microservices/) ****Design****
	- Using a microservices design, Amazon allows each service (such user management and payment processing) to function independently while interacting with other services through message queues or APIs.
		- As a result, the system is more modular and simpler to scale and administer.
- [****Architecture Driven by Events****](https://www.geeksforgeeks.org/system-design/event-driven-architecture-system-design/)
	- Numerous services offered by Amazon are event-driven, which means they respond to predetermined occasions ( when a consumer submits an order).
		- This sets off a sequence of events involving several services like delivery scheduling, order processing, and inventory updates.
- ****Protection and Management of Access****
	- Secure communication is required between services.
		- To ensure that only authorized services can interact with sensitive components, Amazon uses role-based access control, encryption, and token-based authentication.

## 4\. Components of Amazon's Services

Below are the components of Amazon services:

- ****Front-end Components****
	- Handle user interfaces such as apps, websites, and voice interactions with front-end components.
		- These consist of user interfaces found on the Alexa devices, mobile apps, and Amazon website. These parts communicate with backend systems and manage user interactions.
- ****Application Components****
	- Include essential features like content streaming, product search, and recommendations.
		- supports buffering and adaptive streaming, enabling the smooth transmission of media material to users.
		- offers effective search capabilities and tailored suggestions according to user habits and inclinations.
- ****Data Storage Components****
	- Use [caching](https://www.geeksforgeeks.org/system-design/caching-system-design-concept-for-beginners/), NoSQL, and databases to manage persistent data.
		- Uses services like as Redis or Amazon CloudFront to store data that is accessed frequently and retrieves it more quickly.
		- Uses RDBMSs like Amazon RDS for structured, transactional data and NoSQL databases like DynamoDB for flexible, scalable data storage.
- ****Messaging Components****
	- [Queues](https://www.geeksforgeeks.org/system-design/message-queues-system-design/) and [event-driven systems](https://www.geeksforgeeks.org/system-design/event-driven-architecture-system-design/) facilitate asynchronous communication between services.
		- Simultaneously communicates with Amazon SQS to guarantee dependable job completion and service separation.
		- Uses Amazon SNS to broadcast messages to numerous subscribers, allowing for notifications and updates in real time.
- ****Monitoring Components****
	- Gather information, handle it, and evaluate it to enable data-driven choices and offer insights.
		- Tracks parameters like CPU, memory, and response times using tools like Amazon CloudWatch, giving information about the health and performance of the system.
		- Uses automatic alerts and logging services, such as Amazon CloudWatch Logs, to advise administrators of possible problems, allowing for proactive problem solving and system maintenance.

## 5\. Design for Amazon - Online Shopping System

Amazon (amazon.com) stands as the largest online retailer globally.

### 1\. Requirements for Amazon - Online Shopping System

- Users should be able to list new products for sale.
- Users should be able to search for products by name or category.
- Users can view all products, but must register to make purchases.
- Users should be able to add, remove, or modify items in their shopping cart.
- Users should be able to proceed to checkout and purchase items in their cart.
- Users should have the ability to rate products and write reviews.
- Users should specify a shipping address for order delivery.
- Users should be able to cancel an order if it hasn't shipped.
- Users should receive notifications regarding order and shipping status changes.
- Payment should be possible via credit card or electronic bank transfer.
- Users should be able to track their shipments to see the current status of their orders.

### 2\. Actors

- ****Admin:**** Responsible for managing accounts and adding or modifying product categories.
- ****Member:**** Can search the catalog, manage shopping cart items, place orders, and list new products for sale.
- ****System:**** Handles notifications for order and shipping updates.
- ****Guest:**** Can search the catalog, manage shopping cart items, and register as a member.

### 3\. Top Use Cases

- Adding or updating products: Updates to the catalog occur when a product is added or modified.
- Searching for products by name or category.
- Managing shopping cart items: Adding or removing items.
- Checking out: Purchasing items in the shopping cart.
- Making payments: Completing orders.
- Adding new product categories.
- Sending shipment update notifications to members.

### 4\. Classes

- ****Account:**** Includes Admin and Member accounts.
- ****Guest:**** Can search for and view products, and add items to the shopping cart.
- ****Catalog:**** Allows users to search for products by name or category; maintains an index for efficient search.
- ****Product:**** Represents individual products, each belonging to a ProductCategory.
- ****ProductReview:**** Allows registered members to review products.
- ****ShoppingCart:**** Stores items users intend to purchase.
- ****Item:**** Represents a product in the shopping cart (e.g., a pen).

### 5\. Code

### 5.1. Enums, data types, and constants
```
public enum OrderStatus {
      UNSHIPPED, PENDING, SHIPPED, COMPLETED, CANCELED, REFUND_APPLIED;
}

public enum AccountStatus {
       ACTIVE, BLOCKED, BANNED, COMPROMISED, ARCHIVED, UNKNOWN;
}

public enum  ShipmentStatus {
       PENDING, SHIPPED, DELIVERED, ON_HOLD;
}

public enum  PaymentStatus {
       UNPAID, PENDING, COMPLETED, FILLED, DECLINED, CANCELLED, ABANDONED, SETTLING, SETTLED, REFUNDED;
}

public class Address {
  private String streetAddress;
  private String city;
  private String state;
  private String zipCode;
  private String country;
}
```
### 5.2. Account, Customer, Admin, and Guest

These classes represent different people that interact with our system:
```
public class Account {
  private String username;
  private String password;
  private String name;
  private String email;
  private int phone;
  private boolean status;
  Private Address shippingAddress;
  private String[] creditCards;
  private String[] bankAccounts;
  
  public Account(username, password, name, email, phone, status, creditCards, bankAccounts) {
    //Initialize
  }
  
  public void addProduct() {}
  
  public void addProductReview() {}
  
  public boolean resetPassword() {}
}

public class Customer() {
  private List<Product> cart;
  private double order;
  
  public int getShoppingCart() {
     return cart;
  }
  
  public void addItem(Product item) {
    cart.add(item);
  }
  
  public void removeItem(Product item) {
    cart.remove(item);
  }
  
 public class Guest extends Customer {
  public void registeredAccount() {}
 }

  public class Member extends Customer {
    public void placeOrder() {}
  }
}
```
### 5.3. ProductCategory, Product, and ProductReview

Classes related to a product:
```
public class ProductCategory {
  private String name;
  private String description;
}

public class ProductReview {
  private int rating;
  private int review;
  private String reviewer;
}

public class Product {
  private int id;
  private String name;
  private String description;
  private float price;
  private String category;
  private int available_item_count = 0;
  private String seller_account;
  
  public int get_available_count() {
    return available_item_count;
  }
  
  public void updatePrice(float new_price) {
    this.price = new_price;
  }
}
```
### 5.4. ShoppingCart, Item, Order, and OrderLog

Users will add items to the shopping cart and place an order to buy all the items in the cart:
```
public class Item {
  private int id;
  private int quantity;
  private float price;
  
  public void updateQuantity(int quantity) {}
  
}

public class ShoppingCart {
  private Product[] items;
  
  public void addItems(Product item) {}
  
  public void removeItem(Product item) {}
  
  public void updateItemQuantity(Product item, int quantity) {}
  
  public Product[] getItems() {
    return items;
  }
  
  public void checkout() {
  }
}

public class OrderLog {
  private int ordernumber;
  private Date creationDate;
  private OrderStatus status;
}

class Order {
  private int ordernumber;
  private OrderStatus status;
  private Date orderDate;
  private OrderLog[] orderLog;
  
  public Order sendshipment() {
  }
  
  public void makepPyment() {}
  
  public void addOrderLog() {}
}
```
### 5.5. Shipment, ShipmentLog, and Notification:

After successfully placing an order, a shipment record will be created:
```
class ShipmentLog {
  private String shipment_number;
  private ShipmentStatus status;
  private Date creationdate;
}

class Shipment {
  private int shipment_number;
  private ShipmentStatus shipment_method;
  private Date shipmentdate;
  private Date estimatedarrival;
  private ShipmentLog[] shipmentLogs;
  
  public void addShipmentLog(ShipmentLog shipmentLog) {}
}

class Notification {
  private int notificationId;
  private Date createdOn;
  private String content;
  
  public Notification sendNotification(Account account) {}
}
```
### 5.6. Search Interface and Catalog:
```
public interface Search {
 public List<Book> searchByTitle(String title);
 public List<Book> searchByAuthor(String author);
 public List<Book> searchBySubject(String subject);
 public List<Book> searchByPubDate(Date publishDate);
}

public class Catalog implements Search {
 private HashMap<String, List<Product>> productNames;
 private HashMap<String, List<Product>> productCategories;

 public List<Product> searchByName(String query) {
   return productNames.get(query);
 }

 public List<Book> searchByCategory(String query) {
   return productCategories.get(query);
 }
}
```
## 6\. Designing for Scalability, Reliability, and Availability

- [****Scalability****](https://www.geeksforgeeks.org/system-design/what-is-scalability/):
	- Utilizes specialized storage systems (databases, caches) that are tailored for specific access patterns, and implements effective batch and stream processing techniques for data transformation and analysis.
		- Additionally, it takes advantage of containerization and serverless computing to achieve scalable deployments.
		- In order to achieve scalability, additional servers must be added horizontally, and older servers must be upgraded vertically. While load balancing guarantees that traffic is spread equally.
- [****Reliability****](https://www.geeksforgeeks.org/system-design/reliability-in-system-design/):
	- Reliability by replicating essential components and utilizing failover mechanisms to immediately transition to backups in the event of a breakdown.
		- Frequent data backups and replications across several sites guard against data loss, while solutions like AWS CloudWatch allow for warnings and continuous monitoring that facilitate prompt problem identification and resolution.
		- Constructs resilient networks with [redundancy](https://www.geeksforgeeks.org/system-design/redundancy-system-design/) and [load balancing](https://www.geeksforgeeks.org/system-design/what-is-load-balancer-system-design/).
		- Employs message queues and event-driven designs for asynchronous integration; and establishes secure, high-performance communication protocols.
- [****Availability****](https://www.geeksforgeeks.org/system-design/availability-in-system-design/)****:****
	- Deploys systems across multiple data centers and cloud regions for redundancy, offers comprehensive monitoring, logging, and automated remediation capabilities.
		- Guarantees real-time observability with the help of dashboards and proactive alerting mechanisms.

## 7\. Data Storage and Management

Massive volumes of data can be handled by Amazon's data management and storage technologies with great performance and efficiency:

### 7.1. Data Stores:

- Amazon utilizes a diverse range of specialized data stores that cater to the unique access patterns and requirements of various applications.
- These include relational databases such as Amazon RDS for structured data that necessitates complex queries, NoSQL databases like Amazon DynamoDB for adaptable, schema-less data models, and in-memory caches like Amazon ElastiCache for rapid, low-latency data access.
- Moreover, the data is partitioned and indexed to enhance query performance and scalability.
- Relational databases (RDBMS), such as Amazon RDS, are utilized for structured data storage, whereas NoSQL databases, such as DynamoDB, provide scalability and flexibility for unstructured data.
- Large-scale analytics are supported by data warehousing with Amazon Redshift, distributed file systems like Amazon EFS and object storage with Amazon S3 offer scalable solutions for a variety of data types and shared access across instances.

### 7.2. Data Processing:

- Data processing involves transforming raw data into actionable insights using techniques and tools like ETL (Extract, Transform, Load) for analysis preparation, real-time processing with frameworks like Apache Kafka, and batch processing for large datasets.
- Data pipelines also integrate with analytics platforms, enabling tasks such as aggregation, filtering, and data enrichment to support decision-making and business intelligence. To efficiently automate and manage these processes, tools like Amazon EMR and AWS Glue are commonly utilized.
- Amazon uses services such as Amazon Kinesis to ingest, process, and analyze data streams in real-time.
- Massive amounts of data may be effectively transformed and analyzed by Amazon thanks to these extremely scalable data processing pipelines.

### 7.3. Data Architecture:

- ****Data Models:****
	- Conceptual models abstractly represent key elements and relationships in data.
		- Logical models provide a detailed organization of information, including tables, columns, and their interconnections, without addressing physical storage.
		- In contrast, physical models define the actual storage methods, like databases, indexes, and partitions, tailored to specific technological environments.
- ****Data Access and Consumption:****
	- Ensuring that query languages, data visualization tools, and APIs make data easily accessible to users and applications. Supporting a range of data consumers, such as machine learning models and business analysts, is part of this.
- ****Data Lake and Data Warehouse:****
	- Large volumes of unprocessed data in their original format are stored in a data lake until they are needed.
		- A data warehouse is a system where structured and query-optimized data is kept for use in reporting and analysis.

## 8\. Communication and Networking

- ****Network Design****
	- With redundant connectivity and load balancing, Amazon's network architecture is both highly available and fault-tolerant.
		- This guarantees that their systems can function even in the event that a network component malfunctions.
- ****Communication Protocols****
	- For low-latency, high-throughput interactions between services, Amazon makes use of contemporary, high-performance communication protocols like HTTP/2 and gRPC.
		- These protocols facilitate features like header compression and multiplexing while offering effective data transport.
- ****Messaging and Events****
	- Message queues and event-driven architectures are widely used by Amazon to facilitate asynchronous service communication.
		- As a result, services can grow independently and interact dependably without being closely tied.

## 9\. Conclusion

The goal of Amazon's low-level design (LLD) is to create systems that are incredibly scalable, dependable, and available. To manage enormous volumes of data and traffic, they make use of fault-tolerant network design, specialized data stores, and effective data processing pipelines.