---
title: "Designing TikTok"
source: "https://www.geeksforgeeks.org/system-design/designing-tiktok-system-design/"
author:
  - "[[GeeksforGeeks]]"
published: 2023-12-29
created: 2026-09-23
description: "Your All-in-One Learning Portal: GeeksforGeeks is a comprehensive educational platform that empowers learners across domains-spanning computer science and programming, school education, upskilling, commerce, software tools, competitive exams, and more."
tags:
  - "clippings"
---
TikTok is a short-video sharing platform where users can upload, watch, and interact with videos. It delivers personalized content to millions of users with low-latency video streaming.

- Supports video upload, processing, streaming, and user interactions like likes, comments, and shares.
- Designed to handle millions of concurrent users while providing a fast and personalized viewing experience.

## 1\. Problem Statement

The goal is to design a scalable TikTok-like system that allows users to upload, watch, and share short videos. The system should provide a smooth viewing experience and personalized content recommendations for millions of users.

- Support video uploads, streaming, recommendations, and user interactions such as likes, comments, and follows.
- Ensure high availability, low latency, and scalability while handling millions of concurrent users.

## 2\. Requirements

Before designing the system, we need to identify its functional and non-functional requirements. These requirements define the expected features and quality attributes of the system.

### 2.1 Functional Requirements

Functional requirements describe the core features that the TikTok system must support.

- Users should be able to register, log in, and manage their profiles.
- Users should be able to upload, process, and publish short videos.
- Users should be able to like, comment, share, and save videos.
- Users should be able to follow creators and view their profiles.
- Users should be able to search for videos, creators, hashtags, and sounds.
- The system should send notifications for likes, comments, follows, and mentions.

### 2.2 Non-Functional Requirements

Non-functional requirements define how well the system should perform.

- ****Availability:**** The system should remain highly available with minimal downtime.
- ****Scalability:**** It should support millions of concurrent users and billions of video views.
- ****Reliability:**** Video uploads, processing, and interactions should be reliable without data loss.
- ****Low Latency:**** Videos should start playing quickly with minimal buffering.
- ****Performance:**** The recommendation feed and video loading should respond within a few hundred milliseconds.
- ****Security:**** User authentication, authorization, and data transmission should be secure.
- ****Storage:**** The system should efficiently store and manage massive amounts of video content.
- ****Consistency:**** User interactions such as likes and comments can be eventually consistent.
- ****Maintainability:**** The architecture should be modular and easy to maintain and extend.

## 3\. Capacity Estimation

Before designing the architecture, we estimate the expected traffic, storage, and bandwidth requirements. These estimations help determine the infrastructure needed to support millions of users and large-scale video streaming.

### Assumptions

| Parameter | Assumption |
| --- | --- |
| Registered Users | 1 Billion |
| Daily Active Users | 300 Million |
| Videos Uploaded per Day | 100 Million |
| Average Video Size | 20 MB |
| Average Video Views per Day | 10 Billion |
| Read: Write Ratio | 100: 1 |

### 3.1 Storage Estimation

Assume each uploaded video has an average size of 20 MB, and users upload approximately 100 million videos every day.

> Daily Storage = 100 Million × 20 MB = 2 PB/day

For 30 days,

> Monthly Storage = 30 × 2 PB = 60 PB

****Estimated Storage:**** 60 PB/month (excluding replicas and backups).

### 3.2 Bandwidth Estimation

Assume users watch approximately 10 billion videos every day.

> Daily Bandwidth = 10 Billion × 20 MB = 200 EB/day

Average bandwidth:

> 200 EB / 86400 sec  
> ≈ 18.5 Tbps

****Estimated Bandwidth:**** ~18.5 Tbps

Since video streaming consumes enormous bandwidth, videos should be delivered through a Content Delivery Network (CDN) to reduce latency and improve user experience.

### 3.3 Server Estimation

Assume one streaming server can handle approximately 100,000 concurrent video streams.

> Number of Streaming Servers
> 
> \= 300 Million / 100,000  
> ≈ 3000 Servers

****Estimated Streaming Servers:**** 3000 Servers

### 3.4 Requests Per Second (RPS)

Assume users generate approximately 10 billion video views per day.

> Read Requests Per Second (RPS)
> 
> \= 10 Billion / 86400  
> ≈ 115,741 requests/sec

## 4\. High-Level Design (HLD)

The High-Level Design (HLD) describes the overall architecture of the TikTok system and explains how different components work together to support video upload, processing, recommendation, and low-latency video streaming for millions of users.

![[tiktok_system_architecture.webp|tiktok_system_architecture]]

## Core Components

After the architecture diagram, explain each component one by one.

- ****Client****: The client represents the TikTok mobile or web application where users upload videos, browse feeds, and interact with content.
- ****API Gateway****: The API Gateway acts as the single entry point for all client requests. It authenticates users, applies rate limiting, and forwards requests to the appropriate backend services.
- ****Load Balancer****: The Load Balancer distributes incoming requests across multiple application servers to ensure high availability and prevent server overload.
- ****User Service****: The User Service manages user accounts, authentication, profiles, followers, and following relationships.
- ****Video Service****: The Video Service handles video uploads, metadata management, and video publishing.
- ****Video Processing Service****: The Video Processing Service transcodes uploaded videos into multiple resolutions, generates thumbnails, and optimizes videos for streaming.
- ****Recommendation Service****: The Recommendation Service generates the personalized For You feed using user behavior, watch history, likes, shares, and machine learning models.
- ****Feed Service****: The Feed Service retrieves personalized videos and delivers them to users in the correct order.
- ****Interaction Service****: The Interaction Service manages likes, comments, shares, saves, and follow operations.
- ****Notification Service****: The Notification Service sends push notifications for likes, comments, follows, mentions, and new followers.
- ****Search Service****: The Search Service enables users to search for videos, creators, hashtags, and sounds.
- ****CDN (Content Delivery Network)****: The CDN caches video content close to users, reducing latency and ensuring smooth video playback across different geographical regions.
- ****Object Storage****: Object Storage stores original videos, transcoded videos, thumbnails, and other media assets.
- ****Redis Cache****: Redis stores frequently accessed data such as trending videos, user sessions, recommendation cache, and popular creators.
- ****Database****: The database stores user profiles, video metadata, comments, likes, follows, and other application data.
- ****Message Queue****: A Message Queue enables asynchronous processing of tasks such as video transcoding, recommendation updates, notifications, and analytics.

### Request Flow

After explaining the components, describe how a video upload request travels through the system.

![[tik_tok_request_flow.webp|tik_tok_request_flow]]

Request Flow

- User uploads a video from the TikTok application.
- The request reaches the API Gateway.
- The Load Balancer forwards it to the Video Service.
- The video is uploaded to Object Storage.
- The Video Processing Service transcodes the video and generates thumbnails.
- Video metadata is stored in the Database.
- The Message Queue triggers background tasks such as recommendation updates and notifications.
- Once processing is complete, the Feed Service makes the video available in users' feeds.
- Users stream the video through the CDN for low-latency playback.

### Data Flow

The data flow explains how videos and user interactions move across different components of the TikTok system.

- The client sends requests to the API Gateway, which authenticates and forwards them to the appropriate services.
- Uploaded videos are stored in Object Storage, while video metadata is saved in the Database.
- The Video Processing Service generates multiple video resolutions and thumbnails for adaptive streaming.
- The Feed Service retrieves personalized recommendations using the Recommendation Service and Redis Cache.
- Videos are streamed to users through the CDN to reduce latency and improve playback performance.
- User interactions such as likes, comments, shares, and follows are stored in the Database and used to continuously improve recommendation results.

## 5\. Technology Stack

The TikTok system uses different technologies to handle video uploads, streaming, storage, caching, and recommendation efficiently.

- Each technology is selected based on scalability, performance, and reliability requirements.
- A combination of SQL, NoSQL, caching, and object storage enables the platform to serve millions of users.

| ****Component**** | ****Technology**** |
| --- | --- |
| API | REST API, WebSocket |
| Load Balancer | NGINX / HAProxy |
| Cache | Redis |
| Message Queue | Apache Kafka |
| SQL Database | MySQL |
| NoSQL Database | Cassandra |
| Object Storage | Amazon S3 |
| CDN | CloudFront / Cloudflare |
| Video Processing | FFmpeg |
| Recommendation Engine | TensorFlow / PyTorch |

## 6\. Data Model Design

The data model defines how TikTok stores and manages users, videos, interactions, and media assets. A well-designed schema enables efficient storage, fast retrieval, and supports billions of videos and user interactions.

- Identify the core entities required for video sharing and user interactions.
- Select suitable databases for structured data, video metadata, and media storage.

### Core Entities

The TikTok system consists of the following core entities:

- ****User:**** Stores user profile information, authentication details, and account settings.
- ****Video:**** Stores video metadata such as title, description, creator, duration, hashtags, and visibility.
- ****Interaction:**** Stores user activities such as likes, comments, shares, saves, and views.
- ****Media:**** Stores metadata of uploaded videos, thumbnails, and processed video files.
![[tiktok_er_diagram.webp|tiktok_er_diagram]]

### Database Selection

A combination of SQL, NoSQL, and Object Storage can be used depending on the type of data.

- SQL Database is suitable for storing structured data such as user accounts, profiles, and relationships.
- NoSQL Database is better suited for storing video metadata, comments, and user interactions because of its high scalability.
- Object Storage stores original videos, transcoded videos, and thumbnails, while only their metadata is maintained in the database.

## 7\. API Design

The API design defines how the client communicates with backend services to upload videos, fetch feeds, manage user interactions, and perform search operations.

- Design REST APIs that are scalable and easy to consume.
- Use appropriate HTTP methods for different operations.
- Secure APIs using JWT or OAuth authentication.

### Authentication APIs

| Method | Endpoint | Description |
| --- | --- | --- |
| POST | `/api/v1/auth/register` | Register a new user |
| POST | `/api/v1/auth/login` | Authenticate a user |
| POST | `/api/v1/auth/logout` | Logout the current user |

### Video APIs

| Method | Endpoint | Description |
| --- | --- | --- |
| POST | `/api/v1/videos/upload` | Upload a new video |
| GET | `/api/v1/videos/{videoId}` | Get video details |
| DELETE | `/api/v1/videos/{videoId}` | Delete a video |

### Feed APIs

| Method | Endpoint | Description |
| --- | --- | --- |
| GET | `/api/v1/feed` | Get personalized "For You" feed |
| GET | `/api/v1/feed/following` | Get videos from followed creators |

### Interaction APIs

| Method | Endpoint | Description |
| --- | --- | --- |
| POST | `/api/v1/videos/{videoId}/like` | Like a video |
| POST | `/api/v1/videos/{videoId}/comment` | Add a comment |
| POST | `/api/v1/users/{creatorId}/follow` | Follow a creator |

### Search APIs

| Method | Endpoint | Description |
| --- | --- | --- |
| GET | `/api/v1/search?q={keyword}` | Search videos, creators, hashtags, and sounds |

### Sample Request

****POST**** /api/v1/videos/upload

> {
> 
> "userId": "user\_101",
> 
> "caption": "Beautiful sunset",
> 
> "hashtags": \[
> 
> "#nature",
> 
> "#travel"
> 
> \],
> 
> "privacy": "public"
> 
> }

### Sample Response

> {
> 
> "videoId": "vid\_98765",
> 
> "status": "uploaded",
> 
> "processingStatus": "queued",
> 
> "timestamp": "2026-07-23T10:30:45Z"
> 
> }

## 7\. Low Level Design

The Low-Level Design (LLD) describes the internal structure of the TikTok system by defining the key classes, their responsibilities, and interactions. It helps build a modular, maintainable, and scalable application.

- Identify the core classes required for video sharing and recommendations.
- Define the responsibilities and interactions between different modules.
- Apply SOLID principles and suitable design patterns for better maintainability.

### Core Classes

The TikTok system can be designed using the following core classes:

- ****User:**** Manages user profile, authentication, followers, and following information.
- ****Video:**** Stores video metadata such as title, description, duration, visibility, and upload details.
- ****Media:**** Manages video files, thumbnails, and storage locations.
- ****Feed:**** Generates and serves personalized "For You" and Following feeds.
- ****Recommendation:**** Processes user behavior and recommends relevant videos.
- ****Interaction:**** Handles likes, comments, shares, saves, and view counts.
- ****Notification:**** Sends notifications for likes, comments, follows, and mentions.
- ****VideoService:**** Manages video upload, retrieval, publishing, and deletion operations.
![[tiktok_uml_class_diagram.webp|tiktok_uml_class_diagram]]

### SOLID Principles

The TikTok system follows SOLID principles to keep the code modular, maintainable, and easy to extend.

- ****Single Responsibility Principle (SRP):**** Each service has one responsibility, such as VideoService for videos and RecommendationService for feed generation.
- ****Open/Closed Principle (OCP):**** New content types or recommendation algorithms can be added without modifying existing code.
- ****Liskov Substitution Principle (LSP):**** Different content types (ShortVideo, LiveVideo, Story) can be used wherever a generic Content object is expected.
- ****Interface Segregation Principle (ISP):**** Services expose only the methods required by their consumers.
- ****Dependency Inversion Principle (DIP):**** High-level services depend on abstractions, allowing databases, caches, or storage providers to be replaced easily.

### Design Patterns

| Design Pattern | Usage |
| --- | --- |
| Singleton | Database, Redis, and Object Storage connection management |
| Factory | Create different content types (Video, Live, Story) |
| Strategy | Different recommendation algorithms and ranking strategies |
| Observer | Notify followers when creators upload new videos |
| Builder | Build video metadata objects during upload |
| Adapter | Integrate external services such as CDN or cloud storage |

### 9\. Scalability & Performance

Scalability and performance ensure that the TikTok system can support millions of concurrent users while providing low-latency video uploads, fast streaming, and personalized recommendations.

- ****CDN (Content Delivery Network):**** Caches video content closer to users, reducing latency and enabling smooth video playback across different regions.
- ****Redis Cache:**** Stores frequently accessed data such as trending videos, recommendation cache, and user sessions to improve response time.
- ****Load Balancing:**** Distributes incoming requests across multiple application servers to ensure high availability and prevent server overload.
- ****Database Sharding & Replication:**** Sharding distributes user and video data across multiple databases, while replication improves read performance and fault tolerance.
- ****Asynchronous Processing:**** Kafka or other message queues handle video transcoding, notifications, recommendation updates, and analytics in the background.
- ****Horizontal Scaling:**** Additional Video, Feed, Recommendation, and Processing Services can be added dynamically to handle increasing traffic.
- ****Adaptive Video Streaming:**** Videos are transcoded into multiple resolutions and streamed using HLS or MPEG-DASH for smooth playback on different networks.
- ****Rate Limiting & Auto Scaling:**** Rate limiting prevents API abuse, while auto scaling automatically adjusts resources based on traffic demand.
![[tiktok_scalability_architecture.webp|tiktok_scalability_architecture]]

## 10\. Bottlenecks & Improvements

This section discusses the key challenges a TikTok-like system may face at scale and the techniques used to improve scalability, reliability, and performance.

- Identify common bottlenecks in video upload, streaming, and recommendation services.
- Apply techniques to improve availability, scalability, and fault tolerance.

### Common Bottlenecks

- ****Video Processing Bottleneck:**** Video transcoding is resource-intensive. Use asynchronous processing with worker nodes and message queues.
- ****Database Bottleneck:**** High read/write traffic can overload a single database. Use replication and sharding to distribute the load.
- ****Cache Misses:**** Cache misses increase database queries and response time. Use Redis to cache trending videos and user feeds.
- ****CDN Bottleneck:**** Serving videos from the origin server increases latency. Use a CDN to deliver content from edge locations.
- ****Recommendation Service Overload:**** Generating personalized feeds for millions of users is computationally expensive. Use distributed recommendation services and precomputed recommendations.

### Possible Improvements

- ****Auto Scaling:**** Automatically scale services based on traffic demand.
- ****Global CDN:**** Cache videos closer to users for faster streaming.
- ****Asynchronous Processing:**** Process uploads, transcoding, and notifications using Kafka and worker services.
- ****Geo-Distributed Deployment:**** Deploy services across multiple regions to reduce latency.
- ****Monitoring & Alerting:**** Continuously monitor system health and quickly detect failures.