---
title: "Quorum in System Design"
source: "https://www.geeksforgeeks.org/system-design/quorum-in-system-design/"
author:
  - "[[GeeksforGeeks]]"
published: 2024-03-08
created: 2026-09-22
description: "Your All-in-One Learning Portal: GeeksforGeeks is a comprehensive educational platform that empowers learners across domains-spanning computer science and programming, school education, upskilling, commerce, software tools, competitive exams, and more."
tags:
  - "clippings"
---
Quorum-based approaches are crucial in distributed systems for maintaining consistency and availability in the presence of network partitions or failures. A quorum refers to a subset of nodes in a distributed system that must agree on a specific decision or action for it to be considered valid. This article will detail the concept of quorum-based systems, including their role in distributed systems, and the different types of quorum.

![[Quorum-in-System-Design.webp|Quorum-in-System-Design]]

Important Topics for Quorum in System Design

## What is a Quorum?

Quorum, within distributed systems, denotes the minimum number of nodes or processes required to reach a consensus on a specific action or decision to validate it. This consensus is essential for maintaining system coherence and ensuring effective operation, even in the presence of failures or network partitions.

## Importance of Quorum In System Design

Quorum is crucial for maintaining consistency, availability, and fault tolerance in distributed systems. Here are some key points explaining the importance of quorum:

- [****Consistency****](https://www.geeksforgeeks.org/system-design/consistency-in-system-design/#:~:text=Consistency%20in%20system%20design%20refers,concurrent%20operations%20and%20network%20delays.): Quorum ensures consistency by requiring a majority of nodes to agree on an operation before it is considered successful. This prevents inconsistencies that can arise when different nodes have different views of the data.
- [****Availability****](https://www.geeksforgeeks.org/system-design/availability-in-system-design/): Quorum allows a system to remain available even if some nodes are unavailable. As long as a quorum of nodes is still operational, the system can continue to function and process requests.
- ****Fault Tolerance****: Quorum provides fault tolerance by allowing a system to tolerate the failure of a certain number of nodes. As long as a quorum of nodes is still operational, the system can continue to function normally.
- ****Split-Brain Scenario****: Quorum helps prevent a split-brain scenario, where the network is divided into two or more partitions, each believing it is the only active partition. By requiring a quorum of nodes to agree on operations, the system can avoid conflicts that can arise in such scenarios.
- ****Data Integrity****: Quorum ensures data integrity by requiring that a majority of nodes agree on changes to the data. This helps prevent data corruption and ensures that changes are applied consistently across the system.

Overall, quorum is a critical concept in system design for ensuring consistency, availability, fault tolerance, and data integrity in distributed systems

## Types of Quorum Systems in Distributed Systems

The most commonly used types for Quorum Systems are:

### 1\. Read Quorum

It is a number of nodes that must agree on the reading process for it to be valid. For Example, think of a read quorum as a vote among nodes in a distributed system to confirm the validity of a read process. Let's say we have ten nodes, and the read quorum is set at six.

- When a read action occurs, the system checks with at least six nodes to ensure the data's accuracy and availability. If it can't reach this minimum number, the read action is postponed until a quorum is achieved.
- This ensures data consistency and availability by requiring a minimum number of nodes to agree on read operations.

#### For Example:

> Consider a distributed database with 5 nodes. The Read Quorum is set to 3. When a read request is made, the system must read from at least 3 nodes and collect their responses to fulfill the request. This ensures that the data read is consistent across the majority of nodes.

### 2\. Write Quorum

A group of nodes in a distributed system that all have to agree on a write action for it to be valid is called a "write quorum. For Example with ten nodes and a write quorum of six, any write action requires the consensus of at least six nodes. This ensures that the data is consistent across the system and prevents conflicting updates and guarantees data consistency by mandating agreement among nodes for write operations.

#### For Example:

> Consider a distributed database with 5 nodes, the Write Quorum is set to 3. When a write request is made, the system must receive acknowledgments from at least 3 nodes confirming the write operation. This ensures that the data is written to a majority of nodes, maintaining consistency.

### 3\. Membership Quorum

Membership Quorum refers to the minimum number of nodes that must be present and operational for the system to consider itself healthy and operational. This is important for ensuring that the system can continue to function even if some nodes fail.

#### For Example:

> The Membership Quorum for this distributed system is set to 3 as well. This means that at least 3 nodes must be operational for the system to consider itself healthy and operational. If fewer than 3 nodes are available, the system may not be able to perform read or write operations.

### 4\. Configuration Quorum

Configuration Quorum refers to the minimum number of nodes that must agree on changes to the system's configuration, such as adding or removing nodes. This helps prevent conflicts and ensures that configuration changes are applied consistently across the system and Regulates modifications to system configuration parameters, requiring consensus among nodes for configuration changes.

#### For Example:

> The Configuration Quorum is set to 3 in this example. This means that any changes to the system's configuration, such as adding or removing nodes, must be approved by at least 3 nodes. This helps prevent conflicting configurations and ensures that changes are applied consistently.

## What value should we choose for Quorum?

Choosing the right value for quorum depends on several factors, including the number of nodes in the cluster, the desired level of fault tolerance, and the consistency requirements of the system. Here are some general guidelines for choosing a quorum value:

- ****Majority Quorum****: In clusters with an odd number of nodes, a majority quorum is often used. For example, in a cluster with 3 nodes, the quorum value would be 2. This ensures that the cluster can tolerate the failure of one node and still maintain a majority for decision-making.
- ****Majority-Plus-One Quorum****: In clusters with an even number of nodes, a majority-plus-one quorum is often used to avoid split-brain scenarios. For example, in a cluster with 4 nodes, the quorum value would be 3. This ensures that even if one node fails, there is still a majority of nodes available.
- ****Consistency Requirements****: The quorum value should also take into account the consistency requirements of the system. For example, if strong consistency is required, a higher quorum value may be needed to ensure that a majority of nodes agree on decisions.

Note: It is important to choose a quorum value that provides a balance between fault tolerance, consistency, and availability, based on the specific requirements of the system

## Quorum Consistency Models

Quorum Consistency Models are approaches used in distributed systems to achieve a balance between consistency, availability, and partition tolerance, often described in the CAP theorem. Here are some common quorum consistency models:

- [****Strong Consistency****](https://www.geeksforgeeks.org/system-design/strong-consistency-in-system-design/): In this model, every read receives the most recent write or an error. Strong consistency ensures that all nodes in the system have the same view of the data at all times. Achieving strong consistency often comes at the cost of availability during network partitions.
- [****Eventual Consistency****](https://www.geeksforgeeks.org/system-design/eventual-consistency-in-distributive-systems-learn-system-design/): Eventual consistency allows different nodes to have different views of the data at any given time, but guarantees that if no new updates are made to the data, eventually all updates will propagate through the system and all nodes will have the same view. This model prioritizes availability over consistency.
- ****Sequential Consistency****: Sequential consistency ensures that the results of any execution are the same as if the operations of all nodes were executed in some sequential order, even though they may have been executed concurrently. This model provides a stronger form of consistency than eventual consistency but may still allow some temporary inconsistencies.
- [****Causal Consistency****:](https://www.geeksforgeeks.org/system-design/causal-consistency-model-in-system-design/) Causal consistency ensures that if one operation causally precedes another, then all nodes will see those operations in the same order. This model relaxes the constraints of sequential consistency to allow for more concurrency while still ensuring a causal relationship between operations.
- ****Read Your Writes Consistency****: Read your writes consistency guarantees that after a write operation completes successfully, any subsequent read operation will return the value of the write operation. This model ensures that a client will always see its own writes, but does not necessarily guarantee consistency with respect to other clients' writes.

These quorum consistency models provide different trade-offs between consistency, availability, and partition tolerance, allowing system designers to choose the model that best suits the requirements of their application

### Four reasons why Quorum consistency models are important:

- ****Data Integrity:**** It ensures that the data used in processing and analytics pipelines is consistent and up-to-date, providing accurate results and insights.
- ****High Availability:**** With quorum-based consistency, customers can rely on the system to continue functioning even in the face of node failures or network partitions, ensuring uninterrupted data processing and analytics.
- ****Scalability:**** It allows to scale horizontally by distributing data and workload across multiple nodes, providing the ability to handle larger datasets.
- ****Fault Tolerance:**** By replicating data, It ensure fault tolerance and data durability. If a node fails, the data remains available on other nodes, preventing data loss and maintaining operational continuity.

## Quorum Consensus Algorithms

Quorum Consensus algorithms make sure that distributed systems are always consistent and reliable. By exchanging messages and deciding on a certain value, these algorithms help nodes in a distributed system come to a decision.

### 1\. Paxos

Paxos is a consensus algorithm that ensures that a distributed system can agree on a single value, even if some nodes in the system fail or messages are lost. Paxos uses a two-phase approach: first, a proposer suggests a value, then the acceptors (nodes) vote on whether to accept the proposed value. If a majority of acceptors agree, the value is chosen. Paxos is widely used in distributed databases and file systems.

### 2\. Raft algorithm

Raft is a consensus algorithm designed for ease of understanding and implementation. It uses a leader-follower approach, where one node is elected as the leader and coordinates the consensus process. The leader receives client requests, replicates them to followers, and ensures that a majority of nodes agree on the order of operations. Raft provides strong consistency guarantees and is used in systems like etcd and Consul.

### 3\. Zab

Zab is the consensus protocol used in Apache ZooKeeper, a distributed coordination service. Zab ensures that updates to ZooKeeper are atomic and ordered. It uses a leader-follower approach similar to Raft, where one node is elected as the leader and coordinates the ordering of updates. Zab provides high availability and fault tolerance for ZooKeeper.

These consensus algorithms play a crucial role in ensuring that distributed systems can operate correctly and maintain consistency even in the face of failures and network partitions. They are essential building blocks for building reliable and scalable distributed systems

## Quorum Configurations

Recomended Quorum Configurations are mentioned below:

### 1\. Quorum in Two-Node Configuration

In a two-node configuration, quorum configurations typically work as follows:

- ****Quorum of One****: Each node can make decisions independently without requiring agreement from the other node. This means that either node can process read or write operations without needing approval from the other node. However, this setup is not fault-tolerant because if one node fails, the entire system becomes unavailable.
- ****Quorum of Two****: To make the two-node configuration fault-tolerant, a quorum of two can be used. In this case, both nodes must agree on a decision for it to be considered valid. For example, if one node wants to write data, it must receive confirmation from the other node before committing the write. This setup ensures that the system remains available even if one node fails because the remaining node can continue to operate independently.

In summary, in a two-node configuration, a quorum of one means each node can make decisions independently, while a quorum of two means both nodes must agree on decisions to ensure fault tolerance.

![[Quorum-with-two-node-configuration.webp|Quorum-with-two-node-configuration]]

> Total votes: 3  
> Votes required for Quorum: 2

### 2\. Quorum Grater than Two-Node Configuration

When a cluster have more than two nodes Quorum devices are not required. As cluster surivives from failures of a single node withoutt a quorum device. In this situation we cannot start the cluster without a majority of nodes in the cluster.

- We can add a quorum device to a cluster that includes more than two nodes. It can survive as a cluster when that it has a majority of quorum votes, including the votes of the nodes and the quorum devices.
- Consequently, when adding a quorum device, consider the possible node and quorum device failures when choosing whether and where to configure quorum devices.

![[Each-pair-must-be-available-for-either-pair-to-survive.webp|Each-pair-must-be-available-for-either-pair-to-survive]]

> Total votes: 6  
> Votes required for Quorum: 4

![[Usually-applications-are-run-.webp|Usually-applications-are-run-]]

> Total votes: 5  
> Votes required for Quorum: 3

![[Combination-of-one-or-more.webp|Combination-of-one-or-more]]

> Total votes: 5  
> Votes required for Quorum: 3

## Use-Cases of Quorum in System Design

Quorum is a critical concept in distributed systems and is used in various scenarios to ensure consistency, availability, and fault tolerance. Here are some common use cases of quorum:

- ****Distributed Databases****: Quorum is used in distributed databases to ensure that read and write operations are consistent across multiple nodes. By requiring a quorum of nodes to agree on each operation, distributed databases can maintain data consistency even in the presence of network partitions or node failures.
- ****Consensus Algorithms****: Quorum is a fundamental concept in consensus algorithms like Paxos and Raft. These algorithms use a quorum of nodes to agree on the order of operations, ensuring that all nodes in the system reach a consistent state.
- ****File Systems****: Quorum is used in distributed file systems to ensure that file operations are consistent across multiple nodes. By requiring a quorum of nodes to agree on each operation, distributed file systems can maintain data consistency and availability.
- ****Configuration Management****: Quorum is used in configuration management systems to ensure that configuration changes are applied consistently across multiple nodes. By requiring a quorum of nodes to agree on each change, configuration management systems can prevent conflicts and ensure that changes are applied correctly.
- [****Load Balancing****](https://www.geeksforgeeks.org/system-design/what-is-load-balancer-system-design/): Quorum can be used in load balancing algorithms to ensure that requests are distributed evenly across a cluster of servers. By requiring a quorum of servers to agree on the load balancing decision, load balancers can ensure that requests are routed efficiently and reliably.

Overall, quorum is a versatile concept that is used in a wide range of distributed systems to ensure consistency, availability, and fault tolerance

## Benefits of Quorum in System Design

Below are the benefits of Quorum:

- [****Consistency****](https://www.geeksforgeeks.org/system-design/consistency-in-system-design/#:~:text=Consistency%20in%20system%20design%20refers,concurrent%20operations%20and%20network%20delays.)****:**** It keeps systems consistent by having a certain number of nodes to agree on a decision or action before it can be considered valid.
- ****Data Integrity:**** It ensures that the data used in processing and analytics pipelines is consistent and up-to-date, providing accurate results and insights.
- [****High Availability****](https://www.geeksforgeeks.org/system-design/what-is-high-availability-in-system-design/#:~:text=High%20availability%20in%20system%20design%20refers%20to%20the%20ability%20of,%2C%20typically%2099.9%25%20or%20higher.)****:**** With quorum-based consistency, customers can rely on the system to continue functioning even in the face of node failures or network partitions, ensuring uninterrupted data processing and analytics.
- [****Scalability****](https://www.geeksforgeeks.org/system-design/what-is-scalability/)****:**** It allows to scale horizontally by distributing data and workload across multiple nodes, providing the ability to handle larger datasets.
- ****Fault Tolerance:**** By replicating data, It ensure fault tolerance and data durability. If a node fails, the data remains available on other nodes, preventing data loss and maintaining operational continuity.

## Challenges of Quorum in System Design

Below are the challenges of Quorum:

- ****Complexity:**** Implementing quorum-based systems is difficult, and it needs to be carefully designed and tested to make it to work.
- ****Performance:**** It can reduce performance because they need communication between nodes, which can slow down and increase latency.
- ****Maintenance:**** It need to be maintained on a regular basis to make sure they stay consistent and ready. this process is time consuming.
- ****Configuration:**** It can be difficult to set up quorum-based systems because the size and type of the quorum must be carefully chosen to meet specific requirements for consistency and availability.