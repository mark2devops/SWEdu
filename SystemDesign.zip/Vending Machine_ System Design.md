---
title: "Vending Machine: System Design"
source: "https://www.geeksforgeeks.org/system-design/vending-machine-high-level-system-design/"
author:
  - "[[GeeksforGeeks]]"
published: 2023-09-27
created: 2026-09-23
description: "Your All-in-One Learning Portal: GeeksforGeeks is a comprehensive educational platform that empowers learners across domains-spanning computer science and programming, school education, upskilling, commerce, software tools, competitive exams, and more."
tags:
  - "clippings"
---
Designing a Vending Machine means building a system where users can select a product, make payment, and receive the item automatically. In an interview, the main focus is on product selection, inventory tracking, payment handling, and correct state transitions.

- Users should be able to view available products, select an item, and make payment.
- The system should dispense the correct product, return change when needed, and update inventory after every purchase.
![[vending_machine.webp|vending_machine]]

## 1\. Problem Statement

We need to design a Vending Machine system that allows users to buy products such as snacks or drinks without human assistance. The system should manage product availability, payments, dispensing, and refunds correctly.

- The machine should validate the selected product and payment before dispensing the item.
- It should handle insufficient balance, out-of-stock products, cancellations, refunds, and inventory updates reliably.

## 2\. System Requirements

Before designing the Vending Machine, we need to identify its functional and non-functional requirements. These requirements define what the machine should do and how reliably it should work.

### Functional Requirements

- Users should be able to view available products and their prices.
- Users should be able to select a product for purchase.
- The machine should accept supported payment methods such as cash, card, or digital payment.
- The system should verify that enough balance has been provided before dispensing the product.
- The machine should dispense the selected product and return change when required.
- The inventory should be updated after every successful purchase.
- The system should handle out-of-stock products, payment failures, cancellations, and refunds.

### Non-Functional Requirements

- ****Reliability:**** The machine should dispense the correct product after successful payment.
- ****Consistency:**** Inventory and payment status should always remain accurate.
- ****Low Latency:**** Product selection and payment processing should complete quickly.
- ****Availability:**** The machine should remain operational whenever products and required hardware are available.
- ****Security:**** Payment information and machine operations should be protected from unauthorized access.
- ****Maintainability:**** Products, prices, inventory, and payment components should be easy to update or replace.

## 3\. Capacity Estimation

Before designing the architecture, we estimate the expected products, transactions, inventory size, and request volume. These estimates help us decide the storage, hardware, and processing requirements.

### Assumptions

| ****Parameter**** | ****Assumption**** |
| --- | --- |
| Product Types | 50 |
| Slots per Product | 20 |
| Total Product Capacity | 1,000 Items |
| Transactions per Day | 2,000 |
| Average Transaction Record | 1 KB |
| Payment Methods | Cash, Card, UPI |

### 3.1 Inventory Capacity

Assume the vending machine has 50 product types with around 20 items per product.

> Total Capacity = 50 × 20  
> \= 1,000 Items

The system should continuously track the quantity and availability of every product.

### 3.2 Transactions Per Second

Assume the machine handles around 2,000 transactions per day.

> TPS = 2,000 / 86,400  
> ≈ 0.02 transactions/second

Traffic is low compared to large distributed systems, but each transaction must still be processed correctly.

### 3.3 Storage Estimation

Assume each transaction record requires around 1 KB.

> Daily Storage = 2,000 × 1 KB  
> ≈ 2 MB/day

For one year:

> Yearly Storage ≈ 730 MB

### 3.4 Peak Usage

During office breaks, railway stations, airports, or events, several users may try to use the machine within a short time.

The system should process product selection, payment, dispensing, and inventory updates sequentially and reliably so the same item is not sold twice.

## 4\. High Level Design

The High-Level Design (HLD) shows how different components of the Vending Machine work together to handle product selection, payment, dispensing, and inventory updates.

![[frame_3652.webp|frame_3652]]

Vending Machine System Architecture

### Core Components

- ****User Interface:**** Allows users to browse products, view prices and availability, select products, and see payment and transaction status.
- ****API Gateway:**** Acts as the single entry point for client requests and routes them to the appropriate application services.
- ****Load Balancer:**** Distributes incoming requests across available backend instances to improve scalability and availability.
- ****Product Service:**** Manages product information such as product name, price, slot number, and product availability.
- ****Inventory Service:**** Tracks product quantities and updates inventory when products are purchased or restocked.
- ****Payment Service:**** Handles payment processing and verifies whether the required amount has been successfully paid.
- ****Transaction Service:**** Manages the complete purchase workflow and maintains transaction states such as pending, successful, failed, or cancelled.
- ****Dispense Service:**** Controls the vending machine mechanism to release the selected product after successful payment.
- ****Payment Gateway:**** Integrates with external payment providers to process card and digital payments securely.
- ****Notification Service:**** Sends notifications or status updates related to payments, purchases, failures, or refunds.
- ****Message Queue:**** Enables asynchronous communication between services and queues tasks that can be processed in the background.
- ****Redis Cache:**** Stores frequently accessed data such as product information and availability to reduce database load and improve response time.
- ****Database:**** Stores persistent data such as products, inventory, prices, users, and transaction records.
- ****Object Storage:**** Stores files or large objects such as product images, receipts, logs, or other machine-related documents.
- ****Background Workers:**** Process asynchronous tasks from the message queue, such as notifications, transaction processing, and other long-running operations.

### Request Flow

![[frame_3653.webp|frame_3653]]

Vending Machine System- Request Flow Diagram

- The user selects a product.
- The Product Service checks its price and availability.
- The Inventory Service confirms that the product is in stock.
- The user makes the required payment.
- The Payment Service validates the payment.
- The Transaction Service marks the purchase as `PAID`.
- The Dispense Service releases the selected product.
- Inventory is reduced after successful dispensing.
- If required, the Change Service returns the remaining amount.
- The transaction is marked as `COMPLETED`.

### Data Flow

- Product and inventory information is read from local storage or the Database.
- Payment details are passed to the Payment Service for validation.
- The Dispense Service communicates with vending machine hardware to release the product.
- Inventory is updated only after successful dispensing.
- Failed or cancelled transactions are handled by the Refund Service.
- Admin operations update product, price, and inventory information.

## 5\. Technology Stack

Before designing the data model, it is helpful to identify which technologies can be used by different components of the Vending Machine system.

| ****Component**** | ****Technology**** |
| --- | --- |
| User Interface | Embedded UI, Touchscreen Application |
| Backend Logic | Java, C++, Python |
| Local Storage | SQLite, Embedded Database |
| Cache | In-Memory Cache |
| Payment Integration | Card Reader SDK, UPI/QR APIs |
| Hardware Communication | GPIO, Serial Communication, MQTT |
| Inventory Management | Local Database, REST API |
| Transaction Processing | Local Service / Microservice |
| Logging | Local Logs, ELK Stack |
| Monitoring | Prometheus, Grafana |
| Authentication | Admin PIN, JWT |
| Cloud Sync | REST API, MQTT |
| Containerization | Docker (for cloud/backend services) |

## 6\. Data Model Design

The data model defines how the Vending Machine stores and manages products, inventory, transactions, payments, and machine information. A good schema ensures correct stock tracking and reliable purchase processing.

- Identify the core entities required for product selection, payment, dispensing, and inventory management.
- Define relationships between products, transactions, and payments.
- Select the appropriate storage model based on consistency and simplicity.

### Core Entities

The Vending Machine system consists of the following core entities:

![[frame_3658.webp|frame_3658]]

Vending Machine System ER Diagram

- ****Product:**** Stores product name, price, type, and product information.
- ****Inventory:**** Stores available quantity and slot information for each product.
- ****Transaction:**** Stores selected product, amount, transaction status, and timestamp.
- ****Payment:**** Stores payment method, amount, and payment status.
- ****VendingMachine:**** Stores machine ID, location, and machine status.
- ****Admin:**** Stores authorized staff information used for refill and maintenance operations.

### Database Selection

For a vending machine, a simple local database is usually sufficient.

- SQL Database such as SQLite can store products, inventory, transactions, and payment records.
- In-Memory Storage can maintain current product availability for faster access.
- Cloud Database can optionally store data from multiple vending machines for centralized monitoring, reporting, and inventory management.

## 7\. API Design

The API design defines how the Vending Machine components communicate for product selection, payment, dispensing, inventory updates, and admin operations.

- Keep the APIs simple because the system has a limited number of core operations.
- Use secure admin APIs for refill, pricing, and maintenance actions.

### Product APIs

| ****Method**** | ****Endpoint**** | ****Description**** |
| --- | --- | --- |
| GET | `/api/v1/products` | Get available products |
| GET | `/api/v1/products/{productId}` | Get product details |
| PUT | `/api/v1/products/{productId}` | Update product price or details |

### Inventory APIs

| ****Method**** | ****Endpoint**** | ****Description**** |
| --- | --- | --- |
| GET | `/api/v1/inventory` | Get current inventory |
| GET | `/api/v1/inventory/{productId}` | Check product stock |
| PUT | `/api/v1/inventory/{productId}` | Refill or update stock |

### Transaction APIs

| ****Method**** | ****Endpoint**** | ****Description**** |
| --- | --- | --- |
| POST | `/api/v1/transactions` | Start a new purchase |
| GET | `/api/v1/transactions/{transactionId}` | Get transaction status |
| POST | `/api/v1/transactions/{transactionId}/cancel` | Cancel a transaction |

### Payment APIs

| ****Method**** | ****Endpoint**** | ****Description**** |
| --- | --- | --- |
| POST | `/api/v1/payments` | Process payment |
| GET | `/api/v1/payments/{paymentId}` | Get payment status |
| POST | `/api/v1/payments/{paymentId}/refund` | Process refund |

### Dispense API

| ****Method**** | ****Endpoint**** | ****Description**** |
| --- | --- | --- |
| POST | `/api/v1/dispense` | Dispense the selected product |

### Sample Request

****POST**** `/api/v1/transactions`

> `{`  
> `  "productId": "prod_101",`  
> `  "paymentMethod": "UPI",`  
> `  "amount": 50`  
> `}`

### Sample Response

> `{`  
> `  "transactionId": "txn_501",`  
> `  "productId": "prod_101",`  
> `  "status": "PAID",`  
> `  "amount": 50`  
> `}`

## 8\. Low Level Design

The Low-Level Design (LLD) describes the internal structure of the Vending Machine by defining the main classes, their responsibilities, and their interactions.

### Core Classes

The Vending Machine system can be designed using the following core classes:

![[frame_3659.webp|frame_3659]]

Vending Machine UML Class Diagram

- ****Product:**** Stores product ID, name, price, and product details.
- ****Inventory:**** Manages product quantity, slots, and stock availability.
- ****Transaction:**** Represents a purchase and stores product, amount, status, and timestamp.
- ****Payment:**** Handles payment amount, method, and payment status.
- ****VendingMachine:**** Coordinates product selection, payment, dispensing, and inventory updates.
- ****DispenseService:**** Controls the mechanism used to release the selected product.
- ****Admin:**** Manages product refill, pricing, and machine maintenance.

### SOLID Principles

The Vending Machine follows SOLID principles to keep the system modular, maintainable, and easy to extend.

- ****Single Responsibility Principle (SRP):**** Each class handles one responsibility. For example, Inventory manages stock while Payment handles payment operations.
- ****Open/Closed Principle (OCP):**** New product types or payment methods can be added without modifying existing core logic.
- ****Liskov Substitution Principle (LSP):**** Different payment implementations can be used through a common payment interface.
- ****Interface Segregation Principle (ISP):**** Classes depend only on the methods required for their functionality.
- ****Dependency Inversion Principle (DIP):**** High-level vending logic depends on abstractions rather than specific payment or hardware implementations.

### Design Patterns

| ****Design Pattern**** | ****Usage**** |
| --- | --- |
| ****Singleton**** | Maintain a single VendingMachine instance |
| ****Factory**** | Create different product or payment objects |
| ****Strategy**** | Handle different payment and pricing strategies |
| ****State**** | Manage machine states such as Idle, ProductSelected, PaymentPending, and Dispensing |

## 9\. Scalability & Performance

Scalability and performance ensure that the Vending Machine system can support many machines, products, payments, and inventory updates while keeping transactions fast and reliable.

![[frame_3660.webp|frame_3660]]

Vending Machine - Scalability Architechture

- ****Local Processing:**** Product selection, inventory checks, and basic transaction logic can run locally so the machine continues working even with limited network connectivity.
- ****Caching:**** Frequently accessed product and inventory data can be kept in memory for faster response.
- ****Cloud Synchronization:**** Multiple vending machines can periodically sync inventory, sales, and machine status with a central backend.
- ****Horizontal Scaling:**** Additional backend service instances can be added as the number of connected vending machines grows.
- ****Asynchronous Processing:**** Sales logs, inventory updates, alerts, and analytics can be processed through a message queue.
- ****Database Replication:**** Central databases can use replicas for better availability and reporting performance.
- ****Offline Mode:**** The machine should continue basic operations when the network is temporarily unavailable and sync data later.
- ****Inventory Optimization:**** Low-stock information can be sent to the backend so refill operations can be planned efficiently.
- ****Payment Reliability:**** Payment requests should use retries and idempotency to prevent duplicate charges.
- ****Monitoring:**** Machine health, stock levels, payment failures, and hardware issues should be monitored remotely.

## 10\. Bottlenecks & Improvements

This section discusses the common problems a Vending Machine system may face and the techniques used to keep purchases, payments, inventory, and hardware operations reliable.

### Common Bottlenecks

- ****Product Dispense Failure:**** Payment may succeed, but the machine may fail to release the selected product.
- ****Inventory Mismatch:**** The system may show a product as available even when the physical slot is empty.
- ****Payment Failure:**** Network or payment gateway issues may leave a transaction in a pending state.
- ****Hardware Failure:**** Coin acceptors, card readers, sensors, or dispensing motors may stop working.
- ****Network Connectivity:**** Cloud-connected machines may temporarily lose internet access.
- ****Duplicate Payment:**** Retrying a failed payment request may accidentally charge the user more than once.
- ****Low Stock:**** Products may become unavailable if refill information is not updated on time.

### Possible Improvements

- ****Sensor Validation:**** Use sensors to confirm that the selected product was actually dispensed before completing the transaction.
- ****Automatic Refund:**** Refund the payment if the product cannot be dispensed successfully.
- ****Offline Mode:**** Allow basic vending operations to continue locally when network connectivity is unavailable.
- ****Idempotency:**** Use unique transaction IDs to prevent duplicate payments during retries.
- ****Inventory Synchronization:**** Keep physical inventory and system inventory synchronized after every successful dispense or refill.
- ****Remote Monitoring:**** Monitor machine health, stock levels, payment failures, and hardware status from a central system.
- ****Low-Stock Alerts:**** Automatically notify operators when product quantities fall below a configured threshold.
- ****Retry & Failover:**** Retry temporary payment or cloud-sync failures and use fallback services when possible.