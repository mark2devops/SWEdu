---
title: "Strong Consistency in System Design"
source: "https://www.geeksforgeeks.org/system-design/strong-consistency-in-system-design/"
author:
  - "[[GeeksforGeeks]]"
published: 2024-02-26
created: 2026-09-22
description: "Your All-in-One Learning Portal: GeeksforGeeks is a comprehensive educational platform that empowers learners across domains-spanning computer science and programming, school education, upskilling, commerce, software tools, competitive exams, and more."
tags:
  - "clippings"
---
Strong Consistency is a consistency model in distributed systems that ensures all users and nodes see the same data immediately after an update. It guarantees that every read operation returns the most recent committed value, making the system appear as a single, consistent source of truth.

- Once data is updated, all users and nodes instantly see the latest value.
- Prevents temporary inconsistencies and ensures all reads return the most recent committed data.

> ****Example:**** In an online banking system, after money is transferred from one account to another, all users and services immediately see the updated account balance.

![[Strong-consistency.webp|Strong-consistency]]

## Consistency

[Consistency](https://www.geeksforgeeks.org/system-design/consistency-in-system-design/) refers to the ability of a distributed system to ensure that all nodes reflect the same state of data at any point in time-even during concurrent reads/writes or network delays. When multiple clients interact with the same data, consistency guarantees that they all see a correct and unified version of the truth.

- ****Read consistency:**** Any read operation on the data will return the most recent write value or a value that satisfies specific consistency guarantees
- ****Write consistency:**** When a write operation is performed, the data will be propagated to all relevant nodes in the system, ensuring that all replicas are updated with the latest value before the operation is considered successful.

## Importance of Data Consistency

Data consistency ensures that all users and systems access the same accurate and up-to-date information, maintaining reliability across the application.

- A consistent system behaves predictably and reliably, regardless of access time or method.
- It helps maintain data integrity, preventing corruption or mismatched values.
- Users trust the system more when they always see accurate and synchronized data.
- It improves user experience and builds confidence in the system’s reliability.

## Types of Strong Consistency

There are two commonly discussed forms of strong consistency:

****1\. Sequential Consistency:**** Sequential consistency guarantees that all operations appear to execute in a single [sequential](https://www.geeksforgeeks.org/system-design/sequential-consistency-in-distributive-systems/) order, and all processes observe that same order. However, this order does not necessarily have to match real-time execution.

****2\. Linearizability:**** [Linearizability](https://www.geeksforgeeks.org/system-design/strict-consistency-or-linearizability-in-system-design/) is a stronger consistency model that guarantees operations appear to occur instantaneously at some point between their start and end times. It preserves both a single global order of operations and real-time ordering, ensuring all processes observe the same most recent value.

## Ways to achieve Strong Consistency

Strong consistency can be achieved using several techniques that ensure all nodes in a distributed system maintain the same data state.

- ****Linearizability****: Ensures that every operation appears to occur instantaneously at a single point in time. Reads always return the most recent completed write, preserving real-time ordering.
- ****Synchronous Replication:**** Data is written to all replicas before the operation is confirmed. This keeps all copies synchronized and prevents stale reads.
- ****Quorum-Based Protocols:**** Protocols such as Paxos, Raft, and quorum consensus require a majority of replicas to agree before committing changes. This agreement helps maintain a consistent view of data across the system.
- ****Distributed Locking****: Uses locks to control concurrent access to shared resources. This prevents conflicting updates and ensures data consistency.
- ****Two-Phase Commit (2PC):**** A distributed transaction protocol that coordinates multiple nodes before committing changes. All participating nodes must agree to commit or abort the transaction, ensuring consistency.

## Challenges with Strong Consistency

The challenges in achieving strong consistency are:

- Maintaining consistent data across multiple nodes requires additional communication and coordination, impacting performance.
- Implementing and maintaining strong consistency protocols can be complex and require significant expertise.
- As the number of nodes increases, the cost of maintaining consistency can become prohibitive.
- Strong consistency guarantees can be difficult to maintain in the presence of network failures or node outages.
- Synchronization mechanisms required for strong consistency introduce latency in read and write operations, impacting overall system performance.

## Example of Strong Consistency

The example to understand the Strong Consistency is:

![[strong-example.png|strong-example]]

- User 1 sends a write request to Node C to update Val1 to 100.
- Node C receives the request, updates the value to 100, and propagates the update to Nodes A, B and D.
- The response from Node C is sent back to User 1
- Now the User 2 immediately sends a read request to Node D to get the value of Val1.
- Since the system follows strong consistency, Node D has already received the update from Node C and reflects the latest value of Val1, which is 100.
- Node D responds to User 2 with the value 100.