---
title: "Object Diagrams | Unified Modeling Language (UML)"
source: "https://www.geeksforgeeks.org/system-design/unified-modeling-language-uml-object-diagrams/"
author:
  - "[[GeeksforGeeks]]"
published: 2017-10-25
created: 2026-09-23
description: "Your All-in-One Learning Portal: GeeksforGeeks is a comprehensive educational platform that empowers learners across domains-spanning computer science and programming, school education, upskilling, commerce, software tools, competitive exams, and more."
tags:
  - "clippings"
---
Object diagrams are UML diagrams that show the instances of classes and the relationships between them at a specific point in time. They provide a snapshot of how objects interact within a system during execution.

- Displays objects, their attributes, and links between them.
- Helps in understanding the real-time structure and behavior of a system.

> ****Example:**** A `Student` object connected to a `Course` object showing a student enrolled in a course.

### Object

An object is a specific instance of a class that contains its own unique data and behavior. A class acts as a blueprint, while objects are the real entities created from it.

- Represents a real-world entity with attributes and actions.
- Each object has unique values for its attributes.

> ****Example:**** Student s1 with name = "Rahul" and rollNo = 101 is an object of the Student class.

### Classifier

A classifier in UML is an element that defines a common set of features such as attributes, methods, and operations for a group of instances.

- Used to group elements that share common properties.
- Classes, objects, components, and nodes can act as classifiers in UML.

> ****Example:**** A `Student` class is a classifier because multiple student objects can be created from it.

## Object Diagram Notations

The object diagram in UML uses specific notations to represent instances of classes and their relationships at a particular moment in time.

![[Object-Diagram-Notations-222.jpg|Object-Diagram-Notations-222]]

### 1\. Objects or Instance specifications

Represents an instance of a class that exists within the system.

- Shown as a rectangle containing the object name and details.
- Multiple instance specifications can be used to represent changes in an object over time.

![[object-box.jpg|object-box]]

### 2\. Attributes and Values

Represent the properties of an object and their current values.

- Listed inside the object box beneath the object name.
- Show the state and data associated with a specific object instance.

### 3\. Link

Represents a relationship or connection between two objects in an object diagram.

- Shown as a solid line connecting the related objects.
- Specifies how instance specifications or objects are associated with each other.

![[links.jpg|links]]

> ****For Example**** \- In the figure below, an object of class Student is linked to an object of class College.

![[An-object-diagram-using-a-link-and-3-objects---(2).webp|An-object-diagram-using-a-link-and-3-objects---(2)]]

### 4\. Dependency Relationships

We use a dependency relationship to show when one element depends on another element. A dependency is used to depict the relationship between dependent and independent entities in the system.

- Any change in the definition or structure of one element may cause changes to the other.
- This is a unidirectional kind of relationship between two objects.

![[Dependency-Relationship-notation.jpg|Dependency-Relationship-notation]]

> ****For example -**** In the figure below, an object of Player class is dependent (or uses) an object of Bat class.

![[An-object-diagram-using-a-dependency-An-object-diagram-using-a-dependency--(1).webp|An-object-diagram-using-a-dependency-An-object-diagram-using-a-dependency--(1)]]

### 5\. Association

Association is a relationship between two objects or classes where one object references another. In UML, it is represented by a line connecting object boxes, and it can be uni-directional or bi-directional using arrows.

![[Association-2.jpg|Association-2]]

> ****For example -**** The object of Order class is associated with an object of Customer class.

![[An-object-diagram-using-association---(1).webp|An-object-diagram-using-association---(1)]]

### 6\. Aggregation

Aggregation represents a "has a" relationship. We use a hollow diamond on the containing object with a line which joins it to the contained object.

- Aggregation is a specific form of association.
- It is a kind of parent-child relationship however it isn't inheritance.
- Aggregation occurs when the lifecycle of the contained objects does not strongly depend on the lifecycle of container objects.

![[Aggregation.jpg|Aggregation]]

> ****For example -**** A library has an aggregation relationship with books. Library has books or books are a part of library. The existence of books is independent of the existence of the library.

![[An-object-diagram-using-aggregation---(2).webp|An-object-diagram-using-aggregation---(2)]]

### 7\. Composition

Represents a strong whole-part relationship where the child object depends on the parent object.

- Shown using a filled diamond at the parent object's end.
- The child object cannot exist independently of the parent object.

![[composition-diagram.jpg|composition-diagram]]

> Consider the example of a boy Gurkaran: Gurkaran is composed of legs and arms. Here Gurkaran has a composition relationship with his legs and arms. Here legs and arms can't exist without the existence of their parent object.

![[An-object-diagram-using-composition----(1).webp|An-object-diagram-using-composition----(1)]]

## Purpose of Object Diagrams

The main purpose of using object diagrams is:

- They offer a detailed view of how objects interact with each other in specific scenarios.
- Proper design and analysis of applications can be faster and efficient.
- Object diagrams are beneficial during the implementation phase of software development.
- Promoting a shared understanding of specific instances and their relationships, facilitating collaboration among team members.

## Benefits

Object diagrams help visualize object relationships, interactions, and system behavior, making development and testing more effective.

- ****Detailed Relationship View:**** Provides a clear understanding of object relationships, dependencies, and collaborations within the system.
- ****Integration Testing Support:**** Assists in testing interactions between objects to ensure smooth communication among system components.
- ****Code Validation:**** Helps verify that the implemented code matches the intended design and object relationships.
- ****Scenario Visualization:**** Clearly illustrates specific use cases and object behavior in different system situations.

## Use Cases of Object Diagrams

Object diagrams are used to visualize real object relationships and interactions at a specific point in time, helping in development, testing, and system understanding.

- ****Communication and Collaboration:**** Improves communication among team members and stakeholders by clearly showing object relationships.
- ****Test Case Design:**** Assists testers in creating test cases based on object behavior and interactions.
- ****Debugging and Troubleshooting:**** Helps identify and fix issues by analyzing object states at a particular moment.
- ****Training and Documentation:**** Useful for training new team members and improving system documentation through visual representation.