---
title: "Difference between High Level Design(HLD) and Low Level Design(LLD)"
source: "https://www.geeksforgeeks.org/system-design/difference-between-high-level-design-and-low-level-design/"
author:
  - "[[GeeksforGeeks]]"
published: 2020-10-10
created: 2026-09-23
description: "Your All-in-One Learning Portal: GeeksforGeeks is a comprehensive educational platform that empowers learners across domains-spanning computer science and programming, school education, upskilling, commerce, software tools, competitive exams, and more."
tags:
  - "clippings"
---
[System design](https://www.geeksforgeeks.org/system-design/system-design-tutorial/) involves creating both a High-Level Design (HLD), which is like a roadmap showing the overall plan, and a Low-Level Design (LLD), which is a detailed guide for programmers on how to build each part.

- It ensures a well-organized and smoothly functioning project.
- High-Level Design and Low-Level Design are the two main aspects of System Design.
![[1 1.webp|1]]

## High Level Design(HLD)

[High-level design or HLD](https://www.geeksforgeeks.org/system-design/what-is-high-level-design-learn-system-design/) describes the overall architecture of a system and shows how different components interact. It outlines major modules, system structure, and relationships between services.

HLD includes:

- System architecture showing the major components and their interactions.
- Database design and high-level data flow between modules.
- Overview of systems, services, platforms, and their relationships.
- Description of hardware, software interfaces, and user interfaces.
- User workflow and key performance considerations.

## Low Level Design(LLD)

[LLD or Low-Level Design](https://www.geeksforgeeks.org/system-design/what-is-low-level-design-or-lld-learn-system-design/), is a phase in the software development process where detailed system components and their interactions are specified.

- It describes detailed description of each and every module means it includes actual logic for every system component and it goes deep into each modules specification.
- It is also known as micro level/detailed design.
- It is created by designers and developers.
- It involves converting the high-level design into a more detailed blueprint, addressing specific algorithms, data structures, and interfaces.
- LLD serves as a guide for developers during coding, ensuring the accurate and efficient implementation of the system’s functionality.

## High Level Design Vs Low Level Design

High Level Design (HLD) defines the overall system architecture, while Low Level Design (LLD) explains the detailed internal logic and component-level implementation.

| HIGH-LEVEL DESIGN | LOW-LEVEL DESIGN |
| --- | --- |
| High Level Design is the general system design means it refers to the overall system design. | Low Level Design is like detailing HLD means it refers to component-level design process. |
| High Level Design in short called as HLD. | Low Level Design in short called as LLD. |
| It is also known as macro level/system design. | It is also known as micro level/detailed design. |
| Furthermore, it describes the overall description/architecture of the application. | It describes detailed description of each and every module. |
| High Level Design expresses the brief functionality of each module. | Low Level Design expresses details of functional logic of the module. |
| It is created by solution architect. | It is created by designers and developers. |
| Here in High Level Design the participants are design team, review team, and client team. | Here in Low Level Design participants are design team, Operation Teams, and Implementers. |
| It is created first means before Low Level Design. | It is created second means after High Level Design. |
| In HLD the input criteria is Software Requirement Specification (SRS). | In LLD the input criteria is reviewed High Level Design (HLD). |
| In HLD the output criteria is database design, functional design and review record. | In LLD the output criteria is program specification and unit test plan. |

What is the main purpose of High-Level Design (HLD)?

- A
	To write the program code
- B
	To describe the overall system architecture and structure
- C
	To test the system modules
- D
	To deploy the application

Who is mainly responsible for creating the High-Level Design (HLD)?

What does Low-Level Design (LLD) mainly focus on?

Which design is created first in the system design process?

What is the main input for creating Low-Level Design (LLD)?

![[sucess-img 8.png|success]]

Quiz Completed Successfully

Score:0/5

Accuracy:0%