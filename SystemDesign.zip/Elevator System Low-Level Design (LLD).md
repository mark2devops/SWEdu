---
title: "Elevator System Low-Level Design (LLD)"
source: "https://www.geeksforgeeks.org/system-design/elevator-system-low-level-design-lld/"
author:
  - "[[GeeksforGeeks]]"
published: 2024-05-23
created: 2026-09-23
description: "Your All-in-One Learning Portal: GeeksforGeeks is a comprehensive educational platform that empowers learners across domains-spanning computer science and programming, school education, upskilling, commerce, software tools, competitive exams, and more."
tags:
  - "clippings"
---
Elevator System is one of the famous [Low-Level Design(LLD)](https://www.geeksforgeeks.org/system-design/what-is-low-level-design-or-lld-learn-system-design/) problems being asked in interviews. We are here going to discuss this problem along with its requirements, [use-cases diagram](https://www.geeksforgeeks.org/system-design/use-case-diagram/), [class diagram](https://www.geeksforgeeks.org/system-design/unified-modeling-language-uml-class-diagrams/) and implementation.

Let's understand this with the help of Diagram:

![[elevator_system.webp|elevator_system]]

Elevator System

## Requirements of Elevator System Low-Level Design (LLD)

1. ****Elevators and Floors****: The system shall include 3 elevator cars. The elevators will service a building that has up to 15 floors.
2. ****Elevator Movemen**** t: Elevators shall be capable of moving up, moving down, or remaining idle.
3. ****Elevator Door Operation****: Elevator doors shall open only when the elevator is idle and not in motion.
4. ****Floor Access****: Each elevator shall be capable of stopping at every floor in the building.
5. ****Outside Control Panel****: An external panel with up and down buttons shall be available on each floor to call an elevator.
6. ****Inside Control Panel****: Inside each elevator, a control panel with buttons for all floors and door operation (open/close) shall be provided.
7. ****Displays****: Each elevator shall have internal and external displays. External displays shall indicate the current floor and the direction of movement. Internal displays shall show the current floor, the direction of movement, and the elevator’s capacity.
8. ****Floor Panels and Displays****: Each floor shall have a panel with buttons for calling elevators and displays indicating the status of each elevator.
9. ****Passenger Directions****: The system shall accommodate multiple passengers going to different floors and in different directions simultaneously.
10. ****Elevator System Control****: The system shall manage elevator movement, door operations, and monitor elevator statuses.
11. ****Smart Dispatch System****: Upon a passenger calling for an elevator, the system shall intelligently assign the most suitable elevator based on its current location and trajectory.
12. ****Capacity****: Each elevator shall have a maximum capacity of eight people or 680 kilograms.
13. ****Maximum Number of Elevators****: The building shall be equipped with up to three elevators to service all floors.

## Use-Case Diagram of Elevator System Low-Level Design (LLD)

Below is the use case diagram for the Elevator Low-Level Design(LLD)

![[Use-Case-Diagram-of-Elevator-System-Low-Level-Design-(LLD).webp|Use-Case-Diagram-of-Elevator-System-Low-Level-Design-(LLD)]]

## Class Diagram of Elevator System Low-Level Design (LLD)

### 1\. Enums are being used in this problem:

![[Enum.jpg|Enum]]

### 2\. Button interface and its Implementation Classes:

![[Diagrams.jpg|Diagrams]]

### 3\. Display, Door and Floor classes:

![[Display-Door-and-Floor-Classes.jpg|Display-Door-and-Floor-Classes]]

### 4\. Panel and its implementation classes:

![[Pannel-and-its-Implementation-Classes-.jpg|Pannel-and-its-Implementation-Classes-]]

### 5\. Elevator and Elevator System Classes:

****Note:**** We will implement Singleton Design Pattern in ElevatorSystem class, as we want to insure to have only one object in the system.

![[Elevator-and-Elevator-System-Classes.jpg|Elevator-and-Elevator-System-Classes]]

## Relationship between classes

Solid diamond arrow representing composition and hollow diamond representing aggregation.

![[Relationship-between-classes.webp|Relationship-between-classes]]

## Implementation of the Elevator System Low-Level Design (LLD)

### 1\. Project Folder Structure

![[Screenshot-2024-05-08-205626.png|Screenshot-2024-05-08-205626]]

Project Folder structure

### 2\. Direction.
C++
```
enum class Direction {
    UP,
    DOWN,
    IDLE
};
```
Java
```
public enum Direction {
    UP,
    DOWN,
    IDLE;
}
```
Python
```
from enum import Enum

class Direction(Enum):
    UP = 1
    DOWN = 2
    IDLE = 3
```
JavaScript
```
const Direction = {
    UP: 'UP',
    DOWN: 'DOWN',
    IDLE: 'IDLE'
};
```
### 3\. DoorAction
C++
```
public enum DoorAction {
    OPEN,CLOSE;
}
```
Java
```
public enum DoorAction {
    OPEN, CLOSE;
}
```
Python
```
from enum import Enum

class DoorAction(Enum):
    OPEN = 'OPEN'
    CLOSE = 'CLOSE'
```
JavaScript
```
const DoorAction = {
    OPEN: 'OPEN',
    CLOSE: 'CLOSE'
};
```
### 4\. ElevatorNumber
C++
```
enum class ElevatorNumber { ELEVATOR_NUMBER1, ELEVATOR_NUMBER2, ELEVATOR_NUMBER3 };
```
Java
```
public enum ElevatorNumber { ELEVATOR_NUMBER1, ELEVATOR_NUMBER2, ELEVATOR_NUMBER3 }
```
Python
```
from enum import Enum\nclass ElevatorNumber(Enum):\n    ELEVATOR_NUMBER1 = 1\n    ELEVATOR_NUMBER2 = 2\n    ELEVATOR_NUMBER3 = 3
```
JavaScript
```
const ElevatorNumber = {
    ELEVATOR_NUMBER1: 1,
    ELEVATOR_NUMBER2: 2,
    ELEVATOR_NUMBER3: 3
};
// Note: JavaScript does not have a built-in Enum type, so an object is used to mimic the behavior.
```
### 5\. FloorNumber
C++
```
public enum FloorNumber {
    FLOOR_NUMBER1,FLOOR_NUMBER2,FLOOR_NUMBER3,FLOOR_NUMBER4,FLOOR_NUMBER5,FLOOR_NUMBER6,FLOOR_NUMBER7,FLOOR_NUMBER8,FLOOR_NUMBER9,FLOOR_NUMBER10,FLOOR_NUMBER11,FLOOR_NUMBER12,FLOOR_NUMBER13,FLOOR_NUMBER14,FLOOR_NUMBER15;
}
```
Java
```
public enum FloorNumber {
    FLOOR_NUMBER1, FLOOR_NUMBER2, FLOOR_NUMBER3, FLOOR_NUMBER4, FLOOR_NUMBER5, FLOOR_NUMBER6, FLOOR_NUMBER7, FLOOR_NUMBER8, FLOOR_NUMBER9, FLOOR_NUMBER10, FLOOR_NUMBER11, FLOOR_NUMBER12, FLOOR_NUMBER13, FLOOR_NUMBER14, FLOOR_NUMBER15;
}
```
Python
```
from enum import Enum

class FloorNumber(Enum):
    FLOOR_NUMBER1 = 1
    FLOOR_NUMBER2 = 2
    FLOOR_NUMBER3 = 3
    FLOOR_NUMBER4 = 4
    FLOOR_NUMBER5 = 5
    FLOOR_NUMBER6 = 6
    FLOOR_NUMBER7 = 7
    FLOOR_NUMBER8 = 8
    FLOOR_NUMBER9 = 9
    FLOOR_NUMBER10 = 10
    FLOOR_NUMBER11 = 11
    FLOOR_NUMBER12 = 12
    FLOOR_NUMBER13 = 13
    FLOOR_NUMBER14 = 14
    FLOOR_NUMBER15 = 15
```
JavaScript
```
const FloorNumber = Object.freeze({
    FLOOR_NUMBER1: 'FLOOR_NUMBER1',
    FLOOR_NUMBER2: 'FLOOR_NUMBER2',
    FLOOR_NUMBER3: 'FLOOR_NUMBER3',
    FLOOR_NUMBER4: 'FLOOR_NUMBER4',
    FLOOR_NUMBER5: 'FLOOR_NUMBER5',
    FLOOR_NUMBER6: 'FLOOR_NUMBER6',
    FLOOR_NUMBER7: 'FLOOR_NUMBER7',
    FLOOR_NUMBER8: 'FLOOR_NUMBER8',
    FLOOR_NUMBER9: 'FLOOR_NUMBER9',
    FLOOR_NUMBER10: 'FLOOR_NUMBER10',
    FLOOR_NUMBER11: 'FLOOR_NUMBER11',
    FLOOR_NUMBER12: 'FLOOR_NUMBER12',
    FLOOR_NUMBER13: 'FLOOR_NUMBER13',
    FLOOR_NUMBER14: 'FLOOR_NUMBER14',
    FLOOR_NUMBER15: 'FLOOR_NUMBER15'
});
```
### 6\. Button
C++
```
public interface Button {
    boolean isPressed();
    boolean press();
}
```
Java
```
public interface Button {
    boolean isPressed();
    boolean press();
}
```
Python
```
from abc import ABC, abstractmethod

class Button(ABC):
    @abstractmethod
    def isPressed(self):
        pass

    @abstractmethod
    def press(self):
        pass
```
JavaScript
```
class Button {
    isPressed() {
        // Implementation here
    }

    press() {
        // Implementation here
    }
}
```
### 7\. Pannel
C++
```
// C++ does not have interfaces like Java. Use abstract classes instead.
#include <iostream>

class Pannel {
public:
    virtual void someMethod() = 0;
};
```
Java
```
import java.util.*;

public interface Pannel {
    void someMethod();
}
```
Python
```
from abc import ABC, abstractmethod

class Pannel(ABC):
    @abstractmethod
    def someMethod(self):
        pass
```

### 8\. Display
C++
```
import enums.Direction;
import enums.FloorNumber;

public class Display {
    private FloorNumber floorNumber;
    private Direction direction;
    private Integer weight;

    public Display(FloorNumber floorNumber, Direction direction, Integer weight) {
        this.floorNumber = floorNumber;

        this.direction = direction;
        this.weight = weight;
    }

    public Display() {
    }

    public FloorNumber getFloorNumber() {
        return floorNumber;
    }

    public void setFloorNumber(FloorNumber floorNumber) {
        this.floorNumber = floorNumber;
    }

    public Direction getDirection() {
        return direction;
    }

    public void setDirection(Direction direction) {
        this.direction = direction;
    }

    public Integer getWeight() {
        return weight;
    }

    public void setWeight(Integer weight) {
        this.weight = weight;
    }

}
```
Java
```
import enums.Direction;
import enums.FloorNumber;

public class Display {
    private FloorNumber floorNumber;
    private Direction direction;
    private Integer weight;

    public Display(FloorNumber floorNumber, Direction direction, Integer weight) {
        this.floorNumber = floorNumber;
        this.direction = direction;
        this.weight = weight;
    }

    public Display() {
    }

    public FloorNumber getFloorNumber() {
        return floorNumber;
    }

    public void setFloorNumber(FloorNumber floorNumber) {
        this.floorNumber = floorNumber;
    }

    public Direction getDirection() {
        return direction;
    }

    public void setDirection(Direction direction) {
        this.direction = direction;
    }

    public Integer getWeight() {
        return weight;
    }

    public void setWeight(Integer weight) {
        this.weight = weight;
    }
}
```
Python
```
from enum import Enum

class FloorNumber(Enum):
    pass

class Direction(Enum):
    pass

class Display:
    def __init__(self, floor_number=None, direction=None, weight=None):
        self.floor_number = floor_number
        self.direction = direction
        self.weight = weight

    def get_floor_number(self):
        return self.floor_number

    def set_floor_number(self, floor_number):
        self.floor_number = floor_number

    def get_direction(self):
        return self.direction

    def set_direction(self, direction):
        self.direction = direction

    def get_weight(self):
        return self.weight

    def set_weight(self, weight):
        self.weight = weight
```
JavaScript
```
class FloorNumber {
    // Assume enum values are defined here
}

class Direction {
    // Assume enum values are defined here
}

class Display {
    constructor(floorNumber, direction, weight) {
        this.floorNumber = floorNumber;
        this.direction = direction;
        this.weight = weight;
    }

    getFloorNumber() {
        return this.floorNumber;
    }

    setFloorNumber(floorNumber) {
        this.floorNumber = floorNumber;
    }

    getDirection() {
        return this.direction;
    }

    setDirection(direction) {
        this.direction = direction;
    }

    getWeight() {
        return this.weight;
    }

    setWeight(weight) {
        this.weight = weight;
    }
}
```
### 9\. Door
C++
```
import enums.DoorAction;

public class Door {
    private DoorAction doorAction;

    public Door(DoorAction doorAction) {
        this.doorAction = doorAction;
    }

    public Door() {
    }

    public void openDoor(){
        doorAction = DoorAction.OPEN;
    }
    public void closeDoor(){
        doorAction = DoorAction.CLOSE;
    }
}
```
Java
```
import enums.DoorAction;

public class Door {
    private DoorAction doorAction;

    public Door(DoorAction doorAction) {
        this.doorAction = doorAction;
    }

    public Door() {
    }

    public void openDoor(){
        doorAction = DoorAction.OPEN;
    }
    public void closeDoor(){
        doorAction = DoorAction.CLOSE;
    }
}
```
Python
```
from enum import Enum

class DoorAction(Enum):
    OPEN = 1
    CLOSE = 2

class Door:
    def __init__(self, door_action=None):
        self.door_action = door_action

    def open_door(self):
        self.door_action = DoorAction.OPEN

    def close_door(self):
        self.door_action = DoorAction.CLOSE
```
JavaScript
```
const DoorAction = {
    OPEN: 'OPEN',
    CLOSE: 'CLOSE'
};

class Door {
    constructor(doorAction = null) {
        this.doorAction = doorAction;
    }

    openDoor() {
        this.doorAction = DoorAction.OPEN;
    }

    closeDoor() {
        this.doorAction = DoorAction.CLOSE;
    }
}
```
### 10\. DoorButton
C++
```
import enums.DoorAction;
import interfaces.Button;

public class DoorButton implements Button {
    private boolean status;

    private DoorAction doorAction;

    public DoorButton(boolean status, DoorAction doorAction) {
        this.status = status;
        this.doorAction = doorAction;
    }
    public DoorButton() {
    }

    public DoorAction getDoorAction() {
        return doorAction;
    }

    public void setDoorAction(DoorAction doorAction) {
        this.doorAction = doorAction;
    }



    public void setStatus(boolean status) {
        this.status = status;
    }

    @Override
    public boolean isPressed() {
        return status;
    }

    @Override
    public boolean press() {
        status=!status;
        return status;
    }    
}
```
Java
```
import enums.DoorAction;
import interfaces.Button;

public class DoorButton implements Button {
    private boolean status;

    private DoorAction doorAction;

    public DoorButton(boolean status, DoorAction doorAction) {
        this.status = status;
        this.doorAction = doorAction;
    }
    public DoorButton() {
    }

    public DoorAction getDoorAction() {
        return doorAction;
    }

    public void setDoorAction(DoorAction doorAction) {
        this.doorAction = doorAction;
    }


    public void setStatus(boolean status) {
        this.status = status;
    }

    @Override
    public boolean isPressed() {
        return status;
    }

    @Override
    public boolean press() {
        status=!status;
        return status;
    }
}
```
Python
```
from enums import DoorAction
from interfaces import Button

class DoorButton(Button):
    def __init__(self, status=False, door_action=None):
        self.status = status
        self.door_action = door_action

    def get_door_action(self):
        return self.door_action

    def set_door_action(self, door_action):
        self.door_action = door_action

    def set_status(self, status):
        self.status = status

    def is_pressed(self):
        return self.status

    def press(self):
        self.status = not self.status
        return self.status
```
JavaScript
```
const DoorAction = Object.freeze({
    OPEN: 'OPEN',
    CLOSE: 'CLOSE'
});

class DoorButton {
    constructor(status = false, doorAction = null) {
        this.status = status;
        this.doorAction = doorAction;
    }

    getDoorAction() {
        return this.doorAction;
    }

    setDoorAction(doorAction) {
        this.doorAction = doorAction;
    }

    setStatus(status) {
        this.status = status;
    }

    isPressed() {
        return this.status;
    }

    press() {
        this.status = !this.status;
        return this.status;
    }
}
```
### 11\. ElevatorButton
C++
```
#include <iostream>
#include "FloorNumber.h"

class Button {
public:
    virtual bool isPressed() = 0;
    virtual bool press() = 0;
};

class ElevatorButton : public Button {
private:
    bool status;
    FloorNumber floorNumber;

public:
    ElevatorButton(bool status, FloorNumber floorNumber) : status(status), floorNumber(floorNumber) {}
    ElevatorButton() {}

    FloorNumber getFloorNumber() {
        return floorNumber;
    }

    void setFloorNumber(FloorNumber floorNumber) {
        this->floorNumber = floorNumber;
    }

    void setStatus(bool status) {
        this->status = status;
    }

    bool isPressed() override {
        return status;
    }

    bool press() override {
        status = !status;
        return status;
    }
};
```
Java
```
class FloorNumber {
    // Define your floor numbers here
}

class Button {
    public boolean isPressed() {
        throw new UnsupportedOperationException("Method not implemented.");
    }

    public void press() {
        throw new UnsupportedOperationException("Method not implemented.");
    }
}

class ElevatorButton extends Button {
    private boolean status;
    private Integer floorNumber;

    public ElevatorButton(boolean status, Integer floorNumber) {
        this.status = status;
        this.floorNumber = floorNumber;
    }

    public Integer getFloorNumber() {
        return this.floorNumber;
    }

    public void setFloorNumber(Integer floorNumber) {
        this.floorNumber = floorNumber;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    @Override
    public boolean isPressed() {
        return this.status;
    }

    @Override
    public void press() {
        this.status = !this.status;
    }
}
```
Python
```
from enum import Enum

class FloorNumber(Enum):
    # Define your floor numbers here
    pass

class Button:
    def is_pressed(self):
        pass

    def press(self):
        pass

class ElevatorButton(Button):
    def __init__(self, status=False, floor_number=None):
        self.status = status
        self.floor_number = floor_number

    def get_floor_number(self):
        return self.floor_number

    def set_floor_number(self, floor_number):
        self.floor_number = floor_number

    def set_status(self, status):
        self.status = status

    def is_pressed(self):
        return self.status

    def press(self):
        self.status = not self.status
        return self.status
```
JavaScript
```
class FloorNumber {
    // Define your floor numbers here
}

class Button {
    isPressed() {
        throw new Error('Method not implemented.');
    }

    press() {
        throw new Error('Method not implemented.');
    }
}

class ElevatorButton extends Button {
    constructor(status = false, floorNumber = null) {
        super();
        this.status = status;
        this.floorNumber = floorNumber;
    }

    getFloorNumber() {
        return this.floorNumber;
    }

    setFloorNumber(floorNumber) {
        this.floorNumber = floorNumber;
    }

    setStatus(status) {
        this.status = status;
    }

    isPressed() {
        return this.status;
    }

    press() {
        this.status = !this.status;
        return this.status;
    }
}
```
### 12\. HallButton
C++
```
import enums.Direction;
import interfaces.Button;

public class HallButton implements Button {
    private boolean status;

    private Direction direction;

    public HallButton(boolean status, Direction direction) {
        this.status = status;
        this.direction = direction;
    }
    public HallButton() {
    }

    public Direction getDirection() {
        return direction;
    }

    public void setDirection(Direction direction) {
        this.direction = direction;
    }



    public void setStatus(boolean status) {
        this.status = status;
    }

    @Override
    public boolean isPressed() {
        return status;
    }

    @Override
    public boolean press() {
        status=!status;
        return status;
    }
}
```
Java
```
import enums.Direction;
import interfaces.Button;

public class HallButton implements Button {
    private boolean status;

    private Direction direction;

    public HallButton(boolean status, Direction direction) {
        this.status = status;
        this.direction = direction;
    }
    public HallButton() {
    }

    public Direction getDirection() {
        return direction;
    }

    public void setDirection(Direction direction) {
        this.direction = direction;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    @Override
    public boolean isPressed() {
        return status;
    }

    @Override
    public boolean press() {
        status=!status;
        return status;
    }
}
```
Python
```
from enum import Enum

class Direction(Enum):
    UP = 1
    DOWN = 2

class Button:
    def is_pressed(self):
        pass

    def press(self):
        pass

class HallButton(Button):
    def __init__(self, status=False, direction=None):
        self.status = status
        self.direction = direction

    def get_direction(self):
        return self.direction

    def set_direction(self, direction):
        self.direction = direction

    def set_status(self, status):
        self.status = status

    def is_pressed(self):
        return self.status

    def press(self):
        self.status = not self.status
        return self.status
```
JavaScript
```
const Direction = Object.freeze({ UP: 'UP', DOWN: 'DOWN' });

class HallButton {
    constructor(status = false, direction = null) {
        this.status = status;
        this.direction = direction;
    }

    getDirection() {
        return this.direction;
    }

    setDirection(direction) {
        this.direction = direction;
    }

    setStatus(status) {
        this.status = status;
    }

    isPressed() {
        return this.status;
    }

    press() {
        this.status = !this.status;
        return this.status;
    }
}
```
### 13\. Elevator
C++
```
import enums.Direction;
import enums.ElevatorNumber;
import enums.FloorNumber;

public class Elevator {
    private ElevatorNumber elevatorNumber;
    private Door door;
    private InsidePannel insidePannel;
    private Display display;
    private FloorNumber currentFloorNumber;
    private Direction currentDirection;

    public Elevator(ElevatorNumber elevatorNumber, Door door, InsidePannel insidePannel, Display display, FloorNumber currentFloorNumber, Direction currentDirection) {
        this.elevatorNumber = elevatorNumber;
        this.door = door;
        this.insidePannel = insidePannel;
        this.display = display;
        this.currentFloorNumber = currentFloorNumber;
        this.currentDirection = currentDirection;
    }

    public Elevator() {
    }

    public ElevatorNumber getElevatorNumber() {
        return elevatorNumber;
    }

    public void setElevatorNumber(ElevatorNumber elevatorNumber) {
        this.elevatorNumber = elevatorNumber;
    }

    public Door getDoor() {
        return door;
    }

    public void setDoor(Door door) {
        this.door = door;
    }

    public InsidePannel getInsidePannel() {
        return insidePannel;
    }

    public void setInsidePannel(InsidePannel insidePannel) {
        this.insidePannel = insidePannel;
    }

    public Display getDisplay() {
        return display;
    }

    public void setDisplay(Display display) {
        this.display = display;
    }

    public FloorNumber getCurrentFloorNumber() {
        return currentFloorNumber;
    }

    public void setCurrentFloorNumber(FloorNumber currentFloorNumber) {
        this.currentFloorNumber = currentFloorNumber;
    }

    public Direction getCurrentDirection() {
        return currentDirection;
    }

    public void setCurrentDirection(Direction currentDirection) {
        this.currentDirection = currentDirection;
    }

}
```
Java
```
public enum Direction { UP(1), DOWN(2); private int value; Direction(int value) { this.value = value; } public int getValue() { return value; } }

public enum ElevatorNumber { ONE(1), TWO(2); private int value; ElevatorNumber(int value) { this.value = value; } public int getValue() { return value; } }

public enum FloorNumber { ONE(1), TWO(2); private int value; FloorNumber(int value) { this.value = value; } public int getValue() { return value; } }

public class Door { }

public class InsidePannel { }

public class Display { }

public class Elevator {
    private ElevatorNumber elevatorNumber;
    private Door door;
    private InsidePannel insidePannel;
    private Display display;
    private FloorNumber currentFloorNumber;
    private Direction currentDirection;

    public Elevator(ElevatorNumber elevatorNumber, Door door, InsidePannel insidePannel, Display display, FloorNumber currentFloorNumber, Direction currentDirection) {
        this.elevatorNumber = elevatorNumber;
        this.door = door;
        this.insidePannel = insidePannel;
        this.display = display;
        this.currentFloorNumber = currentFloorNumber;
        this.currentDirection = currentDirection;
    }

    public ElevatorNumber getElevatorNumber() { return elevatorNumber; }
    public void setElevatorNumber(ElevatorNumber elevatorNumber) { this.elevatorNumber = elevatorNumber; }
    public Door getDoor() { return door; }
    public void setDoor(Door door) { this.door = door; }
    public InsidePannel getInsidePannel() { return insidePannel; }
    public void setInsidePannel(InsidePannel insidePannel) { this.insidePannel = insidePannel; }
    public Display getDisplay() { return display; }
    public void setDisplay(Display display) { this.display = display; }
    public FloorNumber getCurrentFloorNumber() { return currentFloorNumber; }
    public void setCurrentFloorNumber(FloorNumber currentFloorNumber) { this.currentFloorNumber = currentFloorNumber; }
    public Direction getCurrentDirection() { return currentDirection; }
    public void setCurrentDirection(Direction currentDirection) { this.currentDirection = currentDirection; }
}
```
Python
```
from enum import Enum


class Direction(Enum):
    UP = 1
    DOWN = 2


class ElevatorNumber(Enum):
    ONE = 1
    TWO = 2


class FloorNumber(Enum):
    ONE = 1
    TWO = 2


class Door:
    pass


class InsidePannel:
    pass


class Display:
    pass


class Elevator:
    def __init__(self, elevator_number=None, door=None, inside_pannel=None, display=None, current_floor_number=None, current_direction=None):
        self.elevator_number = elevator_number
        self.door = door
        self.inside_pannel = inside_pannel
        self.display = display
        self.current_floor_number = current_floor_number
        self.current_direction = current_direction

    def get_elevator_number(self):
        return self.elevator_number

    def set_elevator_number(self, elevator_number):
        self.elevator_number = elevator_number

    def get_door(self):
        return self.door

    def set_door(self, door):
        self.door = door

    def get_inside_pannel(self):
        return self.inside_pannel

    def set_inside_pannel(self, inside_pannel):
        self.inside_pannel = inside_pannel

    def get_display(self):
        return self.display

    def set_display(self, display):
        self.display = display

    def get_current_floor_number(self):
        return self.current_floor_number

    def set_current_floor_number(self, current_floor_number):
        self.current_floor_number = current_floor_number

    def get_current_direction(self):
        return self.current_direction

    def set_current_direction(self, current_direction):
        self.current_direction = current_direction
```
JavaScript
```
var Direction;
(function (Direction) {
    Direction[Direction["UP"] = 1] = "UP";
    Direction[Direction["DOWN"] = 2] = "DOWN";
})(Direction || (Direction = {})); // enum Direction

var ElevatorNumber;
(function (ElevatorNumber) {
    ElevatorNumber[ElevatorNumber["ONE"] = 1] = "ONE";
    ElevatorNumber[ElevatorNumber["TWO"] = 2] = "TWO";
})(ElevatorNumber || (ElevatorNumber = {})); // enum ElevatorNumber

var FloorNumber;
(function (FloorNumber) {
    FloorNumber[FloorNumber["ONE"] = 1] = "ONE";
    FloorNumber[FloorNumber["TWO"] = 2] = "TWO";
})(FloorNumber || (FloorNumber = {})); // enum FloorNumber

var Door = /** @class */ (function () {
    function Door() {
    }
    return Door;
})();

var InsidePannel = /** @class */ (function () {
    function InsidePannel() {
    }
    return InsidePannel;
})();

var Display = /** @class */ (function () {
    function Display() {
    }
    return Display;
})();

var Elevator = /** @class */ (function () {
    function Elevator(elevatorNumber, door, insidePannel, display, currentFloorNumber, currentDirection) {
        if (elevatorNumber === void 0) { elevatorNumber = null; }
        if (door === void 0) { door = null; }
        if (insidePannel === void 0) { insidePannel = null; }
        if (display === void 0) { display = null; }
        if (currentFloorNumber === void 0) { currentFloorNumber = null; }
        if (currentDirection === void 0) { currentDirection = null; }
        this.elevatorNumber = elevatorNumber;
        this.door = door;
        this.insidePannel = insidePannel;
        this.display = display;
        this.currentFloorNumber = currentFloorNumber;
        this.currentDirection = currentDirection;
    }
    Elevator.prototype.getElevatorNumber = function () {
        return this.elevatorNumber;
    };
    Elevator.prototype.setElevatorNumber = function (elevatorNumber) {
        this.elevatorNumber = elevatorNumber;
    };
    Elevator.prototype.getDoor = function () {
        return this.door;
    };
    Elevator.prototype.setDoor = function (door) {
        this.door = door;
    };
    Elevator.prototype.getInsidePannel = function () {
        return this.insidePannel;
    };
    Elevator.prototype.setInsidePannel = function (insidePannel) {
        this.insidePannel = insidePannel;
    };
    Elevator.prototype.getDisplay = function () {
        return this.display;
    };
    Elevator.prototype.setDisplay = function (display) {
        this.display = display;
    };
    Elevator.prototype.getCurrentFloorNumber = function () {
        return this.currentFloorNumber;
    };
    Elevator.prototype.setCurrentFloorNumber = function (currentFloorNumber) {
        this.currentFloorNumber = currentFloorNumber;
    };
    Elevator.prototype.getCurrentDirection = function () {
        return this.currentDirection;
    };
    Elevator.prototype.setCurrentDirection = function (currentDirection) {
        this.currentDirection = currentDirection;
    };
    return Elevator;
}());
```
### 14\. Floor
C++
```
import enums.FloorNumber;

public class Floor {
    private FloorNumber floorNumber;
    private OutsidePannel outsidePannel;

    public FloorNumber getFloorNumber() {
        return floorNumber;
    }

    public void setFloorNumber(FloorNumber floorNumber) {
        this.floorNumber = floorNumber;
    }

    public OutsidePannel getOutsidePannel() {
        return outsidePannel;
    }

    public void setOutsidePannel(OutsidePannel outsidePannel) {
        this.outsidePannel = outsidePannel;
    }

    public Floor(FloorNumber floorNumber, OutsidePannel outsidePannel) {
        this.floorNumber = floorNumber;
        this.outsidePannel = outsidePannel;
    }
}
```
Java
```
import enums.FloorNumber;

public class Floor {
    private FloorNumber floorNumber;
    private OutsidePannel outsidePannel;

    public FloorNumber getFloorNumber() {
        return floorNumber;
    }

    public void setFloorNumber(FloorNumber floorNumber) {
        this.floorNumber = floorNumber;
    }

    public OutsidePannel getOutsidePannel() {
        return outsidePannel;
    }

    public void setOutsidePannel(OutsidePannel outsidePannel) {
        this.outsidePannel = outsidePannel;
    }

    public Floor(FloorNumber floorNumber, OutsidePannel outsidePannel) {
        this.floorNumber = floorNumber;
        this.outsidePannel = outsidePannel;
    }
}
```
Python
```
from enum import Enum


class FloorNumber(Enum):
    pass


class OutsidePannel:
    pass


class Floor:
    def __init__(self, floor_number, outside_pannel):
        self.floor_number = floor_number
        self.outside_pannel = outside_pannel

    def get_floor_number(self):
        return self.floor_number

    def set_floor_number(self, floor_number):
        self.floor_number = floor_number

    def get_outside_pannel(self):
        return self.outside_pannel

    def set_outside_pannel(self, outside_pannel):
        self.outside_pannel = outside_pannel
```
JavaScript
```
class FloorNumber {
    // Assume FloorNumber enum values are defined here
}

class OutsidePannel {
    // Assume OutsidePannel properties and methods are defined here
}

class Floor {
    constructor(floorNumber, outsidePannel) {
        this.floorNumber = floorNumber;
        this.outsidePannel = outsidePannel;
    }

    getFloorNumber() {
        return this.floorNumber;
    }

    setFloorNumber(floorNumber) {
        this.floorNumber = floorNumber;
    }

    getOutsidePannel() {
        return this.outsidePannel;
    }

    setOutsidePannel(outsidePannel) {
        this.outsidePannel = outsidePannel;
    }
}
```
### 15\. InsidePannel
C++
```
import enums.DoorAction;
import enums.FloorNumber;
import interfaces.Pannel;

import java.util.ArrayList;
import java.util.List;

public class InsidePannel implements Pannel{
    private List<ElevatorButton> elevatorButtonList;
    private List<DoorButton> doorButtons;

    public InsidePannel() {
    elevatorButtonList=new ArrayList<>();
    doorButtons=new ArrayList<>();
        for (int i = 0; i <15 ; i++) {
            elevatorButtonList.add(new ElevatorButton(false, FloorNumber.values()[i]));
        }

        for (int i = 0; i <3 ; i++) {
            doorButtons.add(new DoorButton(false, DoorAction.values()[i]));
        }
    }

    public boolean pressFloorButton(int floorNumber) {
        return elevatorButtonList.get(floorNumber).press();
    }
    public boolean pressDoorButton(int doorNumber) {
        return doorButtons.get(doorNumber).press();
    }
}
```
Java
```
import enums.DoorAction;
import enums.FloorNumber;
import interfaces.Pannel;

import java.util.ArrayList;
import java.util.List;

public class InsidePannel implements Pannel{
    private List<ElevatorButton> elevatorButtonList;
    private List<DoorButton> doorButtons;

    public InsidePannel() {
    elevatorButtonList=new ArrayList<>();
    doorButtons=new ArrayList<>();
        for (int i = 0; i <15 ; i++) {
            elevatorButtonList.add(new ElevatorButton(false, FloorNumber.values()[i]));
        }

        for (int i = 0; i <3 ; i++) {
            doorButtons.add(new DoorButton(false, DoorAction.values()[i]));
        }
    }

    public boolean pressFloorButton(int floorNumber) {
        return elevatorButtonList.get(floorNumber).press();
    }
    public boolean pressDoorButton(int doorNumber) {
        return doorButtons.get(doorNumber).press();
    }
}
```
Python
```
from enum import Enum

class DoorAction(Enum):
    OPEN = 1
    CLOSE = 2
    STOP = 3

class FloorNumber(Enum):
    pass

for i in range(15):
    setattr(FloorNumber, f'FLOOR_{i}', i)

class ElevatorButton:
    def __init__(self, pressed, floor_number):
        self.pressed = pressed
        self.floor_number = floor_number

    def press(self):
        self.pressed = True
        return True

class DoorButton:
    def __init__(self, pressed, door_action):
        self.pressed = pressed
        self.door_action = door_action

    def press(self):
        self.pressed = True
        return True

class InsidePannel:
    def __init__(self):
        self.elevator_button_list = []
        self.door_buttons = []

        for i in range(15):
            self.elevator_button_list.append(ElevatorButton(False, FloorNumber[f'FLOOR_{i}']))

        for i in range(3):
            self.door_buttons.append(DoorButton(False, list(DoorAction)[i]))

    def press_floor_button(self, floor_number):
        return self.elevator_button_list[floor_number].press()

    def press_door_button(self, door_number):
        return self.door_buttons[door_number].press()
```
JavaScript
```
const enums = {
    DoorAction: ['OPEN', 'CLOSE', 'STOP'],
    FloorNumber: Array.from({length: 15}, (_, i) => i)
};

class ElevatorButton {
    constructor(pressed, floorNumber) {
        this.pressed = pressed;
        this.floorNumber = floorNumber;
    }

    press() {
        this.pressed = true;
        return true;
    }
}

class DoorButton {
    constructor(pressed, doorAction) {
        this.pressed = pressed;
        this.doorAction = doorAction;
    }

    press() {
        this.pressed = true;
        return true;
    }
}

class InsidePannel {
    constructor() {
        this.elevatorButtonList = [];
        this.doorButtons = [];

        for (let i = 0; i < 15; i++) {
            this.elevatorButtonList.push(new ElevatorButton(false, enums.FloorNumber[i]));
        }

        for (let i = 0; i < 3; i++) {
            this.doorButtons.push(new DoorButton(false, enums.DoorAction[i]));
        }
    }

    pressFloorButton(floorNumber) {
        return this.elevatorButtonList[floorNumber].press();
    }

    pressDoorButton(doorNumber) {
        return this.doorButtons[doorNumber].press();
    }
}
```
### 16\. OutsidePannel
C++
```
import enums.Direction;
import interfaces.Pannel;

import java.util.ArrayList;
import java.util.List;

public class OutsidePannel implements Pannel {
    private List<HallButton> hallButtons;

    public OutsidePannel() {
        hallButtons = new ArrayList<>();
        hallButtons.add(new HallButton(false,Direction.UP));
        hallButtons.add(new HallButton(false,Direction.DOWN));
        hallButtons.add(new HallButton(false,Direction.IDLE));
    }

    public void moveUp(){

    }
    public void moveDown(){

    }
}
```
Java
```
import java.util.ArrayList;
import java.util.List;

public class OutsidePannel implements Pannel {
    private List<HallButton> hallButtons;

    public OutsidePannel() {
        hallButtons = new ArrayList<>();
        hallButtons.add(new HallButton(false, Direction.UP));
        hallButtons.add(new HallButton(false, Direction.DOWN));
        hallButtons.add(new HallButton(false, Direction.IDLE));
    }

    public void moveUp(){

    }
    public void moveDown(){

    }
}
```
Python
```
from enum import Enum

class Direction(Enum):
    UP = 1
    DOWN = 2
    IDLE = 3

class Pannel:
    pass

class HallButton:
    def __init__(self, pressed, direction):
        self.pressed = pressed
        self.direction = direction

class OutsidePannel(Pannel):
    def __init__(self):
        self.hall_buttons = [
            HallButton(False, Direction.UP),
            HallButton(False, Direction.DOWN),
            HallButton(False, Direction.IDLE)
        ]

    def move_up(self):
        pass

    def move_down(self):
        pass
```
JavaScript
```
const Direction = Object.freeze({
    UP: 'UP',
    DOWN: 'DOWN',
    IDLE: 'IDLE'
});

class HallButton {
    constructor(pressed, direction) {
        this.pressed = pressed;
        this.direction = direction;
    }
}

class OutsidePannel {
    constructor() {
        this.hallButtons = [
            new HallButton(false, Direction.UP),
            new HallButton(false, Direction.DOWN),
            new HallButton(false, Direction.IDLE)
        ];
    }

    moveUp() {
        // Implementation
    }

    moveDown() {
        // Implementation
    }
}
```
### 17\. ElevatorSystem
C++
```
import enums.Direction;
import enums.FloorNumber;

import java.util.*;

public class ElevatorSystem {
    private List<Elevator> elevators;
    private List<Floor> floors;



    private ElevatorSystem() {
    }

    public List<Elevator> getElevators() {
        return elevators;
    }

    public void setElevators(List<Elevator> elevators) {
        this.elevators = elevators;
    }

    public List<Floor> getFloors() {
        return floors;
    }

    public void setFloors(List<Floor> floors) {
        this.floors = floors;
    }
    private static volatile ElevatorSystem elevatorSystemInstance;


    public static ElevatorSystem getInstance() {
        if (elevatorSystemInstance == null) {
            synchronized (ElevatorSystem.class){
                if (elevatorSystemInstance == null) {
                    return elevatorSystemInstance = new ElevatorSystem();
                }
            }
        }
        return elevatorSystemInstance;
    }

    public Elevator requestElevator(Direction direction, Floor floor) {
        //TODO: returning elevator using smart dispatch, setting up the properties of the elevator
        return null;
    }

    public void openDoor(Elevator elevator) {
        elevator.getDoor().openDoor();

    }
    public void closeDoor(Elevator elevator) {
        elevator.getDoor().closeDoor();

    }
    public void selectFloor(FloorNumber floorNumber, Elevator elevator) {
      elevator.getInsidePannel().pressFloorButton(floorNumber.ordinal());
    }

}
```
Java
```
import enums.Direction;
import enums.FloorNumber;

import java.util.*;

public class ElevatorSystem {
    private List<Elevator> elevators;
    private List<Floor> floors;


    private ElevatorSystem() {
    }

    public List<Elevator> getElevators() {
        return elevators;
    }

    public void setElevators(List<Elevator> elevators) {
        this.elevators = elevators;
    }

    public List<Floor> getFloors() {
        return floors;
    }

    public void setFloors(List<Floor> floors) {
        this.floors = floors;
    }
    private static volatile ElevatorSystem elevatorSystemInstance;


    public static ElevatorSystem getInstance() {
        if (elevatorSystemInstance == null) {
            synchronized (ElevatorSystem.class){
                if (elevatorSystemInstance == null) {
                    return elevatorSystemInstance = new ElevatorSystem();
                }
            }
        }
        return elevatorSystemInstance;
    }

    public Elevator requestElevator(Direction direction, Floor floor) {
        //TODO: returning elevator using smart dispatch, setting up the properties of the elevator
        return null;
    }

    public void openDoor(Elevator elevator) {
        elevator.getDoor().openDoor();

    }
    public void closeDoor(Elevator elevator) {
        elevator.getDoor().closeDoor();

    }
    public void selectFloor(FloorNumber floorNumber, Elevator elevator) {
      elevator.getInsidePannel().pressFloorButton(floorNumber.ordinal());
    }

}
```
Python
```
from enum import Enum


class Direction(Enum):
    UP = 1
    DOWN = 2


class FloorNumber(Enum):
    ONE = 1
    TWO = 2
    THREE = 3
    # Add more floor numbers as needed


class Elevator:
    def __init__(self):
        self.door = Door()
        self.inside_panel = InsidePanel()

    def get_door(self):
        return self.door

    def get_inside_panel(self):
        return self.inside_panel


class Door:
    def open_door(self):
        pass

    def close_door(self):
        pass


class InsidePanel:
    def press_floor_button(self, floor_number):
        pass


class Floor:
    pass


class ElevatorSystem:
    _instance = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super(ElevatorSystem, cls).__new__(cls)
            cls._instance.elevators = []
            cls._instance.floors = []
        return cls._instance

    def get_elevators(self):
        return self.elevators

    def set_elevators(self, elevators):
        self.elevators = elevators

    def get_floors(self):
        return self.floors

    def set_floors(self, floors):
        self.floors = floors

    def request_elevator(self, direction, floor):
        # TODO: returning elevator using smart dispatch, setting up the properties of the elevator
        return None

    def open_door(self, elevator):
        elevator.get_door().open_door()

    def close_door(self, elevator):
        elevator.get_door().close_door()

    def select_floor(self, floor_number, elevator):
        elevator.get_inside_panel().press_floor_button(floor_number.value)
```
JavaScript
```
class Direction {
    static UP = 'UP';
    static DOWN = 'DOWN';
}

class FloorNumber {
    static ONE = 1;
    static TWO = 2;
    static THREE = 3;
    // Add more floor numbers as needed
}

class Door {
    openDoor() {
        // Implementation
    }

    closeDoor() {
        // Implementation
    }
}

class InsidePanel {
    pressFloorButton(floorNumber) {
        // Implementation
    }
}

class Elevator {
    constructor() {
        this.door = new Door();
        this.insidePanel = new InsidePanel();
    }

    getDoor() {
        return this.door;
    }

    getInsidePanel() {
        return this.insidePanel;
    }
}

class Floor {
    // Implementation
}

class ElevatorSystem {
    static #instance = null;

    static getInstance() {
        if (!ElevatorSystem.#instance) {
            ElevatorSystem.#instance = new ElevatorSystem();
        }
        return ElevatorSystem.#instance;
    }

    constructor() {
        this.elevators = [];
        this.floors = [];
    }

    getElevators() {
        return this.elevators;
    }

    setElevators(elevators) {
        this.elevators = elevators;
    }

    getFloors() {
        return this.floors;
    }

    setFloors(floors) {
        this.floors = floors;
    }

    requestElevator(direction, floor) {
        // TODO: returning elevator using smart dispatch, setting up the properties of the elevator
        return null;
    }

    openDoor(elevator) {
        elevator.getDoor().openDoor();
    }

    closeDoor(elevator) {
        elevator.getDoor().closeDoor();
    }

    selectFloor(floorNumber, elevator) {
        elevator.getInsidePanel().pressFloorButton(floorNumber);
    }
}
```
## Performance Optimization of Elevator System Low-Level Design (LLD)

### 1\. Efficient Scheduling Algorithms

Implement efficient control algorithms like the Elevator Group Control System (EGCS) which include:

- ****Single Elevator Optimization:**** Use algorithms like the Simplex method for single elevator optimization.
- ****Multiple Elevator Coordination:**** Implement algorithms such as the Destination Control System (DCS) to manage traffic flow effectively.
- ****Heuristic Approaches:**** Use heuristics or meta-heuristics (e.g., Genetic Algorithms, Simulated Annealing) for complex scenarios.

### 2\. Intelligent Load Balancing

- ****Dynamic Load Balancing:**** Distribute requests efficiently among multiple elevators to minimize wait and travel times.
- ****Real-time Traffic Analysis:**** Use sensors and data analytics to predict traffic patterns and adjust elevator deployment dynamically.