---
title: "What is eventual consistency between Microservices?"
source: "https://www.geeksforgeeks.org/system-design/what-is-eventual-consistency-between-microservices/"
author:
  - "[[GeeksforGeeks]]"
published: 2024-03-07
created: 2026-09-22
description: "Your All-in-One Learning Portal: GeeksforGeeks is a comprehensive educational platform that empowers learners across domains-spanning computer science and programming, school education, upskilling, commerce, software tools, competitive exams, and more."
tags:
  - "clippings"
---
[Eventual Consistency](https://www.geeksforgeeks.org/system-design/eventual-consistency-in-distributive-systems-learn-system-design/) between [microservices](https://www.geeksforgeeks.org/system-design/microservices/) refers to the concept that, in a distributed system where data is replicated across multiple microservices or databases, eventual consistency is maintained over time. This means that while updates to data may not be immediately reflected across all microservices, they will eventually converge to a consistent state.

- In a microservices architecture, each microservice manages its own data store, and data may be replicated or cached across multiple microservices for performance and scalability reasons.
- However, ensuring that all copies of the data remain consistent can be challenging due to the distributed nature of the system and the potential for network delays, failures, or conflicts.

To achieve eventual consistency between microservices, various strategies, and techniques can be used, such as:

## 1\. Asynchronous Communication

Microservices can communicate with each other asynchronously, allowing them to continue processing requests without waiting for a response. This can help reduce the impact of network delays on consistency.

## 2\. Eventual Consistency Models

Microservices can use eventual consistency models, where updates are propagated asynchronously and conflicts are resolved over time. This allows each microservice to maintain its own copy of the data and eventually converge to a consistent state.

## 3\. Conflict Resolution

Microservices can implement conflict resolution mechanisms to resolve conflicts that arise when multiple microservices update the same data concurrently. This can involve using timestamps, version numbers, or other techniques to determine the most recent update.

## 4\. Compensating Transactions

Microservices can use compensating transactions to undo or reverse the effects of a previous transaction if it is found to be in conflict with another transaction. This can help maintain consistency in the presence of conflicting updates.

Overall, eventual consistency between microservices is about ensuring that, despite the complexities of a distributed system, data remains consistent over time and that any inconsistencies are resolved in a timely and efficient manner