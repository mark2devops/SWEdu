---
title: "Software Quality Assurance - Software Engineering"
source: "https://www.geeksforgeeks.org/software-testing/software-engineering-software-quality-assurance/"
author:
  - "[[GeeksforGeeks]]"
published: 2019-03-27
created: 2026-09-23
description: "Your All-in-One Learning Portal: GeeksforGeeks is a comprehensive educational platform that empowers learners across domains-spanning computer science and programming, school education, upskilling, commerce, software tools, competitive exams, and more."
tags:
  - "clippings"
---
Software Quality Assurance (SQA) is a systematic approach used to ensure that software development processes and work products follow defined quality standards and procedures. It focuses on preventing defects, improving development processes, and maintaining software quality throughout the software development life cycle (SDLC).

- Helps prevent defects by identifying process issues early
- Supports quality activities throughout the software development life cycle
![[2056958475.webp|2056958475]]

Two Primary Dimensions of Quality

## Quality in Software

Software quality refers to the degree to which a software product satisfies specified requirements and meets the needs of its users. It includes both the quality of the development process and the quality of the final software product.

### 1\. Quality of Design

- Ensures that requirements and specifications correctly reflect customer needs
- Decided before development begins
- Focuses on planning, architecture, and system design

### 2\. Quality of Conformance

- Measures how well the final product matches the design specifications
- Evaluated during and after development
- Focuses on implementation, testing, and delivery

## Focus of Software Quality Assurance (SQA)

SQA focuses on establishing and maintaining processes that help achieve the required level of software quality. Important quality characteristics include:

![[software_quality_assurance_characteristics.webp|software_quality_assurance_characteristics]]

- ****Functional Suitability:**** The software provides the functions needed to meet specified requirements.
- ****Performance Efficiency:**** The software performs efficiently while using appropriate system resources.
- ****Compatibility:**** The software can work and interact effectively with other systems or environments.
- ****Usability:**** The software is easy for users to learn, understand, and operate.
- ****Reliability:**** The software performs consistently and dependably under specified conditions.
- ****Security:**** The software protects data and resources from unauthorized access and other security threats.
- ****Maintainability:**** The software can be easily analyzed, modified, corrected, and maintained.
- ****Portability:**** The software can be transferred and adapted to different environments with reasonable effort.

## Process of SQA

SQA activities are performed throughout the SDLC to establish, monitor, and improve software quality.

- ****SQA Planning:**** Defines quality objectives, applicable standards, procedures, responsibilities, and quality activities.
- ****Requirements Review:**** Reviews requirements for correctness, completeness, consistency, and testability.
- ****Process Definition:**** Establishes development, documentation, coding, review, and testing procedures.
- ****Process Monitoring:**** Monitors project activities to ensure that defined processes and standards are followed.
- ****Reviews and Inspections:**** Examines requirements, designs, code, and other work products to identify issues early.
- ****Auditing:**** Evaluates processes and work products against defined standards and procedures.
- ****Verification and Testing:**** Checks whether software work products and the final product satisfy specified requirements.
- ****Defect Management:**** Records, tracks, analyzes, and verifies defects throughout their lifecycle.
- ****Process Improvement:**** Analyzes process performance and applies improvements to increase efficiency and quality.

## Software Quality Assurance Standards

Several standards and models help organizations establish, manage, and evaluate software quality and development processes.

- ****ISO 9001:**** Provides requirements for a quality management system that can be applied to organizations and their processes.
- ****ISO/IEC 25010:**** Defines a software product quality model with characteristics used to specify, measure, and evaluate software quality. The current edition is ISO/IEC 25010:2023.
- ****ISO/IEC/IEEE 12207:**** Defines software life cycle processes for activities such as development, operation, maintenance, and support.
- ****ISO/IEC/IEEE 29119:**** Provides internationally agreed standards for software testing, including testing concepts, processes, and test documentation.
- ****IEEE 730-2026:**** Defines requirements for initiating, planning, controlling, and executing Software Quality Assurance processes for software development and maintenance projects.
- ****IEEE 1012:**** Defines processes and requirements for software and system verification and validation.
- ****CMMI:**** Provides a framework for improving organizational processes and assessing process maturity and capability.

## Responsibilities of SQA Team

The SQA team helps establish, monitor, and improve processes that support software quality.

- Define and maintain quality processes and guidelines
- Monitor compliance with established standards and procedures
- Conduct reviews, inspections, and audits
- Identify process risks and recommend corrective actions
- Analyze recurring defects and support root cause analysis
- Monitor quality metrics and project quality activities
- Support quality-related training and awareness
- Promote continuous process improvement

## Tools Used in Software Quality Assurance

Different tools support SQA activities such as testing, defect management, code analysis, version control, and continuous integration.

- ****Test Management Tools:**** Manage test cases, test execution, and test results. Examples: TestRail, Zephyr
- ****Defect Tracking Tools:**** Record, track, and manage software defects. Examples: Jira, Bugzilla
- ****Test Automation Tools:**** Automate software tests to improve efficiency and repeatability. Examples: Selenium, OpenText UFT
- ****Static Analysis Tools:**** Analyze source code without executing it to identify defects, vulnerabilities, and coding issues. Examples: SonarQube, Checkstyle
- ****Performance Testing Tools:**** Evaluate performance, scalability, and system behavior under different workloads. Examples: JMeter, LoadRunner
- ****Configuration Management Tools:**** Manage source code versions and changes. Examples: Git, SVN
- ****Code Review Tools:**** Support collaborative code reviews and help maintain coding standards. Examples: GitHub, Gerrit
- ****Continuous Integration Tools:**** Automate build, integration, and testing activities. Examples: Jenkins, GitLab CI/CD

## Limitations

SQA improves software quality, but it cannot eliminate all risks or guarantee defect-free software.

- SQA can reduce defects but cannot guarantee completely error-free software.
- Reviews, audits, documentation, and monitoring require additional time and effort.
- Implementing quality processes, tools, and skilled resources can increase project costs.
- Effective SQA depends on appropriate processes, skilled professionals, and organizational support.
- Teams may resist changes or additional quality processes.
- Complex systems make it difficult to identify every possible defect, risk, or failure condition

## Software Quality Assurance Vs Software Testing

Software Quality Assurance and Software Testing are related but differ in their focus and purpose.

| Aspect | Software Quality Assurance (SQA) | Software Testing |
| --- | --- | --- |
| Focus | Process-oriented | Product-oriented |
| Objective | Prevent defects by improving development processes | Detect defects in the software |
| Scope | Covers quality activities throughout the SDLC | Performed at different stages of the SDLC |
| Nature | Primarily preventive | Primarily detection-oriented |
| Responsibility | Involves the development team, QA professionals, and other stakeholders | Mainly performed by testers, with developers also involved in testing |
| Activity Type | Process definition, reviews, audits, standards, and process improvement | Test planning, test execution, defect reporting, and verification |
| Goal | Improve the quality of software processes and products | Verify that software meets specified requirements and identify defects |