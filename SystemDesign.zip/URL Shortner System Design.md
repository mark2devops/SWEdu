---
title: "URL Shortner System Design"
source: "https://www.geeksforgeeks.org/system-design/system-design-url-shortening-service/"
author:
  - "[[GeeksforGeeks]]"
published: 2023-05-15
created: 2026-09-23
description: "Your All-in-One Learning Portal: GeeksforGeeks is a comprehensive educational platform that empowers learners across domains-spanning computer science and programming, school education, upskilling, commerce, software tools, competitive exams, and more."
tags:
  - "clippings"
---
Designing a URL shortener means building a system that converts long URLs into short, unique links and redirects users to the original URL when they open them. In an interview, the main focus is on fast redirection, unique short-code generation, and handling very high read traffic.

- Users should be able to submit a long URL and receive a short, unique URL.
- The system should redirect short URLs quickly and reliably while supporting millions of links and requests.

## 1\. Problem Statement

We need to design a URL-shortening system where users can convert long URLs into short links that are easy to share. When someone opens the short URL, the system should quickly redirect them to the original destination.

- The system should generate unique short codes and correctly map them to original URLs.
- It should handle high traffic, prevent collisions, support link expiration, and provide low-latency redirects.

## 2\. System Requirements

Before designing the system, we need to identify its functional and non-functional requirements. These requirements define what the URL shortener should do and how well it should perform.

### Functional Requirements

- Users should be able to submit a long URL and receive a unique short URL.
- The system should redirect users from the short URL to the original URL.
- Users should be able to create custom short aliases when available.
- Short URLs may support expiration after a specified time.
- The system should allow users to delete or disable their shortened URLs.
- The system can track basic analytics such as click count and access time.

### Non-Functional Requirements

- ****Low Latency:**** Redirect requests should be processed very quickly.
- ****Scalability:**** The system should support millions of shortened URLs and very high read traffic.
- ****Availability:**** Redirects should remain available with minimal downtime.
- ****Reliability:**** Short URLs should always map to the correct original URLs.
- ****Uniqueness:**** Generated short codes should avoid collisions.
- ****Security:**** The system should protect against malicious links, abuse, and excessive requests.

## 3\. Capacity Estimation

Before designing the architecture, we estimate the expected number of URLs, redirect traffic, storage, and bandwidth. These estimates help us choose the right database, cache, and scaling strategy.

### Assumptions

| ****Parameter**** | ****Assumption**** |
| --- | --- |
| New URLs Created per Day | 10 Million |
| Redirects per Day | 1 Billion |
| Average URL Size | 500 Bytes |
| Short Code Size | 7 Characters |
| Read: Write Ratio | 100: 1 |

### 3.1 Storage Estimation

Assume each URL record requires around 500 Bytes.

> Daily Storage = 10 Million × 500 Bytes  
> ≈ 5 GB/day

For one year:

> Yearly Storage ≈ 5 GB × 365  
> ≈ 1.8 TB/year

### 3.2 Requests Per Second

Assume around 1 billion redirects per day.

> Redirect RPS = 1 Billion / 86,400  
> ≈ 11,600 requests/second

For URL creation:

> Write RPS = 10 Million / 86,400  
> ≈ 116 requests/second

****Estimated Traffic:**** The system is highly read-heavy and should handle around 12K requests per second on average.

### 3.3 Peak Traffic

During traffic spikes, redirect requests may increase several times above average.

> Peak RPS ≈ 5 × Average  
> ≈ 60K requests/second

The system should be designed to scale horizontally and serve popular links directly from cache.

## 4\. High Level Design

The High-Level Design (HLD) shows how different components of the URL Shortener work together to create short URLs and redirect users quickly to the original links.

![[frame_3633.webp|frame_3633]]

System Architecture

### Core Components

- ****Client:**** The web or mobile application allows users to create and access short URLs.
- ****API Gateway:**** Acts as the single entry point and routes requests to the appropriate backend service.
- ****Load Balancer:**** Distributes requests across multiple application servers.
- ****URL Service:**** Handles short URL creation, custom aliases, expiration, and URL management.
- ****Redirect Service:**** Resolves a short code and redirects the user to the original URL.
- ****ID Generator:**** Generates unique IDs or short codes for new URLs.
- ****Analytics Service:**** Tracks clicks, timestamps, and basic usage statistics.
- ****Redis Cache:**** Stores frequently accessed short-code mappings for faster redirects.
- ****Message Queue:**** Handles analytics events and background tasks asynchronously.
- ****Database:**** Stores short codes, original URLs, expiration time, user information, and link status.

### Request Flow

![[frame_3634.webp|frame_3634]]

Request Flow Diagram

- The user submits a long URL.
- The request reaches the API Gateway and Load Balancer.
- The URL Service generates a unique short code using the ID Generator.
- The short-code-to-original-URL mapping is stored in the Database.
- The generated short URL is returned to the user.
- When someone opens the short URL, the Redirect Service checks Redis Cache.
- If the mapping is not in cache, it is fetched from the Database.
- The user is redirected to the original URL.
- The click event is published to the Message Queue for analytics processing.

### Data Flow

- Short URL mappings are stored permanently in the Database.
- Frequently accessed mappings are cached in Redis.
- Redirect requests use Redis first to keep latency low.
- Analytics events are processed asynchronously through the Message Queue.
- Expired or disabled links are rejected instead of being redirected.

## 5\. Technology Stack

Before designing the data model, it is helpful to identify which technologies can be used by different components of the URL Shortener system.

| ****Component**** | ****Technology**** |
| --- | --- |
| Client Communication | REST API, HTTP/HTTPS |
| API Gateway | NGINX, Kong, AWS API Gateway |
| Load Balancer | NGINX, HAProxy, AWS Elastic Load Balancer |
| Backend Services | Java, Go, Node.js |
| Cache | Redis |
| Message Queue | Apache Kafka |
| SQL Database | PostgreSQL, MySQL |
| NoSQL Database | Cassandra, DynamoDB |
| ID Generation | Base62, Snowflake ID |
| Analytics | Elasticsearch, Apache Flink |
| Authentication | JWT, OAuth 2.0 |
| Monitoring | Prometheus, Grafana |
| Container & Orchestration | Docker, Kubernetes |

## 6\. Data Model Design

The data model defines how the URL Shortener stores and manages users, original URLs, short codes, expiration information, and analytics data. A good schema ensures fast redirects, unique short URLs, and efficient storage.

- Identify the core entities required for URL creation, redirection, and analytics.
- Define relationships between users and shortened URLs.
- Select the appropriate database model based on scalability, read traffic, and performance requirements.

### Core Entities

The URL Shortener system consists of the following core entities:

![[frame_3638.webp|frame_3638]]

ER Diagram

- ****User:**** Stores user profile and account information.
- ****ShortURL:**** Stores the short code, original URL, creation time, and expiration time.
- ****URLMapping:**** Maintains the mapping between a short code and the original URL.
- ****ClickEvent:**** Stores click information such as timestamp, device, and location.
- ****CustomAlias:**** Stores user-defined short aliases when available.

### Database Selection

A combination of SQL, NoSQL, and caching can be used depending on system requirements.

- SQL Database is suitable for users, account information, and structured URL-management data.
- NoSQL Database is suitable for large-scale short URL mappings because it supports horizontal scaling and high read throughput.
- Redis can store frequently accessed short-code mappings for very fast redirects.
- Analytics and click-event data can be stored separately in a high-volume data store for reporting and analysis.

## 7\. API Design

The API design defines how users and client applications communicate with the URL Shortener system to create short URLs, redirect users, and manage links.

- Design REST APIs that are simple, scalable, and easy to consume.
- Use appropriate HTTP methods for URL creation, lookup, and management.
- Secure management APIs using authentication such as JWT or OAuth 2.0.

### URL APIs

| ****Method**** | ****Endpoint**** | ****Description**** |
| --- | --- | --- |
| POST | `/api/v1/urls` | Create a short URL |
| GET | `/api/v1/urls/{shortCode}` | Get URL details |
| DELETE | `/api/v1/urls/{shortCode}` | Delete or disable a short URL |
| PUT | `/api/v1/urls/{shortCode}` | Update expiration or settings |

### Redirect API

| ****Method**** | ****Endpoint**** | ****Description**** |
| --- | --- | --- |
| GET | `/{shortCode}` | Redirect to the original URL |

### Analytics APIs

| ****Method**** | ****Endpoint**** | ****Description**** |
| --- | --- | --- |
| GET | `/api/v1/urls/{shortCode}/stats` | Get click statistics |
| GET | `/api/v1/urls/{shortCode}/history` | Get recent click events |

### Sample Request

****POST**** `/api/v1/urls`

> `{`  
> `  "longUrl": "https://example.com/articles/system-design/url-shortener",`  
> `  "customAlias": "sysdesign",`  
> `  "expiresAt": "2026-12-31T23:59:59Z"`  
> `}`

### Sample Response

> `{`  
> `  "shortCode": "sysdesign",`  
> `  "shortUrl": "https://short.ly/sysdesign",`  
> `  "status": "ACTIVE",`  
> `  "expiresAt": "2026-12-31T23:59:59Z"`  
> `}`

## 8\. Low Level Design

The Low-Level Design (LLD) describes the internal structure of the URL Shortener system by defining the main classes, their responsibilities, and their interactions.

### Core Classes

The URL Shortener system can be designed using the following core classes:

![[frame_3639.webp|frame_3639]]

UML Diagram

- ****User:**** Manages user profile information and created short URLs.
- ****ShortURL:**** Stores short code, original URL, creation time, expiration time, and status.
- ****URLMapping:**** Maintains the mapping between a short code and its original URL.
- ****ClickEvent:**** Stores click information such as timestamp, device, and location.
- ****CustomAlias:**** Manages user-defined aliases for shortened URLs.
- ****URLService:**** Handles URL creation, validation, deletion, and expiration.
- ****RedirectService:**** Resolves short codes and redirects users to the original URL.

### SOLID Principles

The URL Shortener system follows SOLID principles to keep the design modular, maintainable, and easy to extend.

- ****Single Responsibility Principle (SRP):**** Each class handles one responsibility. For example, URLService manages shortened URLs while RedirectService handles redirects.
- ****Open/Closed Principle (OCP):**** New short-code generation or analytics strategies can be added without changing existing core logic.
- ****Liskov Substitution Principle (LSP):**** Different ID-generation implementations can be used through a common interface.
- ****Interface Segregation Principle (ISP):**** Classes depend only on the methods required for their functionality.
- ****Dependency Inversion Principle (DIP):**** High-level services depend on abstractions rather than specific databases, caches, or ID generators.

### Design Patterns

| ****Design Pattern**** | ****Usage**** |
| --- | --- |
| Singleton | Database or cache connection management |
| Factory | Create different short-code generators |
| Strategy | Handle different URL-generation or expiration strategies |
| Observer | Process click and analytics events asynchronously |

## 9\. Scalability & Performance

Scalability and performance ensure that the URL Shortener can handle millions of links and very high redirect traffic while keeping redirects fast, reliable, and highly available.

![[frame_3635.webp|frame_3635]]

Scalability Architecture

- ****Caching:**** Redis stores frequently accessed short-code mappings to reduce database lookups.
- ****Load Balancing:**** A Load Balancer distributes redirect and URL-creation requests across multiple servers.
- ****Database Replication:**** Read replicas improve redirect performance and provide fault tolerance.
- ****Database Sharding:**** URL mappings can be distributed across multiple database servers using the short code or URL ID.
- ****Horizontal Scaling:**** Additional URL and Redirect Service instances can be added as traffic increases.
- ****Asynchronous Processing:**** Kafka handles click events, analytics, logging, and background tasks.
- ****CDN / Edge Caching:**** Popular redirects can be served closer to users to reduce latency.
- ****Rate Limiting:**** Protects the system from abuse, bots, and excessive URL-creation requests.
- ****Unique ID Generation:**** Distributed ID generators help create short codes without collisions.
- ****Multi-Region Deployment:**** Services can be deployed across multiple regions for lower latency and higher availability.

## 10\. Bottlenecks & Improvements

This section discusses the common challenges a URL Shortener may face at scale and the techniques used to maintain fast redirects, high availability, and reliable link management.

### Common Bottlenecks

- ****Database Bottleneck:**** A single database may struggle with a very large number of redirect lookups.
- ****Cache Misses:**** Frequent cache misses increase database load and redirect latency.
- ****Hot URLs:**** Some popular short links may receive extremely high traffic.
- ****ID Collision:**** Poor short-code generation can create duplicate short URLs.
- ****Analytics Overload:**** Recording every click synchronously can slow down redirects.
- ****Expired Links:**** Large numbers of expired URLs can increase unnecessary storage and lookup overhead.
- ****Single Region Failure:**** A regional outage can make redirects unavailable for users in that area.

### Possible Improvements

- ****Redis Caching:**** Cache popular short-code mappings for faster redirects.
- ****Database Sharding & Replication:**** Distribute URL mappings across multiple databases and use replicas for heavy read traffic.
- ****Asynchronous Analytics:**** Send click events to Kafka and process them separately from the redirect flow.
- ****Distributed ID Generation:**** Use Base62 with unique distributed IDs to avoid collisions.
- ****Hot URL Replication:**** Replicate frequently accessed mappings across cache nodes and regions.
- ****Automatic Cleanup:**** Periodically remove expired or disabled URLs.
- ****Multi-Region Deployment:**** Deploy redirect services in multiple regions for lower latency and better availability.
- ****Monitoring & Alerting:**** Monitor redirect latency, cache-hit ratio, database load, failed redirects, and traffic spikes.