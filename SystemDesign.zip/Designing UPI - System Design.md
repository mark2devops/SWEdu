---
title: "Designing UPI - System Design"
source: "https://www.geeksforgeeks.org/system-design/designing-upi-system-design/"
author:
  - "[[GeeksforGeeks]]"
published: 2024-06-03
created: 2026-09-23
description: "Your All-in-One Learning Portal: GeeksforGeeks is a comprehensive educational platform that empowers learners across domains-spanning computer science and programming, school education, upskilling, commerce, software tools, competitive exams, and more."
tags:
  - "clippings"
---
Designing a UPI-like payment system means building a platform where users can transfer money instantly between bank accounts. In an interview, the main focus is on secure payments, correct transaction handling, and high availability.

- Users should be able to link their bank account and send or receive money using a UPI ID or mobile number.
- The system should process payments securely, avoid duplicate transactions, and correctly handle success, failure, pending, and reversal cases.

## 1\. Problem Statement

We need to design a UPI-like payment system where users can transfer money instantly between bank accounts using a UPI ID or linked mobile number. The system should be secure, highly available, and able to process payments with very low latency.

- Users should be able to send, receive, and track payments in real time.
- The system should prevent duplicate transactions and correctly handle success, failure, pending, and reversal cases.

## 2\. System Requirements

Before designing the system, we need to identify its functional and non-functional requirements. These requirements define the expected features and quality attributes of the system.

### Functional Requirements

Functional requirements describe the core features that the system must support.

- Users should be able to register, authenticate, and securely link their bank accounts.
- Users should be able to send and receive money using a UPI ID, mobile number, or QR code.
- Users should be able to make payments to merchants and other users.
- The system should authenticate transactions using a UPI PIN.
- Users should be able to check transaction status and view payment history.
- The system should handle successful, failed, pending, and reversed transactions correctly.

### Non-Functional Requirements

Non-functional requirements define how well the system should perform under different conditions.

- ****Availability:**** The payment system should remain available with minimal downtime.
- ****Scalability:**** It should support millions of users and a large number of concurrent transactions.
- ****Reliability:**** Payments should not be lost, duplicated, or processed incorrectly.
- ****Low Latency:**** Transactions should be processed and confirmed with minimal delay.
- ****Consistency:**** Transaction status and account balances should remain consistent across participating systems.
- ****Security:**** User authentication, UPI PIN, bank information, and transaction data should be securely handled.

## 3\. Capacity Estimation

Before designing the architecture, we need to estimate the expected number of users, transactions, storage, and traffic. These estimates help us choose the right servers, databases, cache, and scaling strategy.

### Assumptions

| ****Parameter**** | ****Assumption**** |
| --- | --- |
| Registered Users | 500 Million |
| Daily Active Users | 200 Million |
| Transactions per Day | 500 Million |
| Average Transaction Record | 1 KB |
| Read: Write Ratio | 3: 1 |

### 3.1 Storage Estimation

Assume each transaction requires approximately 1 KB of storage.

> Daily Storage = 500 Million × 1 KB  
> ≈ 500 GB/day

For 30 days:

> Monthly Storage = 30 × 500 GB  
> ≈ 15 TB/month

****Estimated Storage:**** ~15 TB/month, excluding logs, analytics, and backup data.

### 3.2 Requests Per Second (RPS)

Assume the system processes around 500 million transactions per day.

> RPS = 500 Million / 86,400  
> ≈ 5,787 transactions/second  
> ≈ 5.8K TPS

****Estimated Traffic:**** The system should handle around 6K transactions per second on average, with much higher capacity during peak hours.

### 3.3 Peak Traffic

During festivals, sales, salary days, or other high-demand periods, transaction traffic can increase significantly.

> Peak Traffic ≈ 5 × Average Traffic  
> ≈ 30K transactions/second

The system should therefore be designed to handle sudden traffic spikes without affecting payment reliability.

### 3.4 Server Estimation

Assume one payment-processing server can handle around 2,000 transactions per second.

> Servers Required = 30,000 / 2,000  
> ≈ 15 Servers

With additional capacity for failures and traffic spikes, we can keep around 20–25 payment-processing servers.

> ****Note:**** These values are design assumptions used for system-design discussion and not official UPI traffic figures.

## 4\. High Level Design

The High-Level Design (HLD) shows how different components of the UPI system work together to process payments securely, reliably, and with low latency.

![[upi_payment_system_architecture.webp|upi_payment_system_architecture]]

UPI Payment System Architecture

### Core Components

- ****Client:**** The UPI mobile application allows users to send money, scan QR codes, check balances, and view transaction history.
- ****API Gateway:**** Acts as the entry point for client requests and routes them to the appropriate backend services.
- ****Load Balancer:**** Distributes incoming requests across multiple application servers for better availability and scalability.
- ****User Service:**** Manages user information, profiles, linked accounts, and user-related operations.
- ****Payment Service:**** Handles payment requests and coordinates the payment processing flow.
- ****Bank Integration Service:**** Communicates with participating banks for account validation, debit, credit, and other banking operations.
- ****Transaction Service:**** Creates and maintains transaction records and statuses such as Pending, Success, Failed, or Reversed.
- ****Notification Service:**** Handles payment-related notifications and sends events to the appropriate notification channels.
- ****Push Notification Service:**** Sends payment success, failure, and status notifications through push notifications.
- ****SMS/Email Service:**** Sends transaction alerts and other notifications through SMS or email.
- ****Message Queue (Kafka):**** Handles transaction events, notifications, and other background tasks asynchronously.
- ****Redis Cache:**** Stores frequently accessed or temporary data such as sessions and transaction-related information for faster access.
- ****Database Cluster:**** Stores persistent data such as users, linked accounts, transaction records, and payment statuses.
- ****Object Storage:**** Stores files or other application objects that do not need to be stored directly in the database.

### Request Flow

![[upi_payment_system_flow.webp|upi_payment_system_flow]]

UPI Payment System - Request Flow Diagram

- The user enters the receiver details and initiates a payment.
- The request reaches the API Gateway and Authentication Service.
- The Payment Service creates a transaction with status `PENDING`.
- The Fraud Detection Service validates the transaction.
- The UPI Switch routes the request to the sender's and receiver's banks.
- The sender's bank debits the amount and the receiver's bank credits it.
- The Transaction Service updates the payment status to `SUCCESS` or `FAILED`.
- The Notification Service sends the final payment status to both users.

### Data Flow

- The client sends the payment request to the backend through the API Gateway.
- Transaction details are temporarily stored and validated before processing.
- The payment request is routed through the UPI Switch to the participating banks.
- Final transaction status is stored in the Database.
- Payment events are published to the Message Queue for notifications and background processing.
- Users receive the final payment status through the UPI application.

## 5\. Technology Stack

Before designing the data model, it is helpful to identify which technologies can be used by different components of the UPI system.

| ****Component**** | ****Technology**** |
| --- | --- |
| Client Communication | REST API, gRPC |
| API Gateway | NGINX, Kong, AWS API Gateway |
| Load Balancer | NGINX, HAProxy, AWS Elastic Load Balancer |
| Backend Services | Java, Go (Microservices) |
| Cache | Redis |
| Message Queue | Apache Kafka |
| SQL Database | PostgreSQL, MySQL |
| NoSQL Database | Cassandra, DynamoDB |
| UPI / Bank Integration | Secure Banking APIs |
| Authentication | OAuth 2.0, JWT, UPI PIN |
| Encryption | TLS, AES |
| Fraud Detection | Rule Engine, Machine Learning |
| Notifications | Firebase Cloud Messaging, SMS Services |
| Monitoring | Prometheus, Grafana |
| Container & Orchestration | Docker, Kubernetes |

## 6\. Data Model Design

The data model defines how the UPI system stores and manages users, bank accounts, UPI IDs, transactions, and merchants. A well-designed schema ensures secure transaction processing, data consistency, and scalability as the number of payments grows.

- Identify the core entities required for users, bank accounts, and payment transactions.
- Define relationships between entities to maintain transaction consistency.
- Select the appropriate database model based on reliability, scalability, and performance requirements.

### Core Entities

The UPI system consists of the following core entities:

![[upi_payment_system_ere.webp|upi_payment_system_ere]]

UPI System ER Diagram

- ****User:**** Stores user profile and account information.
- ****Bank Account:**** Stores linked bank account details and bank information.
- ****UPI ID:**** Represents the virtual payment address linked to a user's bank account.
- ****Transaction:**** Stores sender, receiver, amount, timestamp, and transaction status.
- ****Merchant:**** Stores merchant information and payment-related details.

### Database Selection

A combination of SQL and NoSQL databases can be used depending on system requirements.

- ****SQL Database**** is suitable for storing users, bank accounts, transactions, and payment records because these require strong consistency.
- ****NoSQL Database**** can be used for high-volume transaction logs, analytics, and historical data.
- ****Redis**** can store frequently accessed data such as user sessions, transaction states, and temporary payment information.

## 7\. API Design

The API design defines how users and client applications communicate with the UPI backend to perform operations such as authentication, bank account linking, payments, and transaction tracking.

- Design REST APIs that are simple, secure, and easy to consume.
- Use appropriate HTTP methods for different operations.
- Secure APIs using authentication mechanisms such as OAuth 2.0, JWT, and UPI PIN verification.

### Authentication APIs

| ****Method**** | ****Endpoint**** | ****Description**** |
| --- | --- | --- |
| POST | `/api/v1/auth/register` | Register a new user |
| POST | `/api/v1/auth/login` | Authenticate a user |
| POST | `/api/v1/auth/logout` | Logout the current user |

### Bank Account APIs

| ****Method**** | ****Endpoint**** | ****Description**** |
| --- | --- | --- |
| POST | `/api/v1/accounts/link` | Link a bank account |
| GET | `/api/v1/accounts` | Get linked bank accounts |
| DELETE | `/api/v1/accounts/{accountId}` | Remove a linked account |

### Payment APIs

| ****Method**** | ****Endpoint**** | ****Description**** |
| --- | --- | --- |
| POST | `/api/v1/payments` | Initiate a payment |
| GET | `/api/v1/payments/{transactionId}` | Get transaction status |
| GET | `/api/v1/payments/history` | Get payment history |

### UPI ID APIs

| ****Method**** | ****Endpoint**** | ****Description**** |
| --- | --- | --- |
| POST | `/api/v1/upi-ids` | Create a UPI ID |
| GET | `/api/v1/upi-ids` | Get user's UPI IDs |
| DELETE | `/api/v1/upi-ids/{upiId}` | Remove a UPI ID |

### Sample Request

****POST**** `/api/v1/payments`

> `{`  
> `  "senderUpiId": "user1@upi",`  
> `  "receiverUpiId": "user2@upi",`  
> `  "amount": 500,`  
> `  "currency": "INR"`  
> `}`

### Sample Response

> `{`  
> `  "transactionId": "txn_12345",`  
> `  "status": "SUCCESS",`  
> `  "amount": 500,`  
> `  "timestamp": "2026-08-26T10:30:45Z"`  
> `}`

## 8\. Low Level Design

The Low-Level Design (LLD) describes the internal structure of the UPI system by defining the key classes, their responsibilities, and interactions.

### Core Classes

The UPI system can be designed using the following core classes:

![[upi_payment_system_uml.webp|upi_payment_system_uml]]

UPI Payment System - UML Class Diagram

- ****User:**** Manages user profile and linked bank accounts.
- ****BankAccount:**** Stores bank account information associated with a user.
- ****UPIId:**** Represents the UPI ID linked to a bank account.
- ****Transaction:**** Stores sender, receiver, amount, status, and timestamp.
- ****Payment:**** Handles payment processing and payment status.
- ****Notification:**** Sends transaction success, failure, and pending notifications.

### SOLID Principles

The UPI system follows SOLID principles to keep the application modular and easy to maintain.

- ****Single Responsibility Principle (SRP):**** Each class handles one responsibility, such as payments or notifications.
- ****Open/Closed Principle (OCP):**** New payment or authentication methods can be added without changing existing logic.
- ****Liskov Substitution Principle (LSP):**** Different payment implementations can be used through a common payment interface.
- ****Interface Segregation Principle (ISP):**** Classes depend only on the methods they actually require.
- ****Dependency Inversion Principle (DIP):**** High-level services depend on abstractions instead of specific banks or payment providers.

### Design Patterns

| ****Design Pattern**** | ****Usage**** |
| --- | --- |
| Singleton | Database or cache connection management |
| Factory | Create different transaction or payment types |
| Strategy | Handle different payment or authentication strategies |
| Observer | Notify users when transaction status changes |

## 9\. Scalability & Performance

Scalability and performance ensure that the UPI system can handle millions of users and payment transactions while maintaining low latency, high availability, and reliable transaction processing.

![[upi_payment_system_scalability_architecture.webp|upi_payment_system_scalability_architecture]]

UPI Payment System - Scalability Architecture

- ****Caching:**** Redis stores frequently accessed data such as user sessions, bank information, and temporary transaction states to reduce database load.
- ****Load Balancing:**** A Load Balancer distributes payment requests across multiple servers to prevent overload.
- ****Database Replication:**** Multiple database replicas improve read performance and provide fault tolerance during failures.
- ****Database Sharding:**** Transaction data can be distributed across multiple database servers to support growing payment traffic.
- ****Asynchronous Processing:**** Kafka processes notifications, transaction events, reconciliation, and other background tasks asynchronously.
- ****Horizontal Scaling:**** Additional Payment, Transaction, Authentication, and Notification Service instances can be added during high traffic.
- ****Rate Limiting:**** Rate limiting protects the system from excessive requests, abuse, and sudden traffic spikes.
- ****Idempotency:**** Unique transaction IDs ensure that retrying the same payment request does not result in duplicate transactions.
- ****Failover:**** Requests can be redirected to healthy service instances when a server or component becomes unavailable.

## 10\. Bottlenecks & Improvements

This section discusses the major challenges a UPI system can face at scale and the techniques used to maintain reliability, consistency, and high availability.

### Common Bottlenecks

- ****Bank Downtime:**** A participating bank may be slow or unavailable, causing transactions to remain pending or fail.
- ****High Transaction Traffic:**** Sudden payment spikes can overload payment and transaction services.
- ****Duplicate Transactions:**** Retries due to network issues may cause the same payment request to be processed more than once.
- ****Database Bottleneck:**** A single database may struggle with a very large number of transaction reads and writes.
- ****Message Queue Backlog:**** Transaction events, notifications, or reconciliation tasks may accumulate during traffic spikes.
- ****Fraud Detection Delay:**** Complex fraud checks can increase transaction-processing latency.
- ****Network Failure:**** Communication failures between the UPI system and participating banks can leave transaction status uncertain.

### Possible Improvements

- ****Auto Scaling:**** Automatically add or remove service instances based on transaction traffic.
- ****Failover Mechanism:**** Redirect requests to healthy servers when a service instance fails.
- ****Retry Mechanism:**** Retry temporary failures using controlled retry policies and exponential backoff.
- ****Idempotency:**** Use unique transaction IDs to prevent duplicate payments during retries.
- ****Reconciliation:**** Periodically compare transaction records between the UPI system and banks to resolve pending or inconsistent transactions.
- ****Database Sharding & Replication:**** Distribute transaction data across multiple databases and maintain replicas for scalability and fault tolerance.
- ****Monitoring & Alerting:**** Continuously monitor transaction failures, latency, bank availability, Kafka lag, and unusual payment activity.