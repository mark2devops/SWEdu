---
title: "Design Distributed Job Scheduler | System Design"
source: "https://www.geeksforgeeks.org/system-design/design-distributed-job-scheduler-system-design/"
author:
  - "[[GeeksforGeeks]]"
published: 2024-04-02
created: 2026-09-23
description: "Your All-in-One Learning Portal: GeeksforGeeks is a comprehensive educational platform that empowers learners across domains-spanning computer science and programming, school education, upskilling, commerce, software tools, competitive exams, and more."
tags:
  - "clippings"
---
Designing a Distributed Job Scheduler means building a system that can schedule and execute jobs across many worker machines at the right time. In an interview, the main focus is on reliable execution, avoiding duplicate runs, handling failures, and scaling to a large number of jobs.

- Users should be able to schedule one-time or recurring jobs and track their execution status.
- The system should distribute jobs across workers, retry failed jobs, and make sure the same job is not executed multiple times accidentally.

## 1\. Problem Statement

We need to design a Distributed Job Scheduler where users can create jobs that run immediately, at a specific time, or on a recurring schedule. The system should assign these jobs to available workers and track their execution reliably.

- The scheduler should support retries, priorities, recurring jobs, and worker failures.
- It should prevent duplicate execution, recover from crashes, and scale to millions of scheduled jobs.

## 2\. System Requirements

Before designing the Distributed Job Scheduler, we need to identify its functional and non-functional requirements. These requirements define what the scheduler should do and how reliably it should operate.

### Functional Requirements

- Users should be able to create one-time, delayed, and recurring jobs.
- The system should allow users to specify execution time, priority, and retry policy.
- Jobs should be assigned to available worker machines for execution.
- Users should be able to view job status such as `SCHEDULED`, `RUNNING`, `SUCCESS`, or `FAILED`.
- Failed jobs should be retried based on the configured retry policy.
- Users should be able to cancel or pause scheduled jobs.
- The system should track job execution history and results.
- Recurring jobs should run automatically according to their configured schedule.

### Non-Functional Requirements

- ****Availability:**** The scheduler should remain available even if some scheduler or worker nodes fail.
- ****Scalability:**** It should support millions of scheduled jobs and a large number of workers.
- ****Reliability:**** Jobs should not be lost when a server crashes.
- ****Consistency:**** The same job should not be unintentionally executed multiple times.
- ****Low Latency:**** Ready jobs should be assigned to workers with minimal delay.
- ****Fault Tolerance:**** Failed workers and scheduler nodes should be detected and recovered from automatically.
- ****Durability:**** Job definitions, schedules, and execution states should be stored reliably.

## 3\. Capacity Estimation

Before designing the architecture, we estimate the expected number of jobs, executions, workers, and storage. These estimates help us choose the right queue, database, scheduler nodes, and worker capacity.

### Assumptions

| ****Parameter**** | ****Assumption**** |
| --- | --- |
| Registered Users | 10 Million |
| Scheduled Jobs | 100 Million |
| Job Executions per Day | 500 Million |
| Average Job Metadata Size | 2 KB |
| Average Job Execution Time | 5 Seconds |
| Peak Concurrent Jobs | 100,000 |

### 3.1 Job Execution Rate

Assume the system processes around 500 million job executions per day.

> Execution RPS = 500 Million / 86,400  
> ≈ 5,800 jobs/second

During peak periods:

> Peak RPS ≈ 5 × Average  
> ≈ 29,000 jobs/second

### 3.2 Storage Estimation

Assume each job requires around 2 KB of metadata.

> Storage = 100 Million × 2 KB  
> ≈ 200 GB

Execution history, logs, retries, and results will require additional storage.

### 3.3 Worker Estimation

Assume one worker can handle around 50 concurrent jobs.

> Workers Required = 100,000 / 50  
> ≈ 2,000 Workers

Additional worker capacity should be kept for failures and traffic spikes.

### 3.4 Scheduler Load

The scheduler should continuously scan or index jobs that are ready to execute.

Instead of scanning all scheduled jobs, the system should use efficient structures such as:

- Time-based partitions
- Priority queues
- Delayed queues
- Sorted sets

This allows the scheduler to quickly find jobs whose execution time has arrived.

## 4\. High Level Design

The High-Level Design (HLD) shows how different components of the Distributed Job Scheduler work together to create, schedule, queue, execute, retry, and track jobs reliably across multiple workers.

![[a1.png|a1]]

### Core Components

- ****Client:**** Allows users or applications to create, update, cancel, and monitor jobs.
- ****API Gateway:**** Acts as the entry point and routes requests to the appropriate backend services.
- ****Load Balancer:**** Distributes incoming requests across multiple scheduler or API servers.
- ****Job Service:**** Manages job creation, configuration, priority, retry policy, and job metadata.
- ****Scheduler Service:**** Finds jobs whose execution time has arrived and prepares them for execution.
- ****Distributed Lock / Leader Election:**** Ensures that multiple scheduler nodes do not schedule the same job at the same time.
- ****Job Queue:**** Stores jobs that are ready to be executed and distributes them to workers.
- ****Worker Service:**** Pulls jobs from the queue and executes them.
- ****Retry Service:**** Reschedules failed jobs based on retry count and backoff policy.
- ****Result Service:**** Stores job output, execution status, duration, and failure information.
- ****Redis Cache:**** Stores temporary job states, locks, worker heartbeats, and frequently accessed scheduling information.
- ****Database:**** Stores job definitions, schedules, status, retry configuration, and execution history.
- ****Monitoring Service:**** Tracks worker health, queue size, failed jobs, execution latency, and scheduler status.

### Request Flow

![[distributed_job_schedular5.webp|distributed_job_schedular5]]

Distributed Job Scheduler - Request Flow Diagram

1. The user creates a job with execution time, priority, and retry configuration.
2. The request reaches the API Gateway and Job Service.
3. The Job Service stores the job with status `SCHEDULED`.
4. The Scheduler Service detects when the job is ready to run.
5. A distributed lock ensures that only one scheduler instance processes the job.
6. The Scheduler publishes the job to the Job Queue.
7. An available Worker picks up the job and changes its status to `RUNNING`.
8. The Worker executes the job and sends the result to the Result Service.
9. If successful, the job is marked `SUCCESS`.
10. If it fails, the Retry Service may schedule it again based on its retry policy.

### Data Flow

- Job definitions and schedules are stored permanently in the Database.
- Scheduler nodes read only jobs that are close to their execution time instead of scanning the complete job table.
- Ready jobs are pushed to the Job Queue for asynchronous execution.
- Workers continuously consume jobs and send heartbeats to show that they are alive.
- Failed jobs are routed through the Retry Service and scheduled with a future execution time.
- Execution results, logs, and history are stored separately for monitoring and debugging.

## 5\. Technology Stack

Before designing the data model, it is helpful to identify which technologies can be used by different components of the Distributed Job Scheduler.

| ****Component**** | ****Technology**** |
| --- | --- |
| Client Communication | REST API, gRPC |
| API Gateway | NGINX, Kong, AWS API Gateway |
| Load Balancer | NGINX, HAProxy, AWS Elastic Load Balancer |
| Backend Services | Java, Go, Node.js |
| Job Queue | Apache Kafka, RabbitMQ, AWS SQS |
| Delayed Scheduling | Redis Sorted Sets, Kafka Delayed Queue |
| Cache | Redis |
| Distributed Locking | Redis, ZooKeeper, etcd |
| Leader Election | ZooKeeper, etcd |
| SQL Database | PostgreSQL, MySQL |
| NoSQL Database | Cassandra, DynamoDB |
| Worker Execution | Docker Containers, Kubernetes Jobs |
| Retry Processing | Exponential Backoff, Dead Letter Queue |
| Monitoring | Prometheus, Grafana |
| Logging | ELK Stack |
| Container & Orchestration | Docker, Kubernetes |

## 6\. Data Model Design

The data model defines how the Distributed Job Scheduler stores and manages jobs, schedules, workers, executions, retries, and results. A good schema helps the system schedule jobs correctly and track every execution reliably.

- Identify the core entities required for scheduling, execution, retry, and monitoring.
- Define relationships between jobs, workers, executions, and retry attempts.
- Select the appropriate database model based on consistency, scalability, and scheduling performance.

### Core Entities

The Distributed Job Scheduler consists of the following core entities:

![[distributed_job_schedular_2.webp|distributed_job_schedular_2]]

Distributed Job Scheduler - ER Diagram

- ****Job:**** Stores job name, payload, priority, status, and retry configuration.
- ****Schedule:**** Stores execution time, recurrence rule, and next scheduled run.
- ****Worker:**** Stores worker ID, status, capacity, and heartbeat information.
- ****JobExecution:**** Stores execution start time, end time, worker, status, and result.
- ****RetryAttempt:**** Stores retry count, retry time, and failure reason.
- ****JobResult:**** Stores output, error information, and execution metadata.

### Database Selection

A combination of SQL, NoSQL, and Redis can be used depending on system requirements.

- ****SQL Database**** is suitable for job definitions, schedules, execution states, and retry information where consistency is important.
- ****NoSQL Database**** can be used for large-scale execution history, logs, and high-volume job metadata.
- ****Redis Sorted Sets**** can store jobs ordered by execution time for fast scheduling.
- ****Redis**** can also store distributed locks, worker heartbeats, and temporary job states.

## 7\. API Design

The API design defines how users and applications communicate with the Distributed Job Scheduler to create jobs, update schedules, track executions, and manage retries.

- Design REST APIs that are simple, scalable, and easy to use.
- Use appropriate HTTP methods for job creation, scheduling, cancellation, and status tracking.
- Secure APIs using authentication and authorization.

### Job APIs

| ****Method**** | ****Endpoint**** | ****Description**** |
| --- | --- | --- |
| POST | `/api/v1/jobs` | Create a new job |
| GET | `/api/v1/jobs/{jobId}` | Get job details |
| PUT | `/api/v1/jobs/{jobId}` | Update job configuration |
| DELETE | `/api/v1/jobs/{jobId}` | Cancel or delete a job |

### Schedule APIs

| ****Method**** | ****Endpoint**** | ****Description**** |
| --- | --- | --- |
| POST | `/api/v1/jobs/{jobId}/schedule` | Create or update a schedule |
| GET | `/api/v1/jobs/{jobId}/schedule` | Get job schedule |
| POST | `/api/v1/jobs/{jobId}/pause` | Pause a scheduled job |
| POST | `/api/v1/jobs/{jobId}/resume` | Resume a paused job |

### Execution APIs

| ****Method**** | ****Endpoint**** | ****Description**** |
| --- | --- | --- |
| POST | `/api/v1/jobs/{jobId}/run` | Run a job immediately |
| GET | `/api/v1/executions/{executionId}` | Get execution status |
| GET | `/api/v1/jobs/{jobId}/executions` | Get execution history |
| POST | `/api/v1/executions/{executionId}/retry` | Retry a failed execution |

### Worker APIs

| ****Method**** | ****Endpoint**** | ****Description**** |
| --- | --- | --- |
| POST | `/api/v1/workers/register` | Register a worker |
| POST | `/api/v1/workers/{workerId}/heartbeat` | Send worker heartbeat |
| GET | `/api/v1/workers` | Get available workers |

### Sample Request

****POST**** `/api/v1/jobs`

> `{`  
> `  "name": "daily-report",`  
> `  "payload": {`  
> `    "reportType": "sales"`  
> `  },`  
> `  "priority": "HIGH",`  
> `  "schedule": "0 9 * * *",`  
> `  "maxRetries": 3`  
> `}`

### Sample Response

> `{`  
> `  "jobId": "job_501",`  
> `  "status": "SCHEDULED",`  
> `  "nextRunTime": "2026-09-04T09:00:00Z"`  
> `}`

## 8\. Low Level Design

The Low-Level Design (LLD) describes the internal structure of the Distributed Job Scheduler by defining the main classes, their responsibilities, and their interactions.

### Core Classes

The Distributed Job Scheduler can be designed using the following core classes:

![[distributed_job_schedular_3.webp|distributed_job_schedular_3]]

Distributed Job Scheduler - UML Diagram

- ****Job:**** Stores job name, payload, priority, status, and retry configuration.
- ****Schedule:**** Stores execution time, recurrence rule, and next run time.
- ****Worker:**** Represents a worker machine and stores capacity, status, and heartbeat information.
- ****JobExecution:**** Represents one execution of a job and stores start time, end time, status, and assigned worker.
- ****RetryAttempt:**** Stores retry count, retry time, and failure reason.
- ****JobResult:**** Stores execution output, error details, and result metadata.
- ****SchedulerService:**** Finds ready jobs and pushes them to the execution queue.
- ****WorkerService:**** Pulls jobs from the queue and executes them.

### SOLID Principles

The Distributed Job Scheduler follows SOLID principles to keep the system modular, maintainable, and easy to extend.

- ****Single Responsibility Principle (SRP):**** Each class handles one responsibility. For example, SchedulerService handles scheduling while WorkerService handles execution.
- ****Open/Closed Principle (OCP):**** New scheduling, retry, or execution strategies can be added without modifying existing core logic.
- ****Liskov Substitution Principle (LSP):**** Different worker or scheduling implementations can be used through common interfaces.
- ****Interface Segregation Principle (ISP):**** Classes depend only on the methods required for their functionality.
- ****Dependency Inversion Principle (DIP):**** High-level services depend on abstractions rather than specific queues, databases, or worker implementations.

### Design Patterns

| ****Design Pattern**** | ****Usage**** |
| --- | --- |
| ****Strategy**** | Handle different scheduling and retry strategies |
| ****Observer**** | Notify components when job status changes |
| ****Factory**** | Create different job or worker types |
| ****Leader Election**** | Ensure only one scheduler coordinates a job at a time |

## 9\. Scalability & Performance

Scalability and performance ensure that the Distributed Job Scheduler can handle millions of scheduled jobs and thousands of workers while keeping execution reliable and timely.

![[distributed_job_schedular_4.webp|distributed_job_schedular_4]]

Distributed Job Scheduler - Scalability Architecture

- ****Horizontal Scaling:**** Add more scheduler and worker instances as the number of jobs increases.
- ****Distributed Scheduling:**** Jobs can be partitioned across scheduler nodes based on time range, job ID, or shard.
- ****Job Queue:**** Kafka, RabbitMQ, or SQS can buffer ready jobs and distribute them across workers.
- ****Redis Sorted Sets:**** Store jobs ordered by execution time so schedulers can quickly find jobs that are ready to run.
- ****Worker Auto Scaling:**** Increase or decrease worker instances based on queue length and execution load.
- ****Distributed Locking:**** Redis, ZooKeeper, or etcd can prevent multiple scheduler nodes from scheduling the same job.
- ****Database Sharding:**** Job and execution data can be distributed across multiple database servers.
- ****Database Replication:**** Read replicas improve performance for job history and monitoring queries.
- ****Asynchronous Processing:**** Job execution, retries, logging, and notifications are processed independently.
- ****Priority Queues:**** High-priority jobs can be processed before normal or low-priority jobs.
- ****Retry with Backoff:**** Failed jobs can be retried using exponential backoff to avoid overloading downstream services.
- ****Dead Letter Queue:**** Jobs that repeatedly fail can be moved to a separate queue for investigation.

## 10\. Bottlenecks & Improvements

This section discusses the common challenges a Distributed Job Scheduler may face at scale and the techniques used to keep scheduling, execution, and retries reliable.

### Common Bottlenecks

- ****Scheduler Bottleneck:**** A single scheduler may struggle to scan and dispatch a very large number of jobs.
- ****Duplicate Execution:**** Multiple scheduler nodes may pick the same job at the same time.
- ****Queue Backlog:**** A sudden increase in ready jobs can create a large execution queue.
- ****Worker Failure:**** A worker may crash while executing a job and leave it in an uncertain state.
- ****Database Bottleneck:**** Frequent job-status updates and execution-history writes can overload the database.
- ****Retry Storm:**** Many failed jobs retrying together can overload downstream services.
- ****Long-Running Jobs:**** Some jobs may occupy worker capacity for a long time and delay other jobs.
- ****Clock Skew:**** Different scheduler nodes may have slightly different system times and trigger jobs incorrectly.

### Possible Improvements

- ****Scheduler Sharding:**** Partition jobs across scheduler nodes by time range, shard, or job ID.
- ****Distributed Locking:**** Use Redis, ZooKeeper, or etcd so only one scheduler can claim a job.
- ****Lease-Based Execution:**** Assign a temporary execution lease so another worker can retry the job if the original worker fails.
- ****Auto Scaling:**** Add more workers based on queue length and job execution load.
- ****Exponential Backoff:**** Retry failed jobs gradually instead of retrying all of them immediately.
- ****Dead Letter Queue:**** Move repeatedly failing jobs to a separate queue for debugging or manual handling.
- ****Database Sharding & Replication:**** Distribute job and execution data across multiple databases.
- ****Worker Heartbeats:**** Continuously track worker health and recover jobs from failed workers.
- ****Timeouts:**** Terminate jobs that exceed their configured execution limit.
- ****Monitoring & Alerting:**** Monitor scheduling delay, queue size, failed jobs, worker health, retry rate, and execution latency.