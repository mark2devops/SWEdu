---
title: "Adapter Design Pattern"
source: "https://www.geeksforgeeks.org/system-design/adapter-pattern/"
author:
  - "[[GeeksforGeeks]]"
published: 2016-05-03
created: 2026-09-23
description: "Your All-in-One Learning Portal: GeeksforGeeks is a comprehensive educational platform that empowers learners across domains-spanning computer science and programming, school education, upskilling, commerce, software tools, competitive exams, and more."
tags:
  - "clippings"
---
Adapter Design Pattern is a structural pattern that acts as a bridge between two incompatible interfaces, allowing them to work together. It is especially useful for integrating legacy code or third-party libraries into a new system.

- It enables classes with incompatible interfaces to collaborate without modifying their source code.
- It promotes code reusability by allowing existing functionality to be used in new systems.
- It can be implemented in two ways: Class Adapter (using inheritance) and Object Adapter (using composition).
![[Adapter-Design-Pattern.webp|Adapter-Design-Pattern]]

Adapter Design Pattern

In the above Diagram

- Client wants to use a Target interface (it calls Request()).
- Adaptee already has useful functionality, but its method (SpecificRequest()) doesn’t match the Target interface.
- Adapter acts as a bridge: it implements the Target interface (Request()), but inside, it calls the Adaptee’s SpecificRequest().
- This allows the Client to use the Adaptee without changing its code.

## Real-World Example

Adapter Design Pattern can be seen as a mobile adapter that helps in matching the device's power and voltage requirements. Similarly in software development, we use adapter for enabling interoperability between incompatible interfaces

- Software that use different file formats (like CSV, JSON, XML) uses adapters to convert these into a format that the application can work with, facilitating data interoperability.
- Device Drivers in Operating Systems, Database Connectors and Language Converters (Chinese to English and English to Hindi) are more examples of adapters.
- In situations where we have a major change in new vs old APIs, instead of writing the whole old code again, we can use an adapter that does the conversion.

## Components

The components of adapter design pattern:

- ****Target Interface****: The interface expected by the client, defining the operations it can use.
- ****Adaptee****: The existing class with an incompatible interface that needs integration.
- ****Adapter****: Implements the target interface and uses the adaptee internally, acting as a bridge.
- ****Client****: Uses the target interface, unaware of the adapter or adaptee details.

## Working

The Working of adapter design pattern:

- ****Step 1:**** The client initiates a request by calling a method on the adapter via the target interface.
- ****Step 2:**** The adapter maps or transforms the client's request into a format that the adaptee can understand using the adaptee's interface.
- ****Step 3:**** The adaptee does the actual job based on the translated request from the adapter.
- ****Step 4:**** The client receives the results of the call, remaining unaware of the adapter's presence or the specific details of the adaptee.

## Uses

We can use adapter design pattern when:

- Reuses existing code or libraries without rewriting.
- Simplifies integration of new components, keeping the system flexible.
- Centralizes compatibility changes, making maintenance easier and safer.

## Different implementations

The Adapter Design Pattern can be applied in various ways depending on the programming language and the specific context. Here are the primary implementations:

### 1\. Class Adapter (Inheritance-based)

Uses inheritance to adapt the interface of an existing class to the target interface expected by the client.

- In this approach, the adapter class inherits from both the target interface (the one the client expects) and the adaptee (the existing class needing adaptation).
- Programming languages that allow multiple inheritance, like C++, are more likely to use this technique.
- However, in languages like Java and C#, which do not support multiple inheritance, this approach is less frequently used.

### 2\. Object Adapter (Composition-based)

Uses composition to wrap the adaptee object and provide the required interface to the client.

- The object adapter employs composition instead of inheritance. In this implementation, the adapter holds an instance of the adaptee and implements the target interface.
- This approach is more flexible as it allows a single adapter to work with multiple adaptees and does not require the complexities of inheritance.
- The object adapter is widely used in languages like Java and C#.

### 3\. Two-way Adapter

Enables two different interfaces to work together by allowing conversion in both directions.

- A two-way adapter can function as both a target and an adaptee, depending on which interface is being invoked.
- This type of adapter is particularly useful when two systems need to work together and require mutual adaptation.

### 4\. Interface Adapter (Default Adapter)

Provides default implementations for interface methods so only required methods need to be overridden.

- When only a few methods from an interface are necessary, an interface adapter can be employed.
- This is especially useful in cases where the interface contains many methods, and the adapter provides default implementations for those that are not needed.
- This approach is often seen in languages like Java, where abstract classes or default method implementations in interfaces simplify the implementation process.

## Implementation Example

Understand adapter design pattern through an example:

### Problem Statement

Let's consider a scenario where we have an existing system that uses a LegacyPrinter class with a method named printDocument() which we want to adapt into a new system that expects a Printer interface with a method named print(). We'll use the Adapter design pattern to make these two interfaces compatible.

![[class_diagram_of_adapter_design_pattern.webp|class_diagram_of_adapter_design_pattern]]

Class Diagram

### 1\. Target Interface (Printer)

The interface that the client code expects.
C++
```
// Target Interface
class Printer {
public:
    virtual void print() = 0;  // Pure virtual function (abstract method)
};
```
Java
```
/* Target Interface */
interface Printer {
    void print();
}
```
Python
```
""" Target Interface """
from abc import ABC, abstractmethod

class Printer(ABC):
    @abstractmethod
    def print(self):
        pass
```
JavaScript
```
// Target Interface
class Printer {
    print() {
        throw new Error('Method not implemented.');
    }
}
```
### 2\. Adaptee (LegacyPrinter)

The existing class with an incompatible interface.
C++
```
// Adaptee

class LegacyPrinter {
public:
    void printDocument() {
        std::cout << "Legacy Printer is printing a document." << std::endl;
    }
};
```
Java
```
/* Adaptee */

class LegacyPrinter {
    public void printDocument() {
        System.out.println("Legacy Printer is printing a document.");
    }
}
```
Python
```
# Adaptee

class LegacyPrinter:
    def print_document(self):
        print('Legacy Printer is printing a document.')
```
JavaScript
```
// Adaptee

class LegacyPrinter {
    printDocument() {
        console.log('Legacy Printer is printing a document.');
    }
}
```
### 3\. Adapter (PrinterAdapter)

The class that adapts the LegacyPrinter to the Printer interface.
C++
```
// Adapter

class PrinterAdapter : public Printer {
private:
    LegacyPrinter legacyPrinter;

public:
    void print() override {
        legacyPrinter.printDocument();
    }
};
```
Java
```
/* Adapter */

class PrinterAdapter implements Printer {
    private LegacyPrinter legacyPrinter;

    public PrinterAdapter(LegacyPrinter legacyPrinter) {
        this.legacyPrinter = legacyPrinter;
    }

    @Override
    public void print() {
        legacyPrinter.printDocument();
    }
}
```
Python
```
# Adapter

class PrinterAdapter(Printer):
    def __init__(self, legacy_printer):
        self.legacy_printer = legacy_printer

    def print(self):
        self.legacy_printer.print_document()
```
JavaScript
```
// Adapter

class PrinterAdapter {
    constructor(legacyPrinter) {
        this.legacyPrinter = legacyPrinter;
    }

    print() {
        this.legacyPrinter.printDocument();
    }
}
```
### 4\. Client Code
C++
```
// Client Code

void clientCode(Printer& printer) {
    printer.print();
}
```
Java
```
/* Client Code */
interface Printer {
    void print();
}

void clientCode(Printer printer) {
    printer.print();
}
```
Python
```
#
# Client Code
#
from abc import ABC, abstractmethod

class Printer(ABC):
    @abstractmethod
    def print(self):
        pass

def clientCode(printer):
    printer.print()
```
JavaScript
```
// Client Code
function clientCode(printer) {
    printer.print();
}
```
The code that interacts with the Printer interface.

### Complete Code for the above example:
C++
```
// Adapter Design Pattern Example Code

#include <iostream>

// Target Interface
class Printer {
public:
    virtual void print() = 0;
};

// Adaptee
class LegacyPrinter {
public:
    void printDocument() {
        std::cout << "Legacy Printer is printing a document." <<
        std::endl;
    }
};

// Adapter
class PrinterAdapter : public Printer {
private:
    LegacyPrinter legacyPrinter;

public:
    void print() override {
        legacyPrinter.printDocument();
    }
};

// Client Code
void clientCode(Printer& printer) {
    printer.print();
}

int main() {
    // Using the Adapter
    PrinterAdapter adapter;
    clientCode(adapter);

    return 0;
}
```
Java
```
/* Adapter Design Pattern Example Code */

// Target Interface
interface Printer {
    void print();
}

// Adaptee
class LegacyPrinter {
    public void printDocument() {
        System.out.println("Legacy Printer is printing a document.");
    }
}

// Adapter
class PrinterAdapter implements Printer {
    private LegacyPrinter legacyPrinter = new LegacyPrinter();

    @Override
    public void print() {
        legacyPrinter.printDocument();
    }
}

// Client Code
public class Client {
    public static void clientCode(Printer printer) {
        printer.print();
    }

    public static void main(String[] args) {
        // Using the Adapter
        PrinterAdapter adapter = new PrinterAdapter();
        clientCode(adapter);
    }
}
```
Python
```
''' Adapter Design Pattern Example Code '''

# Target Interface
from abc import ABC, abstractmethod

class Printer(ABC):
    @abstractmethod
    def print(self):
        pass

# Adaptee
class LegacyPrinter:
    def print_document(self):
        print('Legacy Printer is printing a document.')

# Adapter
class PrinterAdapter(Printer):
    def __init__(self):
        self.legacy_printer = LegacyPrinter()

    def print(self):
        self.legacy_printer.print_document()

# Client Code
def client_code(printer):
    printer.print()

if __name__ == '__main__':
    # Using the Adapter
    adapter = PrinterAdapter()
    client_code(adapter)
```
JavaScript
```
/* Adapter Design Pattern Example Code */

// Target Interface
const Printer = {
    print: function() {
        throw new Error('print method must be implemented!');
    }
};

// Adaptee
class LegacyPrinter {
    printDocument() {
        console.log('Legacy Printer is printing a document.');
    }
}

// Adapter
class PrinterAdapter {
    constructor() {
        this.legacyPrinter = new LegacyPrinter();
    }

    print() {
        this.legacyPrinter.printDocument();
    }
}

// Client Code
class Client {
    static clientCode(printer) {
        printer.print();
    }

    static main() {
        // Using the Adapter
        const adapter = new PrinterAdapter();
        this.clientCode(adapter);
    }
}

// Running the client code
Client.main();
```
**Output**
```
Legacy Printer is printing a document.
```

## Advantages

The pros of Adapter Design Pattern:

- Promotes code reuse without modification.
- Keeps classes focused on core logic by isolating adaptation.
- Supports multiple interfaces through interchangeable adapters.
- Decouples system from implementations, easing modifications and swaps.

## Disadvantages

The cons of Adapter Design Pattern:

- Adds complexity and can make code harder to follow.
- Introduces slight performance overhead due to extra indirection.
- Multiple adapters increase maintenance effort.
- Handling many interfaces may require multiple adapters, complicating design.

Which principle does Adapter Pattern support?

- A
	Single Responsibility Principle
- B
	Liskov Substitution Principle
- C
	Open/Closed Principle
- D
	Interface Segregation Principle

The main purpose of the Adapter Pattern is to:

- A
	Add behavior dynamically at runtime
- B
	Convert one interface into another compatible interface
- C
	Create multiple object instances efficiently
- D
	Enforce singleton behavior

Which real-world analogy best represents the Adapter Pattern?

- A
	A decorator adding extra toppings to a pizza
- B
	A power plug adapter converting a 2-pin plug to fit a 3-pin socket
- C
	A factory creating multiple product objects
- D
	A proxy controlling access to a resource

What is a limitation of the Adapter Pattern?

- A
	Cannot be used with interfaces
- B
	Only works in Java, not other languages
- C
	Often requires multiple adapters when many interfaces need to be supported
- D
	Breaks encapsulation

When should you NOT use the Adapter Pattern?

- A
	a) When connecting incompatible systems
- B
	When all components are already compatible
- C
	When working with legacy APIs
- D
	When you want to isolate changes in one place

In the Adapter pattern, which component contains the existing incompatible functionality?

What does the Adapter class primarily do?

![[sucess-img 3.png|success]]

Quiz Completed Successfully

Score:0/7

Accuracy:0%