---
title: "Types of Software Design Patterns"
source: "https://www.geeksforgeeks.org/system-design/types-of-design-patterns/"
author:
  - "[[GeeksforGeeks]]"
published: 2023-12-04
created: 2026-09-23
description: "Your All-in-One Learning Portal: GeeksforGeeks is a comprehensive educational platform that empowers learners across domains-spanning computer science and programming, school education, upskilling, commerce, software tools, competitive exams, and more."
tags:
  - "clippings"
---
Design patterns are reusable solutions to common software design problems. They help create clean, scalable, and maintainable code by providing proven design templates.

- Provide a common vocabulary for developers and reduce development time by using well-tested solutions.
- Make large codebases easier to understand, maintain, and refactor.

> ****Example:**** The Observer Pattern is used in event-driven systems where multiple objects need to be notified about changes, such as notification systems or UI event handling.

There are three types of Design Patterns

![[principles_of_arch_linux.webp|principles_of_arch_linux]]

Types

## 1\. Creational Design Pattern

[Creational Design Pattern](https://www.geeksforgeeks.org/system-design/creational-design-pattern/) abstract the instantiation process. They help in making a system independent of how its objects are created, composed and represented.

> ****Example:**** A database connection is created only once and shared across the application. This avoids multiple instances and ensures efficient resource usage.

### Importance

Creational patterns play a key role in making object creation flexible, reusable, and easier to manage.

- Class creational patterns use inheritance for object creation, while object creational patterns delegate creation to other objects for better runtime flexibility.
- Modern systems favor object composition over inheritance, enabling reusable components to be combined into complex behaviors.
- Creational patterns simplify complex object creation by managing construction logic cleanly and consistently.

### Applications

Creational patterns are widely used in scenarios where object creation needs to be controlled, flexible, or standardized.

- Creational patterns help manage complex object creation that involves multiple steps or detailed configuration.
- They promote reusability and modularity by providing a standardized way to create objects across the system.
- By hiding instantiation details, they reduce coupling between client code and concrete classes.
- Specific needs are addressed by patterns like Singleton (single instance control) and Builder (step-by-step construction of complex objects).

### Advantages

Using creational patterns provides several benefits in terms of flexibility, maintainability, and design quality.

- ****Flexibility and Adaptability****: Creational patterns make it easy to change or add new object types without touching existing code.
- ****Centralized Control:**** These patterns control object creation from a single place.
- ****Scalability****: Creational patterns support system growth without breaking existing code.
- ****Promotion of Good Design Practices****: Creational patterns encourage clean and well-structured design.

### Disadvantages

There are some trade-offs when using creational patterns, particularly in terms of complexity and readability.

- ****Increased Complexity:**** Introducing creational patterns can add complexity, especially with many classes, interfaces, and relationships.
- ****Overhead:**** Patterns like Abstract Factory or Prototype may introduce overhead due to extra classes and interfaces.
- ****Dependency on Patterns:**** Over-reliance can make the codebase dependent on a specific pattern, making adaptation or switching harder.
- ****Readability and Understanding:**** Some creational patterns may make code harder to read and understand for developers unfamiliar with them.

## 2\. Structural Design Patterns

[Structural patterns](https://www.geeksforgeeks.org/system-design/structural-design-patterns/) are concerned with how classes and objects are composed to form larger structures. Structural class patterns use inheritance to compose interfaces or implementations.

> ****Example:**** A mobile charger adapter allows different plug types to work together. It converts one interface into another so incompatible devices can connect.

### Importance

Structural patterns help organize and compose objects effectively, making it easier to integrate and extend systems.

- This pattern is particularly useful for making independently developed class libraries work together.
- Structural object patterns describe ways to compose objects to realize new functionality.
- It added flexibility of object composition comes from the ability to change the composition at runtime, which is impossible with static class composition.

### Applications

Structural patterns are applied to improve object composition, simplify integration, and manage complex systems.

- Use the Adapter pattern to connect existing classes without changing their code, ideal for legacy systems or third-party libraries.
- The Decorator pattern adds new functionality by composing objects, providing flexibility without subclassing.
- The Facade pattern simplifies complex subsystems by offering a unified and easy-to-use interface.
- The Proxy pattern manages object access, creation timing, or lifecycle control efficiently.

### Advantages

Structural patterns provide benefits in flexibility, reusability, and maintainability of code.

- ****Code Reusability:**** These patterns provide a standardized way to compose objects, so components can be reused in different contexts and reduce redundancy.
- ****Improved Scalability:**** Structural patterns organize relationships between classes and objects, supporting system growth without increasing complexity.
- ****Simplified Integration:**** Patterns like Adapter make it easier to integrate existing or third-party components by providing a standard interface.
- ****Easier Maintenance:**** Modular and encapsulated designs reduce the impact of changes, lowering the risk of unintended consequences.

### Disadvantages

Structural patterns also introduce some trade-offs in terms of complexity, overhead, and applicability.

- ****Complexity:**** Using structural patterns can increase code complexity, especially when multiple patterns or many classes and interfaces are involved.
- ****Overhead:**** Patterns like Composite may add extra layers, creating additional overhead to manage object hierarchies.
- ****Maintenance Challenges:**** Modifying class structures or relationships can be harder when structural patterns are heavily used, requiring updates across multiple components.
- ****Limited Applicability:**** Not every structural pattern fits every situation; using the wrong pattern may add unnecessary complexity.

## 3\. Behavioral Design Pattern

[Behavioral patterns](https://www.geeksforgeeks.org/system-design/behavioral-design-patterns/) are concerned with algorithms and the assignment of responsibilities between objects. Behavioral patterns describe not just patterns of objects or classes but also the patterns of communication between them.

> ****Example****: In social media apps, followers get notified when a user posts content. This enables one-to-many communication between objects.

### Importance

Behavioral patterns help manage complex object interactions and control flow, making systems easier to understand and maintain.

- These patterns characterize complex control flow that's difficult to follow at runtime.
- They shift focus away from flow of control to let you concentrate just on the way objects are interconnected.
- Behavioral class patterns use inheritance to distribute behavior between classes.

### Applications

Behavioral patterns are applied to improve object collaboration, flexibility, and dynamic behavior in a system.

- Allows objects to communicate and collaborate in a flexible, reusable way, improving overall system interaction.
- Encapsulates algorithms, strategies, or behaviors, enabling reuse and independent modification without affecting other parts of the code.
- Supports dynamic changes in an object's behavior at runtime, providing flexibility without altering its core implementation.
- Manages state-dependent behavior, letting objects change actions based on internal state while keeping interactions clear and modular.

### Advantages

Behavioral patterns enhance flexibility, modularity, and maintainability in software systems.

- ****Flexibility and Adaptability:**** Behavioral patterns allow objects to interact dynamically, making it easier to modify or extend system behavior without changing existing code.
- ****Separation of Concerns:**** Responsibilities are divided among classes, improving modularity and making the code easier to understand.
- ****Encapsulation of Algorithms:**** Behaviors are isolated in standalone objects, allowing modification or extension without affecting client code.
- ****Ease of Maintenance:**** Clear roles and responsibilities help localize changes, reducing the impact on the rest of the system.

### Disadvantages

Behavioral patterns also have trade-offs in terms of complexity, applicability, and scalability.

- ****Increased Complexity:**** Using behavioral patterns can make the codebase more complex, especially when multiple patterns are applied together.
- ****Over-Engineering:**** Applying patterns where simpler solutions would work may lead to unnecessary complexity.
- ****Limited Applicability:**** Not all behavioral patterns fit every situation; using the wrong pattern can add needless complications.
- ****Code Readability:**** Some patterns may reduce readability, making it harder for developers unfamiliar with them to understand the code.
- ****Scalability Concerns:**** Certain patterns, like Observer, may face efficiency issues as the number of objects or interactions grows.

What is the primary purpose of Creational Design Patterns?

- A
	To define object communication behavior
- B
	To simplify user interfaces
- C
	To abstract and control object creation
- D
	To improve runtime algorithm performance

Which of the following is an example of a Structural Design Pattern?

- A
	Strategy
- B
	Observer
- C
	Builder
- D
	Adapter

Structural patterns mainly focus on:

- A
	Managing object lifecycles
- B
	Organizing and composing classes and objects
- C
	Implementing complex algorithms
- D
	Handling object state transitions

Which statement best describes Behavioral Design Patterns?

Which of the following is an advantage of Creational Patterns?

What is a potential disadvantage of Behavioral Design Patterns?

![[sucess-img 95.png|success]]

Quiz Completed Successfully

Score:0/6

Accuracy:0%