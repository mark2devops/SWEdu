---
title: "Denormalization in Databases"
source: "https://www.geeksforgeeks.org/dbms/denormalization-in-databases/"
author:
  - "[[GeeksforGeeks]]"
published: 2018-02-18
created: 2026-09-23
description: "Your All-in-One Learning Portal: GeeksforGeeks is a comprehensive educational platform that empowers learners across domains-spanning computer science and programming, school education, upskilling, commerce, software tools, competitive exams, and more."
tags:
  - "clippings"
---
Denormalization is a database optimization technique where redundant data is intentionally added to one or more tables to reduce the need for complex joins and improve query performance. It is not the opposite of normalization, but rather an optimization applied after normalization.

- In a normalized database, data is stored in separate tables to minimize redundancy.
- for example, storing teacher details in a Teachers table and course details in a Courses table, linked by teacherID.
- While this maintains data integrity, frequent joins between large tables can slow performance.
![[denormalization.webp|denormalization]]

Denormalization

> ****Note:**** Denormalization strikes a balance by allowing some redundancy to achieve faster data retrieval and better performance, at the cost of slightly more maintenance effort when updating data.

## Step 1: Unnormalized Table

This is the starting point where all the data is stored in a single table.

![[Unnormalize-Structure.webp|Unnormalize-Structure]]

Unnormalized Structure

- ****Redundancy:**** For example, "Alice" and "Math" are repeated multiple times. Similarly, "Mr. Smith" is stored twice for the same class.
- ****Update Anomalies:**** If "Mr. Smith" changes to "Mr. Brown," we have to update multiple rows. Missing one row could lead to inconsistencies.
- ****Inefficient Storage:**** Repeated information takes up unnecessary space.

## Step 2: Normalized Structure

To eliminate redundancy and avoid anomalies, we split the data into smaller, related tables. This process is called normalization. Each table now focuses on a specific aspect, such as students, classes or subjects.

![[Normalize-Structure.webp|Normalize-Structure]]

Normalized Structure

- ****No Redundancy:**** "Mr. Smith" appears only once in the Classes Table, even if multiple subjects are associated with the class.
- ****Easier Updates:**** If "Mr. Smith" changes to "Mr. Brown," you only update the Classes Table and it automatically reflects everywhere.
- ****Efficient Storage:**** Repeated data is eliminated, saving space.

## Step 3: Denormalized Table

In some cases, normalization can make querying complex and slow because you need to join multiple tables to get the required information. To optimize performance, we can denormalize the data by combining related tables into a single table.

- All related information (student name, class name, teacher and subject) is stored in a single table.
- This simplifies querying because you don’t need to join multiple tables.
![[Denormalize-Structure.webp|Denormalize-Structure]]

Denormalized Structure

## Denormalization v/s Normalization

[Normalization](https://www.geeksforgeeks.org/dbms/introduction-of-database-normalization/) and Denormalization both are the method which use in database but it works opposite to each other. One side normalization is used for reduce or removing the redundancy which means there will be no duplicate data or entries in the same table and also optimizes for data integrity and efficient storage

Denormalization is used for add the redundancy into normalized table so that enhance the functionality and minimize the running time of database queries (like joins operation ) and optimizes for performance and query simplicity. In a system that demands scalability, like that of any major tech company, we almost always use elements of both normalized and denormalized databases.

## Advantages

This section highlights the benefits of denormalization in improving performance and simplifying data access.

- ****Improved Query Performance:**** Denormalization can improve query performance by reducing the number of joins required to retrieve data.
- ****Reduced Complexity****: By combining related data into fewer tables, denormalization can simplify the database schema and make it easier to manage.
- ****Easier Maintenance and Updates:**** Denormalization can make it easier to update and maintain the database by reducing the number of tables.
- ****Improved Read Performance:**** Denormalization can improve read performance by making it easier to access data.
- ****Better Scalability:**** Denormalization can improve the scalability of a database system by reducing the number of tables and improving the overall performance.

## Disadvantages

This section outlines the limitations of denormalization, particularly related to data redundancy and maintenance challenges.

- ****Reduced Data Integrity:**** By adding redundant data, denormalization can reduce data integrity and increase the risk of inconsistencies.
- ****Increased Complexity:**** While denormalization can simplify the [database schema](https://www.geeksforgeeks.org/dbms/database-schemas/) in some cases, it can also increase complexity by introducing redundant data.
- ****Increased Storage Requirements:**** By adding redundant data, denormalization can increase storage requirements and increase the cost of maintaining the [database](https://www.geeksforgeeks.org/dbms/what-is-database/).
- ****Increased Update and Maintenance Complexity:**** Denormalization can increase the complexity of updating and maintaining the database by introducing redundant data.
- ****Limited Flexibility:**** Denormalization can reduce the flexibility of a database system by introducing redundant data and making it harder to modify the schema.

Which of the following is the primary objective of performing Denormalization in a database?

****(GATE 2021 | MCQ | 1-Mark)****

- A
	To eliminate all redundant data and functional dependencies
- B
	To improve the performance of read-intensive queries by reducing the number of joins
- C
	To ensure the database strictly adheres to the Domain-Key Normal Form (DKNF)
- D
	To increase the speed of INSERT and UPDATE operations by simplifying the table structure

In which of the following scenarios is Denormalization most likely to be preferred over high levels of Normalization?

****(GATE 2021 | MCQ | 1-Mark)****

- A
	A banking system where data consistency and atomicity of transactions are the highest priority
- B
	A real-time inventory system where stock levels are updated thousands of times per second
- C
	A reporting dashboard for an e-commerce site that aggregates millions of historical sales records
- D
	A metadata repository that requires strict adherence to 5NF to prevent join dependencies

Which of the following operations is commonly reduced through denormalization?

- A
	Projection
- B
	Selection
- C
	Join
- D
	Aggregation

Which of the following best differentiates normalization and denormalization?

- A
	Normalization increases query speed; denormalization decreases it
- B
	Normalization removes redundant data; denormalization adds it for performance
- C
	Normalization is used only in NoSQL databases
- D
	Denormalization ensures referential integrity

In which scenario is denormalization most beneficial?

![[sucess-img 20.png|success]]

Quiz Completed Successfully

Score:0/5

Accuracy:0%