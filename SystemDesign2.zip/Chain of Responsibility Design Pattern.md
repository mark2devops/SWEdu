---
title: "Chain of Responsibility Design Pattern"
source: "https://www.geeksforgeeks.org/system-design/chain-responsibility-design-pattern/"
author:
  - "[[GeeksforGeeks]]"
published: 2017-07-28
created: 2026-09-23
description: "Your All-in-One Learning Portal: GeeksforGeeks is a comprehensive educational platform that empowers learners across domains-spanning computer science and programming, school education, upskilling, commerce, software tools, competitive exams, and more."
tags:
  - "clippings"
---
The Chain of Responsibility design pattern is a [behavioral design pattern](https://www.geeksforgeeks.org/system-design/behavioral-design-patterns/) that allows an object to pass a request along a chain of handlers. Each handler in the chain decides either to process the request or to pass it along the chain to the next handler.

- This pattern is frequently used in the chain of multiple objects, where each object either handles the request or passes it on to the next object in the chain if it is unable to handle that request.
- This pattern encourages loose coupling between sender and receiver, providing freedom in handling the request.

> ****Example:**** In a customer support system, requests are handled step-by-step through a chain of support levels—starting with a Bot for simple issues, then a Junior Executive, and finally a Senior Engineer for complex problems if needed.

![[handler 1.webp|handler]]

Chain of Responsibility

In the Diagram

- A Client sends a request to Handler 1, which is the first point in the processing chain.
- If Handler 1 cannot fully handle the request, it forwards it to Handler 2, and then to Handler 3 if needed.
- Each handler decides independently whether to process the request or pass it forward, forming a chain of responsibility.

## Real-World Analogy

> Imagine a customer service department with multiple levels of support staff, each responsible for handling different types of customer inquiries based on their complexity. The chain of responsibility can be illustrated as follows:

- ****Level 1 Support****: This represents the first point of contact for customer inquiries. Level 1 support staff handle basic inquiries and provide general assistance. If they cannot resolve the issue, they escalate it to Level 2 support.
- ****Level 2 Support****: This level consists of more experienced support staff who can handle more complex issues that Level 1 support cannot resolve. If Level 2 support cannot resolve the issue, they escalate it to Level 3 support.
- ****Level 3 Support****: This is the highest level of support, consisting of senior or specialized staff who can handle critical or highly technical issues. If Level 3 support cannot resolve the issue, they may involve other departments or experts within the organization.
![[either_handle_or_passes_to_the_level_2_support.webp|either_handle_or_passes_to_the_level_2_support]]

## Real life Applications

The real life example of chain of responsibility design pattern are:

- In graphical user interfaces (GUIs), events like mouse clicks or key presses can be handled by a chain of listeners. Each listener checks if it can handle the event, passing it along the chain if it can't. This way, multiple components can respond to the same event without being tightly linked.
- In logging systems, you might have different levels of loggers (like INFO, WARN, ERROR). Each logger can handle specific log messages. If one logger can’t process a message (for example, if it's below its level), it passes it to the next logger in the chain.
- In security systems, access requests can be processed by a series of handlers that check permissions. For instance, one handler might check user roles, while another checks specific permissions. If one handler denies access, it can pass the request to the next handler for further evaluation.

## Components

The Chain of Responsibility Pattern consists of the following key components:

- ****Handler Interface or Abstract Class****: This is the base class that defines the interface for handling requests and, in many cases, for chaining to the next handler in the sequence.
- ****Concrete Handlers:**** These are the classes that implement how the requests are going to be handled. They can handle the request or pass it to the next handler in the chain if it is unable to handle that request.
- ****Client****: The request is sent by the client, who then forwards it to the chain’s first handler. Which handler will finally handle the request is unknown to the client.

## Working

This pattern works by passing a request along a chain of handlers until one of them handles the request.

- A request is sent by the client without knowing which handler will process it.
- The request is passed from one handler to the next in the chain.
- Each handler checks whether it can handle the request.
- If it can, it processes the request; otherwise, it forwards it to the next handler.

## Uses

This pattern is used when multiple objects may handle a request and the handler is not known in advance.

- Handling requests in multiple levels (e.g., approval systems).
- Implementing logging frameworks with different log levels.
- Designing event handling systems in GUI applications.
- Managing authentication and authorization chains.

## Implementation Example

Problem Statement

> In a customer support system, requests are processed based on priority through three levels of support. Level 1 handles basic issues, Level 2 manages more complex problems, and Level 3 deals with critical issues that cannot be resolved by the lower levels.

### Benefit of Using the Chain of Responsibility in this scenario

The Chain of Responsibility pattern fits this situation by creating a sequence of handlers where each one either processes the request or passes it to the next. It improves flexibility and scalability by allowing handlers to be added or removed without changing the client code.

![[class_diagram_of_chain_of_responsibility_design_pattern-1.webp|class_diagram_of_chain_of_responsibility_design_pattern-1]]

Class Diagram

Let’s break down into the component wise code:

### 1\. Handler Interface

Defines the interface for handling requests. Includes methods for handling requests (handleRequest()) and setting the next handler in the chain (setNextHandler()).
C++
```
class SupportHandler {
public:
    virtual void handleRequest(Request request) = 0;
    virtual void setNextHandler(SupportHandler* nextHandler) = 0;
};
```
Java
```
public interface SupportHandler {
    void handleRequest(Request request);
    void setNextHandler(SupportHandler nextHandler);
}
```
Python
```
from abc import ABC, abstractmethod

class SupportHandler(ABC):
    @abstractmethod
    def handleRequest(self, request):
        pass

    @abstractmethod
    def setNextHandler(self, nextHandler):
        pass
```
JavaScript
```
class SupportHandler {
    handleRequest(request) {}
    setNextHandler(nextHandler) {}
}
```
### 2\. Concrete Handlers

Implement the SupportHandler interface. Each handler is responsible for handling requests based on its assigned priority level. If a handler can handle the request, it processes it; otherwise, it passes the request to the next handler in the chain.
C++
```
#include <iostream>
#include <string>
using namespace std;

enum Priority { BASIC, INTERMEDIATE, CRITICAL };

class Request {
public:
    Priority getPriority() { return priority; }
    void setPriority(Priority p) { priority = p; }
private:
    Priority priority;
};

class SupportHandler {
public:
    virtual void setNextHandler(SupportHandler* nextHandler) {}
    virtual void handleRequest(Request request) = 0;
};

class Level1SupportHandler : public SupportHandler {
private:
    SupportHandler* nextHandler;
public:
    void setNextHandler(SupportHandler* nextHandler) override {
        this->nextHandler = nextHandler;
    }
    void handleRequest(Request request) override {
        if (request.getPriority() == BASIC) {
            cout << "Level 1 Support handled the request." << endl;
        } else if (nextHandler!= nullptr) {
            nextHandler->handleRequest(request);
        }
    }
};

class Level2SupportHandler : public SupportHandler {
private:
    SupportHandler* nextHandler;
public:
    void setNextHandler(SupportHandler* nextHandler) override {
        this->nextHandler = nextHandler;
    }
    void handleRequest(Request request) override {
        if (request.getPriority() == INTERMEDIATE) {
            cout << "Level 2 Support handled the request." << endl;
        } else if (nextHandler!= nullptr) {
            nextHandler->handleRequest(request);
        }
    }
};

class Level3SupportHandler : public SupportHandler {
public:
    void handleRequest(Request request) override {
        if (request.getPriority() == CRITICAL) {
            cout << "Level 3 Support handled the request." << endl;
        } else {
            cout << "Request cannot be handled." << endl;
        }
    }
    void setNextHandler(SupportHandler* nextHandler) override {
        // No next handler for Level 3
    }
};
```
Java
```
public class Level1SupportHandler implements SupportHandler {
    private SupportHandler nextHandler;

    public void setNextHandler(SupportHandler nextHandler) {
        this.nextHandler = nextHandler;
    }

    public void handleRequest(Request request) {
        if (request.getPriority() == Priority.BASIC) {
            System.out.println("Level 1 Support handled the request.");
        } else if (nextHandler != null) {
            nextHandler.handleRequest(request);
        }
    }
}

public class Level2SupportHandler implements SupportHandler {
    private SupportHandler nextHandler;

    public void setNextHandler(SupportHandler nextHandler) {
        this.nextHandler = nextHandler;
    }

    public void handleRequest(Request request) {
        if (request.getPriority() == Priority.INTERMEDIATE) {
            System.out.println("Level 2 Support handled the request.");
        } else if (nextHandler != null) {
            nextHandler.handleRequest(request);
        }
    }
}

public class Level3SupportHandler implements SupportHandler {
    public void handleRequest(Request request) {
        if (request.getPriority() == Priority.CRITICAL) {
            System.out.println("Level 3 Support handled the request.");
        } else {
            System.out.println("Request cannot be handled.");
        }
    }

    public void setNextHandler(SupportHandler nextHandler) {
        // No next handler for Level 3
    }
}
```
Python
```
from enum import Enum


class Priority(Enum):
    BASIC = 1
    INTERMEDIATE = 2
    CRITICAL = 3


class Request:
    def __init__(self, priority):
        self.priority = priority


class SupportHandler:
    def set_next_handler(self, next_handler):
        pass

    def handle_request(self, request):
        pass


class Level1SupportHandler(SupportHandler):
    def __init__(self):
        self.next_handler = None

    def set_next_handler(self, next_handler):
        self.next_handler = next_handler

    def handle_request(self, request):
        if request.priority == Priority.BASIC:
            print("Level 1 Support handled the request.")
        elif self.next_handler is not None:
            self.next_handler.handle_request(request)


class Level2SupportHandler(SupportHandler):
    def __init__(self):
        self.next_handler = None

    def set_next_handler(self, next_handler):
        self.next_handler = next_handler

    def handle_request(self, request):
        if request.priority == Priority.INTERMEDIATE:
            print("Level 2 Support handled the request.")
        elif self.next_handler is not None:
            self.next_handler.handle_request(request)


class Level3SupportHandler(SupportHandler):
    def handle_request(self, request):
        if request.priority == Priority.CRITICAL:
            print("Level 3 Support handled the request.")
        else:
            print("Request cannot be handled.")

    def set_next_handler(self, next_handler):
        # No next handler for Level 3
        pass
```
JavaScript
```
var Priority;
(function (Priority) {
    Priority[Priority["BASIC"] = 0] = "BASIC";
    Priority[Priority["INTERMEDIATE"] = 1] = "INTERMEDIATE";
    Priority[Priority["CRITICAL"] = 2] = "CRITICAL";
})(Priority || (Priority = {}));
var Request = /** @class */ (function () {
    function Request(priority) {
        this.priority = priority;
    }
    return Request;
}());
var SupportHandler = /** @class */ (function () {
    function SupportHandler() {
    }
    SupportHandler.prototype.setNextHandler = function (nextHandler) {
    };
    SupportHandler.prototype.handleRequest = function (request) {
    };
    return SupportHandler;
}());
var Level1SupportHandler = /** @class */ (function (_super) {
    __extends(Level1SupportHandler, _super);
    function Level1SupportHandler() {
        var _this = _super!== null && _super.apply(this, arguments) || this;
        _this.nextHandler = null;
        return _this;
    }
    Level1SupportHandler.prototype.setNextHandler = function (nextHandler) {
        this.nextHandler = nextHandler;
    };
    Level1SupportHandler.prototype.handleRequest = function (request) {
        if (request.priority === Priority.BASIC) {
            console.log('Level 1 Support handled the request.');
        }
        else if (this.nextHandler!== null) {
            this.nextHandler.handleRequest(request);
        }
    };
    return Level1SupportHandler;
}(SupportHandler));
var Level2SupportHandler = /** @class */ (function (_super) {
    __extends(Level2SupportHandler, _super);
    function Level2SupportHandler() {
        var _this = _super!== null && _super.apply(this, arguments) || this;
        _this.nextHandler = null;
        return _this;
    }
    Level2SupportHandler.prototype.setNextHandler = function (nextHandler) {
        this.nextHandler = nextHandler;
    };
    Level2SupportHandler.prototype.handleRequest = function (request) {
        if (request.priority === Priority.INTERMEDIATE) {
            console.log('Level 2 Support handled the request.');
        }
        else if (this.nextHandler!== null) {
            this.nextHandler.handleRequest(request);
        }
    };
    return Level2SupportHandler;
}(SupportHandler));
var Level3SupportHandler = /** @class */ (function (_super) {
    __extends(Level3SupportHandler, _super);
    function Level3SupportHandler() {
        return _super!== null && _super.apply(this, arguments) || this;
    }
    Level3SupportHandler.prototype.handleRequest = function (request) {
        if (request.priority === Priority.CRITICAL) {
            console.log('Level 3 Support handled the request.');
        }
        else {
            console.log('Request cannot be handled.');
        }
    };
    Level3SupportHandler.prototype.setNextHandler = function (nextHandler) {
        // No next handler for Level 3
    }
    return Level3SupportHandler;
}(SupportHandler));
```
### Complete code for the above example
C++
```
#include <iostream>
#include <string>
using namespace std;

// Handler Interface
class SupportHandler {
public:
    virtual void handleRequest(string request) = 0;
    virtual void setNextHandler(SupportHandler* nextHandler) = 0;
};

// Concrete Handlers
class Level1SupportHandler : public SupportHandler {
private:
    SupportHandler* nextHandler;
public:
    void setNextHandler(SupportHandler* nextHandler) override {
        this->nextHandler = nextHandler;
    }
    void handleRequest(string request) override {
        if (request == "BASIC") {
            cout << "Level 1 Support handled the request." << endl;
        } else if (nextHandler!= nullptr) {
            nextHandler->handleRequest(request);
        }
    }
};

class Level2SupportHandler : public SupportHandler {
private:
    SupportHandler* nextHandler;
public:
    void setNextHandler(SupportHandler* nextHandler) override {
        this->nextHandler = nextHandler;
    }
    void handleRequest(string request) override {
        if (request == "INTERMEDIATE") {
            cout << "Level 2 Support handled the request." << endl;
        } else if (nextHandler!= nullptr) {
            nextHandler->handleRequest(request);
        }
    }
};

class Level3SupportHandler : public SupportHandler {
public:
    void handleRequest(string request) override {
        if (request == "CRITICAL") {
            cout << "Level 3 Support handled the request." << endl;
        } else {
            cout << "Request cannot be handled." << endl;
        }
    }
    void setNextHandler(SupportHandler* nextHandler) override {
        // No next handler for Level 3
    }
};

// Main Function
int main() {
    SupportHandler* level1Handler = new Level1SupportHandler();
    SupportHandler* level2Handler = new Level2SupportHandler();
    SupportHandler* level3Handler = new Level3SupportHandler();

    level1Handler->setNextHandler(level2Handler);
    level2Handler->setNextHandler(level3Handler);

    level1Handler->handleRequest("BASIC");
    level1Handler->handleRequest("INTERMEDIATE");
    level1Handler->handleRequest("CRITICAL");

    delete level1Handler;
    delete level2Handler;
    delete level3Handler;
    return 0;
}
```
Java
```
// Handler Interface
interface SupportHandler {
    void handleRequest(Request request);
    void setNextHandler(SupportHandler nextHandler);
}

// Concrete Handlers
class Level1SupportHandler implements SupportHandler {
    private SupportHandler nextHandler;

    public void setNextHandler(SupportHandler nextHandler) {
        this.nextHandler = nextHandler;
    }

    public void handleRequest(Request request) {
        if (request.getPriority() == Priority.BASIC) {
            System.out.println("Level 1 Support handled the request.");
        } else if (nextHandler != null) {
            nextHandler.handleRequest(request);
        }
    }
}

class Level2SupportHandler implements SupportHandler {
    private SupportHandler nextHandler;

    public void setNextHandler(SupportHandler nextHandler) {
        this.nextHandler = nextHandler;
    }

    public void handleRequest(Request request) {
        if (request.getPriority() == Priority.INTERMEDIATE) {
            System.out.println("Level 2 Support handled the request.");
        } else if (nextHandler != null) {
            nextHandler.handleRequest(request);
        }
    }
}

class Level3SupportHandler implements SupportHandler {
    public void handleRequest(Request request) {
        if (request.getPriority() == Priority.CRITICAL) {
            System.out.println("Level 3 Support handled the request.");
        } else {
            System.out.println("Request cannot be handled.");
        }
    }

    public void setNextHandler(SupportHandler nextHandler) {
        // No next handler for Level 3
    }
}

// Request Class
class Request {
    private Priority priority;

    public Request(Priority priority) {
        this.priority = priority;
    }

    public Priority getPriority() {
        return priority;
    }
}

// Priority Enum
enum Priority {
    BASIC, INTERMEDIATE, CRITICAL
}

// Main Class
public class Main {
    public static void main(String[] args) {
        SupportHandler level1Handler = new Level1SupportHandler();
        SupportHandler level2Handler = new Level2SupportHandler();
        SupportHandler level3Handler = new Level3SupportHandler();

        level1Handler.setNextHandler(level2Handler);
        level2Handler.setNextHandler(level3Handler);

        Request request1 = new Request(Priority.BASIC);
        Request request2 = new Request(Priority.INTERMEDIATE);
        Request request3 = new Request(Priority.CRITICAL);

        level1Handler.handleRequest(request1);
        level1Handler.handleRequest(request2);
        level1Handler.handleRequest(request3);
    }
}
```
Python
```
# Handler Interface
from abc import ABC, abstractmethod

class SupportHandler(ABC):
    @abstractmethod
    def handleRequest(self, request):
        pass

    @abstractmethod
    def setNextHandler(self, nextHandler):
        pass

# Concrete Handlers
class Level1SupportHandler(SupportHandler):
    def __init__(self):
        self.nextHandler = None

    def setNextHandler(self, nextHandler):
        self.nextHandler = nextHandler

    def handleRequest(self, request):
        if request == "BASIC":
            print("Level 1 Support handled the request.")
        elif self.nextHandler is not None:
            self.nextHandler.handleRequest(request)

class Level2SupportHandler(SupportHandler):
    def __init__(self):
        self.nextHandler = None

    def setNextHandler(self, nextHandler):
        self.nextHandler = nextHandler

    def handleRequest(self, request):
        if request == "INTERMEDIATE":
            print("Level 2 Support handled the request.")
        elif self.nextHandler is not None:
            self.nextHandler.handleRequest(request)

class Level3SupportHandler(SupportHandler):
    def handleRequest(self, request):
        if request == "CRITICAL":
            print("Level 3 Support handled the request.")
        else:
            print("Request cannot be handled.")

    def setNextHandler(self, nextHandler):
        pass  # No next handler for Level 3

# Main
if __name__ == "__main__":
    level1Handler = Level1SupportHandler()
    level2Handler = Level2SupportHandler()
    level3Handler = Level3SupportHandler()

    level1Handler.setNextHandler(level2Handler)
    level2Handler.setNextHandler(level3Handler)

    level1Handler.handleRequest("BASIC")
    level1Handler.handleRequest("INTERMEDIATE")
    level1Handler.handleRequest("CRITICAL")
```
JavaScript
```
// Handler Interface
class SupportHandler {
    handleRequest(request) {}
    setNextHandler(nextHandler) {}
}

// Concrete Handlers
class Level1SupportHandler extends SupportHandler {
    constructor() {
        super();
        this.nextHandler = null;
    }

    setNextHandler(nextHandler) {
        this.nextHandler = nextHandler;
    }

    handleRequest(request) {
        if (request === "BASIC") {
            console.log("Level 1 Support handled the request.");
        } else if (this.nextHandler!== null) {
            this.nextHandler.handleRequest(request);
        }
    }
}

class Level2SupportHandler extends SupportHandler {
    constructor() {
        super();
        this.nextHandler = null;
    }

    setNextHandler(nextHandler) {
        this.nextHandler = nextHandler;
    }

    handleRequest(request) {
        if (request === "INTERMEDIATE") {
            console.log("Level 2 Support handled the request.");
        } else if (this.nextHandler!== null) {
            this.nextHandler.handleRequest(request);
        }
    }
}

class Level3SupportHandler extends SupportHandler {
    handleRequest(request) {
        if (request === "CRITICAL") {
            console.log("Level 3 Support handled the request.");
        } else {
            console.log("Request cannot be handled.");
        }
    }

    setNextHandler(nextHandler) {
        // No next handler for Level 3
    }
}

// Main
const level1Handler = new Level1SupportHandler();
const level2Handler = new Level2SupportHandler();
const level3Handler = new Level3SupportHandler();

level1Handler.setNextHandler(level2Handler);
level2Handler.setNextHandler(level3Handler);

level1Handler.handleRequest("BASIC");
level1Handler.handleRequest("INTERMEDIATE");
level1Handler.handleRequest("CRITICAL");
```
**Output**
```
Level 1 Support handled the request.
Level 2 Support handled the request.
Level 3 Support handled the request.
```

## Advantages

The pros of chain of responsibility design pattern are

- The pattern makes enables sending a request to a series of possible recipients without having to worry about which object will handle it in the end. This lessens the reliance between items.
- New handlers can be easily added or existing ones can be modified without affecting the client code. This promotes flexibility and extensibility within the system.
- The sequence and order of handling requests can be changed dynamically during runtime, which allows adjustment of the processing logic as per the requirements.
- It simplifies the interaction between the sender and receiver objects, as the sender does not need to know about the processing logic.

## Disadvantages

The cons of chain of responsibility design pattern are

- The chain should be implemented correctly otherwise there is a chance that some requests might not get handled at all, which leads to unexpected behavior in the application.
- The request will go through several handlers in the chain if it is lengthy and complicated, which could cause performance overhead. The processing logic of each handler has an effect on the system’s overall performance.
- The fact that the chain has several handlers can make debugging more difficult. Tracking the progression of a request and determining which handler is in charge of handling it can be difficult.
- It may become more difficult to manage and maintain the chain of responsibility if the chain is dynamically modified at runtime.

What is the main purpose of the Chain of Responsibility pattern?

- A
	To encapsulate algorithms
- B
	To pass a request through a chain of handlers
- C
	To create objects dynamically
- D
	To store previous states

What does each handler do when it receives a request?

- A
	Immediately rejects it
- B
	Processes it and stops
- C
	Checks if it can handle it or forwards it
- D
	Stores it permanently

In the customer support example, which level handles CRITICAL requests?

- A
	Level 1 Support
- B
	Level 2 Support
- C
	Level 3 Support
- D
	Client

Which of the following is a common real-life use of this pattern?

What is one major advantage of the Chain of Responsibility pattern?

What is a potential disadvantage of this pattern?

- A
	Prevents runtime modification
- B
	Requests may remain unhandled if the chain is incorrect
- C
	Cannot support multiple handlers
- D
	Increases tight coupling

![[sucess-img 10.png|success]]

Quiz Completed Successfully

Score:0/6

Accuracy:0%