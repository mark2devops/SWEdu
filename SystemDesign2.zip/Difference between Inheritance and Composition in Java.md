---
title: "Difference between Inheritance and Composition in Java"
source: "https://www.geeksforgeeks.org/java/difference-between-inheritance-and-composition-in-java/"
author:
  - "[[GeeksforGeeks]]"
published: 2020-01-22
created: 2026-09-23
description: "Your All-in-One Learning Portal: GeeksforGeeks is a comprehensive educational platform that empowers learners across domains-spanning computer science and programming, school education, upskilling, commerce, software tools, competitive exams, and more."
tags:
  - "clippings"
---
When we want to create a new class and there is already a class that includes some of the code that we want, we can derive our new class from the existing class. In doing this, we can reuse the fields and methods of the existing class without having to write them ourself.

A subclass inherits all the members (fields, methods, and nested classes) from its superclass. Constructors are not members, so they are not inherited by subclasses, but the constructor of the superclass can be invoked from the subclass.

Types of [****Inheritance****](https://www.geeksforgeeks.org/cpp/inheritance-in-c/) are:

1. Single inheritance
2. Multi-level inheritance
3. Multiple inheritances
4. Hybrid inheritance
5. Hierarchical inheritance

****Example of Inheritance:****
```
// Java Program Demonstrating
// Inheritance

class A {
    int a, b;
  
    public void add(int x, int y){
        a = x;
        b = y;
        System.out.println("addition of a + b is:"
            + (a + b));
    }
}

// Class B Inheriting Class A
class B extends A 
{  
    public void sum(int x, int y){
        add(x, y);
    }

    public static void main(String[] args){
        B b1 = new B();
        b1.sum(5, 6);
    }
}
```
****Output:****

```
addition of a+b is:11
```

Here, class B is the derived class which inherit the property(****add method****) of the base class A.

### Composition

The [****Composition****](https://www.geeksforgeeks.org/java/association-composition-aggregation-java/) also provides code reusability but the difference here is we do not extend the class for this.

****Example of Composition:**** Let us take an example ofthe ****Library****.
```
// Java program to illustrate
// the concept of Composition
import java.util.*;

// class book
class Book {

    public String title;
    public String author;

    Book(String t, String a)
    {
        this.title = t;
        this.author = a;
    }
}

// Library class contains
// list of books.
class Library {

    // reference to refer to the list of books.
    private final List<Book> books;

    Library(){
      	books = new ArrayList<>();
    }
  
  	public void add(Book b){
      	books.add(b);
    }

    public List<Book> getTotalBooksInLibrary(){
        return books;
    }
}

class Main
{
    public static void main(String[] args)
    {

        // Creating the Objects of Book class.
        Book b1 = new Book("EffectiveJ Java","Joshua Bloch");
        Book b2 = new Book("Thinking in Java","Bruce Eckel");
        Book b3 = new Book("Java: The Complete Reference","Herbert Schildt");

        // Creating the list which contains the
        // no. of books.
        Library library = new Library();      
        
      	library.add(b1);
        library.add(b2);
        library.add(b3);

        List<Book> bks = library.getTotalBooksInLibrary();
      
        for (Book bk : bks) {
            System.out.println("Title : " + bk.title + " and "
                               + " Author : " + bk.author);
        }
    }
}
```
****Output:****

```
Title : EffectiveJ Java and  Author : Joshua Bloch
Title : Thinking in Java and  Author : Bruce Eckel
Title : Java: The Complete Reference and  Author : Herbert Schildt
```

### Difference between Inheritance and Composition

| Inheritance | Composition |
| --- | --- |
| In inheritance, we define the class which we are inheriting(super class) and most importantly it cannot be changed at runtime | Whereas in composition we only define a type which we want to use and which can hold its different implementation also it can change at runtime. Hence, Composition is much more flexible than Inheritance. |
| Here we can only extend one class, in other words more than one class can't be extended as java do not support multiple inheritance. | Whereas composition allows to use functionality from different class. |
| In inheritance we need parent class in order to test child class. | Composition allows to test the implementation of the classes we are using independent of parent or child class. |
| Inheritance cannot extend final class. | Whereas composition allows code reuse even from final classes. |
| It is an ****is-a**** relationship. | While it is a ****has-a**** relationship. |

Which inheritance strategy uses a single table for the entire class hierarchy?

In Java, inheritance represents which relationship?

Which concept is used when a class contains another class object?

![[sucess-img 28.png|success]]

Quiz Completed Successfully

Score:0/3

Accuracy:0%