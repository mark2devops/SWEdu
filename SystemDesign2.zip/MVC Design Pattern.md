---
title: "MVC Design Pattern"
source: "https://www.geeksforgeeks.org/system-design/mvc-design-pattern/"
author:
  - "[[GeeksforGeeks]]"
published: 2017-08-18
created: 2026-09-23
description: "Your All-in-One Learning Portal: GeeksforGeeks is a comprehensive educational platform that empowers learners across domains-spanning computer science and programming, school education, upskilling, commerce, software tools, competitive exams, and more."
tags:
  - "clippings"
---
The MVC (Model–View–Controller) design pattern divides an application into three separate components: Model, View, and Controller. This separation of concerns improves code organization, maintainability, and scalability. Each component handles a specific responsibility, making the application easier to modify and extend.

- ****Model:**** Manages application data and business logic.
- ****View:**** Handles the user interface and presentation of data.
- ****Controller:**** Processes user input and coordinates between Model and View.

## Components

The MVC architecture consists of three main components that work together to separate application logic, data handling, and user interaction.

![[mvc_design_pattern.webp|mvc_design_pattern]]

MVC Design Pattern

### 1\. Model

The Model component in the MVC (Model-View-Controller) design pattern demonstrates the data and business logic of an application. It is responsible for managing the application's data, processing business rules, and responding to requests for information from other components, such as the View and the Controller.

### 2\. View

Displays the data from the Model to the user and sends user inputs to the Controller. It is passive and does not directly interact with the Model. Instead, it receives data from the Model and sends user inputs to the Controller for processing.

### 3\. Controller

Controller acts as an intermediary between the Model and the View. It handles user input and updates the Model accordingly and updates the View to reflect changes in the Model. It contains application logic, such as input validation and data transformation.

## Real-Life Software Example

An e-commerce website follows the MVC pattern to separate data handling, user interface, and request processing.

- ****Model:**** Manages product data, user accounts, and order information from the database.
- ****View:**** Displays product pages, shopping carts, and order details to users.
- ****Controller:**** Handles user requests, processes actions like login or checkout, and updates the Model and View accordingly.

## Uses

MVC is used to organize an application by separating responsibilities, making development and maintenance easier.

- Allows independent development and modification of Model, View, and Controller.
- Improves maintainability by isolating changes to specific components.
- Simplifies testing by separating business logic from the user interface.
- Supports scalability and smoother addition of new features.

## Communication between the Components

This below communication flow ensures that each component is responsible for a specific aspect of the application's functionality, leading to a more maintainable and scalable architecture

- ****User Interaction with View:**** The user interacts with the View, such as clicking a button or entering text into a form.
- ****View Receives User Input:**** The View receives the user input and forwards it to the Controller.
- ****Controller Processes User Input:**** The Controller receives the user input from the View. It interprets the input, performs any necessary operations (such as updating the Model), and decides how to respond.
- ****Controller Updates Model:**** The Controller updates the Model based on the user input or application logic.
- ****Model Notifies View of Changes:**** If the Model changes, it notifies the View.
- ****View Requests Data from Model:**** The View requests data from the Model to update its display.
- ****Controller Updates View:**** The Controller updates the View based on the changes in the Model or in response to user input.
- ****View Renders Updated UI:**** The View renders the updated UI based on the changes made by the Controller.

## Implementation Example

Problem Statement

> Design and implement a student management application using the MVC (Model–View–Controller) design pattern. The Model manages student data such as name and roll number, the View displays the information, and the Controller handles updates and coordinates communication between the Model and View.

![[class_diagram_of_mvc_design_pattern.webp|class_diagram_of_mvc_design_pattern]]

Class Diagram

Let’s break down into the component wise code.

### 1\. Model (Student class)

Represents the data (student's name and roll number) and provides methods to access and modify this data.
C++
```
#include <string>
#include <vector>
using namespace std;

class Student {
private:
    string rollNo;
    string name;

public:
    string getRollNo() {
        return rollNo;
    }

    void setRollNo(string rollNo) {
        this->rollNo = rollNo;
    }

    string getName() {
        return name;
    }

    void setName(string name) {
        this->name = name;
    }
};
```
Java
```
class Student {
    private String rollNo;
    private String name;

    public String getRollNo() {
        return rollNo;
    }

    public void setRollNo(String rollNo) {
        this.rollNo = rollNo;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
```
Python
```
class Student:
    def __init__(self):
        self.__rollNo = ""  # Private attribute
        self.__name = ""  # Private attribute

    def getRollNo(self):
        return self.__rollNo

    def setRollNo(self, rollNo):
        self.__rollNo = rollNo

    def getName(self):
        return self.__name

    def setName(self, name):
        self.__name = name
```
JavaScript
```
class Student {
    constructor() {
        this._rollNo = "";
        this._name = "";
    }

    getRollNo() {
        return this._rollNo;
    }

    setRollNo(rollNo) {
        this._rollNo = rollNo;
    }

    getName() {
        return this._name;
    }

    setName(name) {
        this._name = name;
    }
}
```
### 2\. View (StudentView class)

Represents how the data (student details) should be displayed to the user. Contains a method (`printStudentDetails`) to print the student's name and roll number.
C++
```
#include <iostream>
#include <string>

class StudentView {
public:
    void printStudentDetails(std::string studentName, std::string studentRollNo) {
        std::cout << "Student:\n";
        std::cout << "Name: " << studentName << std::endl;
        std::cout << "Roll No: " << studentRollNo << std::endl;
    }
};
```
Java
```
class StudentView {
    public void printStudentDetails(String studentName, String studentRollNo) {
        System.out.println("Student:");
        System.out.println("Name: " + studentName);
        System.out.println("Roll No: " + studentRollNo);
    }
}
```
Python
```
class StudentView:\n    def printStudentDetails(self, studentName, studentRollNo):\n        print('Student:')\n        print('Name:'+ studentName)\n        print('Roll No:'+ studentRollNo)
```
JavaScript
```
class StudentView {
    printStudentDetails(studentName, studentRollNo) {
        console.log('Student:');\n        console.log('Name: ' + studentName);\n        console.log('Roll No:'+ studentRollNo);
    }
}
```
### 3\. Controller (StudentController class)

Acts as an intermediary between the Model and the View. Contains references to the Model and View objects. Provides methods to update the Model (e.g., `setStudentName`, `setStudentRollNo`) and to update the View (`updateView`).
C++
```
#include <iostream>
#include <string>
using namespace std;

class Student {
private:
    string name;
    string rollNo;
public:
    void setName(string name) { this->name = name; }
    string getName() { return name; }
    void setRollNo(string rollNo) { this->rollNo = rollNo; }
    string getRollNo() { return rollNo; }
};

class StudentView {
public:
    void printStudentDetails(string name, string rollNo) {
        cout << "Student: " << name << ", Roll No: " << rollNo << endl;
    }
};

class StudentController {
private:
    Student model;
    StudentView view;
public:
    StudentController(Student model, StudentView view) : model(model), view(view) {}
    void setStudentName(string name) { model.setName(name); }
    string getStudentName() { return model.getName(); }
    void setStudentRollNo(string rollNo) { model.setRollNo(rollNo); }
    string getStudentRollNo() { return model.getRollNo(); }
    void updateView() { view.printStudentDetails(model.getName(), model.getRollNo()); }
};
```
Java
```
class StudentController {
    private Student model;
    private StudentView view;

    public StudentController(Student model, StudentView view) {
        this.model = model;
        this.view = view;
    }

    public void setStudentName(String name) {
        model.setName(name);
    }

    public String getStudentName() {
        return model.getName();
    }

    public void setStudentRollNo(String rollNo) {
        model.setRollNo(rollNo);
    }

    public String getStudentRollNo() {
        return model.getRollNo();
    }

    public void updateView() {
        view.printStudentDetails(model.getName(), model.getRollNo());
    }
}
```
Python
```
class Student:
    def __init__(self):
        self.name = ""
        self.rollNo = ""
    def set_name(self, name):
        self.name = name
    def get_name(self):
        return self.name
    def set_roll_no(self, rollNo):
        self.rollNo = rollNo
    def get_roll_no(self):
        return self.rollNo

class StudentView:
    def print_student_details(self, name, rollNo):
        print(f'Student: {name}, Roll No: {rollNo}')

class StudentController:
    def __init__(self, model, view):
        self.model = model
        self.view = view
    def set_student_name(self, name):
        self.model.set_name(name)
    def get_student_name(self):
        return self.model.get_name()
    def set_student_roll_no(self, rollNo):
        self.model.set_roll_no(rollNo)
    def get_student_roll_no(self):
        return self.model.get_roll_no()
    def update_view(self):
        self.view.print_student_details(self.model.get_name(), self.model.get_roll_no())
```
JavaScript
```
class Student {
    constructor() {
        this.name = "";
        this.rollNo = "";
    }
    setName(name) {
        this.name = name;
    }
    getName() {
        return this.name;
    }
    setRollNo(rollNo) {
        this.rollNo = rollNo;
    }
    getRollNo() {
        return this.rollNo;
    }
}

class StudentView {
    printStudentDetails(name, rollNo) {
        console.log(`Student: ${name}, Roll No: ${rollNo}`);
    }
}

class StudentController {
    constructor(model, view) {
        this.model = model;
        this.view = view;
    }
    setStudentName(name) {
        this.model.setName(name);
    }
    getStudentName() {
        return this.model.getName();
    }
    setStudentRollNo(rollNo) {
        this.model.setRollNo(rollNo);
    }
    getStudentRollNo() {
        return this.model.getRollNo();
    }
    updateView() {
        this.view.printStudentDetails(this.model.getName(), this.model.getRollNo());
    }
}
```
### Complete code for the above example
C++
```
#include <iostream>
#include <string>
using namespace std;

class Student {
private:
    string rollNo;
    string name;

public:
    string getRollNo() { return rollNo; }
    void setRollNo(string rollNo) { this->rollNo = rollNo; }
    string getName() { return name; }
    void setName(string name) { this->name = name; }
};

class StudentView {
public:
    void printStudentDetails(string studentName, string studentRollNo) {
        cout << "Student:\n";
        cout << "Name: " << studentName << "\n";
        cout << "Roll No: " << studentRollNo << "\n";
    }
};

class StudentController {
private:
    Student model;
    StudentView view;

public:
    StudentController(Student model, StudentView view) : model(model), view(view) {}
    void setStudentName(string name) { model.setName(name); }
    string getStudentName() { return model.getName(); }
    void setStudentRollNo(string rollNo) { model.setRollNo(rollNo); }
    string getStudentRollNo() { return model.getRollNo(); }
    void updateView() { view.printStudentDetails(model.getName(), model.getRollNo()); }
};

Student retriveStudentFromDatabase() {
    Student student;
    student.setName("Lokesh Sharma");
    student.setRollNo("15UCS157");
    return student;
}

int main() {
    Student model = retriveStudentFromDatabase();
    StudentView view;
    StudentController controller(model, view);
    controller.updateView();
    controller.setStudentName("Vikram Sharma");
    controller.updateView();
    return 0;
}
```
Java
```
class Student {
    private String rollNo;
    private String name;

    public String getRollNo() { return rollNo; }

    public void setRollNo(String rollNo)
    {
        this.rollNo = rollNo;
    }

    public String getName() { return name; }

    public void setName(String name) { this.name = name; }
}

class StudentView {
    public void printStudentDetails(String studentName,
                                    String studentRollNo)
    {
        System.out.println("Student:");
        System.out.println("Name: " + studentName);
        System.out.println("Roll No: " + studentRollNo);
    }
}

class StudentController {
    private Student model;
    private StudentView view;

    public StudentController(Student model,
                             StudentView view)
    {
        this.model = model;
        this.view = view;
    }

    public void setStudentName(String name)
    {
        model.setName(name);
    }

    public String getStudentName()
    {
        return model.getName();
    }

    public void setStudentRollNo(String rollNo)
    {
        model.setRollNo(rollNo);
    }

    public String getStudentRollNo()
    {
        return model.getRollNo();
    }

    public void updateView()
    {
        view.printStudentDetails(model.getName(),
                                 model.getRollNo());
    }
}

public class MVCPattern {
    public static void main(String[] args)
    {
        Student model = retriveStudentFromDatabase();

        StudentView view = new StudentView();

        StudentController controller
            = new StudentController(model, view);

        controller.updateView();

        controller.setStudentName("Vikram Sharma");

        controller.updateView();
    }

    private static Student retriveStudentFromDatabase()
    {
        Student student = new Student();
        student.setName("Lokesh Sharma");
        student.setRollNo("15UCS157");
        return student;
    }
}
```
Python
```
class Student:
    def __init__(self):
        self._rollNo = None
        self._name = None

    @property
    def rollNo(self):
        return self._rollNo

    @rollNo.setter
    def rollNo(self, rollNo):
        self._rollNo = rollNo

    @property
    def name(self):
        return self._name

    @name.setter
    def name(self, name):
        self._name = name

class StudentView:
    def printStudentDetails(self, studentName, studentRollNo):
        print('Student:')
        print('Name:', studentName)
        print('Roll No:', studentRollNo)

class StudentController:
    def __init__(self, model, view):
        self.model = model
        self.view = view

    def setStudentName(self, name):
        self.model.name = name

    def getStudentName(self):
        return self.model.name

    def setStudentRollNo(self, rollNo):
        self.model.rollNo = rollNo

    def getStudentRollNo(self):
        return self.model.rollNo

    def updateView(self):
        self.view.printStudentDetails(self.model.name, self.model.rollNo)

def retriveStudentFromDatabase():
    student = Student()
    student.name = 'Lokesh Sharma'
    student.rollNo = '15UCS157'
    return student

if __name__ == '__main__':
    model = retriveStudentFromDatabase()
    view = StudentView()
    controller = StudentController(model, view)
    controller.updateView()
    controller.setStudentName('Vikram Sharma')
    controller.updateView()
```
JavaScript
```
class Student {
    constructor() {
        this._rollNo = null;
        this._name = null;
    }

    get rollNo() {
        return this._rollNo;
    }

    set rollNo(rollNo) {
        this._rollNo = rollNo;
    }

    get name() {
        return this._name;
    }

    set name(name) {
        this._name = name;
    }
}

class StudentView {
    printStudentDetails(studentName, studentRollNo) {
        console.log('Student:')
        console.log('Name:'+ studentName);
        console.log('Roll No:'+ studentRollNo);
    }
}

class StudentController {
    constructor(model, view) {
        this.model = model;
        this.view = view;
    }

    setStudentName(name) {
        this.model.name = name;
    }

    getStudentName() {
        return this.model.name;
    }

    setStudentRollNo(rollNo) {
        this.model.rollNo = rollNo;
    }

    getStudentRollNo() {
        return this.model.rollNo;
    }

    updateView() {
        this.view.printStudentDetails(this.model.name, this.model.rollNo);
    }
}

function retriveStudentFromDatabase() {
    let student = new Student();
    student.name = 'Lokesh Sharma';
    student.rollNo = '15UCS157';
    return student;
}

let model = retriveStudentFromDatabase();
let view = new StudentView();
let controller = new StudentController(model, view);
controller.updateView();
controller.setStudentName('Vikram Sharma');
controller.updateView();
```
The complete code for the above example is.

**Output**
```
Student:
Name: Lokesh Sharma
Roll No: 15UCS157
Student:
Name: Vikram Sharma
Roll No: 15UCS157
```

## Advantages

MVC provides several benefits that improve application design and development.

- Clear separation of concerns improves maintainability.
- Allows parallel development of UI and business logic.
- Makes testing easier, especially unit testing.

## Disadvantages

Despite its benefits, MVC has some limitations.

- Increased complexity for small or simple applications.
- Requires more initial design and planning.
- Can be harder for beginners to understand and implement.

What is the main purpose of the MVC design pattern?

- A
	To combine user interface and business logic into one component
- B
	To divide an application into separate components based on responsibility
- C
	To reduce the number of classes in an application
- D
	To eliminate the need for controllers

Which component in MVC is responsible for managing application data and business logic?

- A
	View
- B
	Controller
- C
	Router
- D
	Model

Which component directly handles user input in MVC?

- A
	Model
- B
	Database
- C
	View
- D
	Controller

What is the role of the View in the MVC pattern?

- A
	To update the database directly
- B
	To handle business logic
- C
	To display data to the user
- D
	To validate input data

Why does MVC improve maintainability?

- A
	Because all logic is written in a single file
- B
	Because it removes the need for testing
- C
	Because it reduces user interaction
- D
	Because changes in one component have minimal impact on others

After the View receives user input, which MVC component processes it next?

Which MVC component updates the Model based on user input and then coordinates updating the View?

![[sucess-img 65.png|success]]

Quiz Completed Successfully

Score:0/7

Accuracy:0%