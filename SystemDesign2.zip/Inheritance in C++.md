---
title: "Inheritance in C++"
source: "https://www.geeksforgeeks.org/cpp/inheritance-in-c/"
author:
  - "[[GeeksforGeeks]]"
published: 2017-05-25
created: 2026-09-23
description: "Your All-in-One Learning Portal: GeeksforGeeks is a comprehensive educational platform that empowers learners across domains-spanning computer science and programming, school education, upskilling, commerce, software tools, competitive exams, and more."
tags:
  - "clippings"
---
Inheritance is one of the fundamental concepts of Object-Oriented Programming (OOP) that allows a class to acquire the properties and behaviors of another class. It promotes code reusability by enabling new classes to extend existing ones instead of rewriting code.

- Allows derived classes to reuse members of an existing class.
- Supports code reusability and hierarchical class design.

****Example:**** In the following example, Animal is the base class and Dog, Cat and Cow are derived classes that extend the Animal class.

![[animal_class.webp|animal_class]]
```
#include <iostream>
using namespace std;

class Animal
{
  public:
    void sound()
    {
        cout << "Animal makes a sound" << endl;
    }
};

class Dog : public Animal
{
  public:
    void sound()
    {
        cout << "Dog barks" << endl;
    }
};

class Cat : public Animal
{
  public:
    void sound()
    {
        cout << "Cat meows" << endl;
    }
};

class Cow : public Animal
{
  public:
    void sound()
    {
        cout << "Cow moos" << endl;
    }
};

int main()
{
    Dog d;
    d.sound();

    Cat c;
    c.sound();

    Cow cow;
    cow.sound();

    return 0;
}
```
**Output**
```
Dog barks
Cat meows
Cow moos
```

****Explanation:**** Animal is the base class, while Dog, Cat, and Cow are derived classes. Each derived class provides its own implementation of sound(), demonstrating how inheritance allows specialized behavior.

### Syntax

> class ChildClass: public ParentClass  
> {  
> // Additional fields and methods  
> };

****Where:****

- DerivedClass is the class inheriting from another class.
- BaseClass is the class being inherited.
- accessSpecifier can be public, protected, or private.

## How Inheritance Works

Inheritance establishes a parent-child relationship between classes. The derived class automatically acquires the accessible members of the base class and can also define its own members.

- Inherits accessible data members and member functions.
- Can add new members specific to the derived class.
- Can override inherited virtual functions.
- Eliminates duplicate code across related classes.

## Types of Inheritance

C++ supports five types of inheritance.

![[inheritance.jpg|inheritance]]

### 1\. Single Inheritance

In single inheritance, a sub-class is derived from only one super class. It inherits the properties and behavior of a single-parent class. Sometimes, it is also known as simple inheritance.

![[inheritence.webp|inheritence]]

Single Inheritance
```
#include <iostream>
using namespace std;

class Vehicle {
public:
    Vehicle() {
        cout << "This is a Vehicle" << endl;
    }
};

class Car : public Vehicle {
public:
    Car() {
        cout << "This Vehicle is Car" << endl;
    }
};

int main() {
   
    Car obj;
    return 0;
}
```
**Output**
```
This is a Vehicle
This Vehicle is Car
```

### 2\. Multiple Inheritance

In [Multiple inheritance](https://www.geeksforgeeks.org/cpp/multiple-inheritance-in-c/), one class can have more than one superclass and inherit features from all parent classes.

![[Multiple_inheritance.webp|Multiple_inheritance]]

Multiple Inheritance
```
#include <iostream>
using namespace std;

class LandVehicle
{
  public:
    void landInfo()
    {
        cout << "This is a LandVehicle" << endl;
    }
};

class WaterVehicle
{
  public:
    void waterInfo()
    {
        cout << "This is a WaterVehicle" << endl;
    }
};

// Derived class inheriting from both base classes
class AmphibiousVehicle : public LandVehicle, public WaterVehicle
{
  public:
    AmphibiousVehicle()
    {
        cout << "This is an AmphibiousVehicle" << endl;
    }
};

int main()
{
    AmphibiousVehicle obj;

    obj.waterInfo();
    obj.landInfo();

    return 0;
}
```
**Output**
```
This is an AmphibiousVehicle
This is a WaterVehicle
This is a LandVehicle
```

### 3\. Multilevel Inheritance

[Multilevel inheritance](https://www.geeksforgeeks.org/cpp/cpp-multilevel-inheritance/) means a class is derived from another derived class, forming a chain of inheritance.

![[Multilevel_inheritance.webp|Multilevel_inheritance]]

Multilevel Inheritance
```
#include <iostream>
using namespace std;

class Vehicle
{
  public:
    Vehicle()
    {
        cout << "This is a Vehicle" << endl;
    }
};

// Derived class from Vehicle
class FourWheeler : public Vehicle
{
  public:
    FourWheeler()
    {
        cout << "4 Wheeler Vehicles" << endl;
    }
};

// Derived class from FourWheeler
class Car : public FourWheeler
{
  public:
    Car()
    {
        cout << "This 4 Wheeler Vehicle is a Car" << endl;
    }
};

int main()
{
    Car obj;
    return 0;
}
```
**Output**
```
This is a Vehicle
4 Wheeler Vehicles
This 4 Wheeler Vehicle is a Car
```

### 4\. Hierarchical Inheritance

In [hierarchical inheritance](https://www.geeksforgeeks.org/cpp/cpp-hierarchical-inheritance/), more than one subclass is inherited from a single base class. i.e. more than one derived class is created from a single base class. For example, cars and buses both are vehicle.

![[hierarchical_inheritance.webp|hierarchical_inheritance]]

Hierarchical Inheritance
```
#include <iostream>
using namespace std;

class Vehicle
{
  public:
    Vehicle()
    {
        cout << "This is a Vehicle" << endl;
    }
};

class Car : public Vehicle
{
  public:
    Car()
    {
        cout << "This Vehicle is Car" << endl;
    }
};

class Bus : public Vehicle
{
  public:
    Bus()
    {
        cout << "This Vehicle is Bus" << endl;
    }
};

int main()
{
    Car obj1;
    Bus obj2;
    return 0;
}
```
**Output**
```
This is a Vehicle
This Vehicle is Car
This is a Vehicle
This Vehicle is Bus
```

### 5\. Hybrid Inheritance

In [hybrid inheritence](https://www.geeksforgeeks.org/cpp/hybrid-inheritance-in-cpp/) when two or more types of inheritance are combined in one program. For example, a class might use multiple inheritance and also be part of a multilevel inheritance chain.

![[inheritence_5.webp|inheritence_5]]

Hybrid Inheritance
```
#include <iostream>
using namespace std;

class Vehicle
{
  public:
    Vehicle()
    {
        cout << "This is a Vehicle" << endl;
    }
};

class Fare
{
  public:
    Fare()
    {
        cout << "Fare of Vehicle" << endl;
    }
};

class Car : public Vehicle
{
  public:
    Car()
    {
        cout << "This Vehicle is a Car" << endl;
    }
};

class Bus : public Vehicle, public Fare
{
  public:
    Bus()
    {
        cout << "This Vehicle is a Bus with Fare";
    }
};

int main()
{
    Bus obj2;
    return 0;
}
```
**Output**
```
This is a Vehicle
Fare of Vehicle
This Vehicle is a Bus with Fare
```

****Diamond Problem****

Hybrid inheritance may create the [Diamond Problem](https://www.geeksforgeeks.org/cpp/diamond-problem-in-cpp/), where a class inherits the same base class through multiple inheritance paths.

- Multiple copies of the base class are created.
- Leads to ambiguity while accessing inherited members.
- Solved using virtual inheritance.

****Virtual Inheritance****

[Virtual inheritance](https://www.geeksforgeeks.org/questions/what-is-virtual-inheritance-in-c/) ensures that only one shared copy of the common base class exists.

- Eliminates ambiguity caused by the Diamond Problem.
- Prevents duplication of base class members.
- Used together with multiple inheritance.

## Advantages of Inheritance in C++

Inheritance improves software organization by promoting reuse and extensibility.

- Reduces code duplication through reuse.
- Simplifies maintenance by centralizing common functionality.
- Supports hierarchical class organization.
- Enables runtime polymorphism through virtual functions.
- Makes applications easier to extend.

## Limitations of Inheritance

Although inheritance is powerful, excessive use can make programs difficult to maintain.

- Creates tight coupling between base and derived classes.
- Changes in the base class can affect all derived classes.
- Deep inheritance hierarchies reduce readability.
- Multiple inheritance may introduce ambiguity.
- Virtual functions add slight runtime overhead.

Which inheritance type is used in the class given below?

class A: public X, public Y {};

- A
	Multilevel inheritance
- B
	Multiple inheritance
- C
	Hybrid inheritance
- D
	Hierarchical inheritance

In multiple inheritance, if two base classes have the same function and the derived class does not override it, what happens?

- A
	Compiler selects the first base class function
- B
	Compiler selects the last base class function
- C
	Compiler gives ambiguity error
- D
	Both functions run automatically

Which symbol is used for inheritance in C++?

- A
	.
- B
	:
- C
	\->
- D
	::

What type of inheritance is shown below?

- A
	Multiple inheritance
- B
	Multilevel inheritance
- C
	Hybrid inheritance
- D
	Single inheritance

What will be the output?

![[sucess-img 51.png|success]]

Quiz Completed Successfully

Score:0/5

Accuracy:0%