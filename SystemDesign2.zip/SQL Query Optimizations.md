---
title: "SQL Query Optimizations"
source: "https://www.geeksforgeeks.org/sql/best-practices-for-sql-query-optimizations/"
author:
  - "[[GeeksforGeeks]]"
published: 2022-03-30
created: 2026-09-23
description: "Your All-in-One Learning Portal: GeeksforGeeks is a comprehensive educational platform that empowers learners across domains-spanning computer science and programming, school education, upskilling, commerce, software tools, competitive exams, and more."
tags:
  - "clippings"
---
- [SQL](https://www.geeksforgeeks.org/sql/sql-tutorial/)
- [Projects](https://www.geeksforgeeks.org/blogs/sql-project-ideas/)
- [Interview Questions](https://www.geeksforgeeks.org/sql/sql-interview-questions/)
- [Quiz](https://www.geeksforgeeks.org/sql/sql-quiz/)
- [DBMS](https://www.geeksforgeeks.org/dbms/dbms/)
- [PostgreSQL](https://www.geeksforgeeks.org/python/introduction-to-psycopg2-module-in-python/)
- [Django](https://www.geeksforgeeks.org/python/django-tutorial/)
- [ReactJS](https://www.geeksforgeeks.org/reactjs/react/)
- [Vue.js](https://www.geeksforgeeks.org/javascript/vue-js/)
- [AngularJS](https://www.geeksforgeeks.org/angular-js/angularjs/)

Poorly written SQL queries can make your database slow, use too many resources, cause locking problems, and give a bad experience to users. Following best practices for writing efficient SQL queries helps improve database performance and ensures optimal use of system resources.

- Reduces query execution time and improves overall performance.
- Minimizes resource consumption while avoiding locking and blocking problems.

## 1\. Use Indexes Wisely

[Indexes](https://www.geeksforgeeks.org/sql/sql-indexes/) help the database find data faster without scanning the whole table.

****Example:**** Creating an index on customer\_id if there are frequent queries on this column like the following query.

```
SELECT * FROM orders WHERE customer_id = 123;
```

Creating an index on customer\_id makes this query much faster:

```
CREATE INDEX idx_orders_customer_id ON orders(customer_id);
```

The above query will run much faster if customer\_id is indexed.

- ****Primary Index****: Automatically created on the primary key; keeps values unique and fast to access.
- ****Secondary Index****: Created on non-primary key columns to improve query performance. Need to be created manually.
- ****Clustered Index****: Determines the arrangement of data in a table; only one per table. In some databases primary indexes are automatically clustered.
- ****Non-Clustered Index****: Contains pointers to the data; multiple can exist per table

****Indexing Guidelines****

- Index columns used often in [WHERE](https://www.geeksforgeeks.org/sql/sql-where-clause/), [JOIN](https://www.geeksforgeeks.org/sql/sql-join-set-1-inner-left-right-and-full-joins/), or [ORDER BY](https://www.geeksforgeeks.org/sql/sql-order-by/) clauses.
- Avoid too many indexes—they slow down [INSERT](https://www.geeksforgeeks.org/sql/sql-insert-statement/), [UPDATE](https://www.geeksforgeeks.org/sql/sql-update-statement/), and [DELETE](https://www.geeksforgeeks.org/sql/sql-delete-statement/).
- Check and monitor index usage regularly to keep queries fast.

## 2\. Avoid SELECT \*: Choose Only Required Columns

Using [SELECT \*](https://www.geeksforgeeks.org/sql/sql-select-query/) can make queries slow, especially on large tables or when joining multiple tables. This is because the database retrieves all columns, even the ones you don’t need. It uses more memory, takes longer to transfer data, and makes the query harder for the database to optimize.

****Avoid this:****

```
SELECT * FROM products;
```

****Use this instead:****

```
SELECT product_id, product_name, price FROM products;
```

### Benefits:

- Uses less memory and runs faster.
- Lets the database skip unneeded columns.
- Makes queries simpler and easier to read.

## 3\. Limit Rows with WHERE and LIMIT

Fetching too many rows can make your query slow. Even if your app needs only 10 rows, the database might return thousands. Use WHERE to filter data and [LIMIT](https://www.geeksforgeeks.org/sql/sql-limit-clause/) to get only the rows you need.

****Example:****

```
SELECT name FROM customers WHERE country = 'USA'  ORDER BY signup_date DESCLIMIT 50;
```

### Benefits:

- Makes queries faster and uses less CPU.
- Sends only the data you need, avoiding overload.
- Useful for testing and previewing results.

## 4\. Write Efficient WHERE Clauses

The `WHERE` clause filters rows in a query, but how you write it affects performance. Using functions or calculations on columns can stop the database from using indexes, which makes the query slower.

****Poor Example:****

```
SELECT * FROM employees WHERE YEAR(joining_date) = 2022;
```

****Drawback:**** Applying YEAR() to every row stops the database from using indexes.

****Optimized Example:****

```
SELECT * FROM employees WHERE joining_date >= '2022-01-01' AND joining_date < '2023-01-01';
```

### Performance Tips:

- Don’t use functions on columns (YEAR(), LOWER(), etc.).
- Avoid calculations on columns (salary + 5000 = 100000).
- Write conditions so indexes can be used efficiently.

## 5\. Use Joins Smartly

Join only the tables you need and filter data before joining. Use [INNER JOIN](https://www.geeksforgeeks.org/sql/sql-inner-join/) instead of [OUTER JOIN](https://www.geeksforgeeks.org/sql/sql-outer-join/) if you don’t need unmatched rows.

****Example:****

```
SELECT u.name, o.amount
FROM users u
JOIN orders o ON u.user_id = o.user_id
WHERE o.amount > 100;
```

### Benefits:

- Faster join processing.
- INNER JOIN combines rows based on a matching condition using ON, ensuring only related records are returned.
- Helps the database choose an efficient execution plan.

## 6\. Avoid N+1 Query Problems

N+1 happens when you run one query to get a list, then run extra queries for each item. Fetch related data in a single query using JOINs instead.

****Poor Approach:****

```
SELECT * FROM users;
-- For each user: SELECT * FROM orders WHERE user_id = ?
```

****Recommended Approach:****

```
SELECT u.user_id, u.name, o.order_id, o.amount
FROM users u
JOIN orders o ON u.user_id = o.user_id;
```

### Benefits:

- Fewer database calls.
- Faster response time.
- Reduces load on the database.

## 7\. Use EXISTS Instead of IN (for Subqueries)

When you want to check whether a specific record exists in a table, using the [EXISTS](https://www.geeksforgeeks.org/sql/sql-exists/) operator is often faster than using IN. This is particularly true when the subquery returns a large number of rows, because EXISTS stops searching as soon as it finds the first matching record, whereas IN has to process all the results before making the comparison.

****Poor Approach:****

```
SELECT name FROM customers
WHERE customer_id IN (SELECT customer_id FROM orders);
```

****Recommended Approach:****

```
SELECT name FROM customers
WHERE EXISTS (
  SELECT 1 FROM orders WHERE orders.customer_id = customers.customer_id
);
```

### Benefits:

- Stops searching once a match is found.
- Uses less memory for large subqueries.
- Often faster and better optimized.

## 8\. Avoid Wildcards at the Start of LIKE

Don’t start a [LIKE](https://www.geeksforgeeks.org/sql/sql-like/) pattern with % because it disables index use and causes a full table scan.

****Poor Approach****:

```
SELECT * FROM users WHERE name LIKE '%john';
```

****Recommended Approach:****

```
SELECT * FROM users WHERE name LIKE 'john%';
```

### Benefits:

- Keeps searches fast and index-friendly.
- Reduces scanning overhead.

## 9\. Use Query Execution Plan

Check how the database runs your query using [EXPLAIN](https://www.geeksforgeeks.org/sql/explain-in-sql/) (MySQL/PostgreSQL) to see slow parts.

****Example:****

```
EXPLAIN SELECT * FROM orders WHERE user_id = 42;
```

### Benefits:

- Helps identify full table scans
- Reveals if indexes are used
- Guides optimization decisions

## 10\. Use UNION ALL Instead of UNION (if possible)

[UNION](https://www.geeksforgeeks.org/sql/sql-union-operator/) removes duplicates, which adds sorting overhead. Use [UNION ALL](https://www.geeksforgeeks.org/sql/sql-union-all/) if duplicates don’t matter.

****Poor Approach:****

```
SELECT col FROM table1
UNION
SELECT col FROM table2;
```

****Recommended Approach:****

```
SELECT col FROM table1
UNION ALL
SELECT col FROM table2;
```

### Benefits:

- Avoids unnecessary sorting.
- Merges results faster.
- Better for large datasets.

Which clause in SQL is used to apply conditions on aggregated values?

- A
	WHERE
- B
	GROUP BY
- C
	HAVING
- D
	ORDER BY

Which of the following is an example of a best practice for optimizing SQL queries?

- A
	Using SELECT \* to retrieve all columns
- B
	Avoiding the use of WHERE clauses in queries
- C
	Using JOIN instead of multiple subqueries when possible
- D
	Using a single query to retrieve all data without any filtering

What is one of the most effective ways to improve the performance of a query in SQL?

- A
	Adding more rows to the tables
- B
	Reducing the number of columns selected in a query
- C
	Using multiple OR conditions in the WHERE clause
- D
	Using DISTINCT for every query

Which of the following is a best practice for optimizing SQL queries involving joins?

What is the effect of using EXPLAIN in SQL before running a query?

- A
	Display the expected query results without executing it
- B
	Show the query execution plan to identify performance bottlenecks
- C
	Automatically optimize and rewrite the SQL query
- D
	Permanently create indexes for faster execution

![[sucess-img 84.png|success]]

Quiz Completed Successfully

Score:0/5

Accuracy:0%