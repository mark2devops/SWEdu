---
title: "Abstract Factory Pattern"
source: "https://www.geeksforgeeks.org/system-design/abstract-factory-pattern/"
author:
  - "[[GeeksforGeeks]]"
published: 2017-07-14
created: 2026-09-23
description: "Your All-in-One Learning Portal: GeeksforGeeks is a comprehensive educational platform that empowers learners across domains-spanning computer science and programming, school education, upskilling, commerce, software tools, competitive exams, and more."
tags:
  - "clippings"
---
The Abstract Factory Pattern is a creational design pattern that provides an interface for creating families of related or dependent objects without specifying their concrete classes. It acts as a "factory of factories," where a super-factory creates other factories that in turn produce specific objects.

- Works around a super-factory that produces multiple factories.
- Concrete factories created at runtime decide the actual product types.
- Useful when the system needs to be independent of how products are created or represented.
- Makes it easy to switch between different groups of related objects without code changes.

****Example:**** A UI theme system supports Light and Dark themes, where each theme provides its own set of components like Button and TextBox. The application uses a factory to create these components, allowing it to switch between themes without changing the main code.

![[uicomponentfactory.webp|uicomponentfactory]]

Abstract Factory Pattern

In the above Diagram

- The diagram shows two factories, LightThemeFactory and DarkThemeFactory, that create UI components.
- Each factory produces related components like Button and TextBox, ensuring consistency within a theme.
- The client uses the abstract factory, allowing easy theme switching without changing core code.

## Real Life Applications

The Abstract Factory Pattern is widely used to provide a consistent way to create related objects across different platforms or systems.

- In applications that need to support multiple cloud platforms (e.g., AWS, Azure, Google Cloud), the Abstract Factory Pattern facilitates the creation of cloud-specific services. An abstract factory can define interfaces for services like storage, compute, and networking.
- In applications that need to support multiple database systems (e.g., SQL, NoSQL), the Abstract Factory Pattern can be used to create database connections and queries. An abstract factory defines interfaces for creating database-related objects.

## Components

To understand abstract factory pattern, we have to understand the components of it and relationships between them.

- ****Abstract Factory****: It provides a way such that concrete factories follow a common interface, providing consistent way to produce related set of objects.
- ****Concrete Factories****: Concrete Factories implement the rules specified by the abstract factory. It contain the logic for creating specific instances of objects within a family.
- ****Abstract Products****: It acts as an abstract or interface type that all concrete products within a family must follow to and provides a unified way for concrete products to be used interchangeably.
- ****Concrete Products****: They implement the methods declared in the abstract products, ensuring consistency within a family and belong to a specific category or family of related objects.
- ****Client****: Client utilizes the abstract factory to create families of objects without specifying their concrete types and interacts with objects through abstract interfaces provided by abstract products.

## Features

The Abstract Factory Pattern provides a structured way to create related objects while keeping client code independent of their concrete implementations.

- Creates families of related or dependent objects.
- Provides an interface for creating multiple related products.
- Promotes consistency among products of the same family.

## Implementation Example

Understand Abstract Factory Design Pattern using an example:

> ****Imagine you're managing a global car manufacturing company****
> 
> - You want to design a system to create cars with specific configurations for different regions, such as North America and Europe.
> - Each region may have unique requirements and regulations, and you want to ensure that cars produced for each region meet those standards.

### Challenges while implementing this system

- Different regions have different cars with different features, so designing this can be challenging.
- The other main challenge is to ensure consistency in the production of cars and their specifications within each region.
- There can be updation in having new cars in different regions so adapting the system to changes in regulations or introducing new features for a specific region becomes challenging.
- So, Modifications would need to be made in multiple places, increasing the chances of introducing bugs and making the system more prone to errors.

### Solution of above challenges by Abstract Factory Pattern

Below is how abstract factory pattern help to solve the above challenges. After using this pattern:

- Different regions has their own factory to create cars for local needs.
- This helps to keeps the design and features the same for vehicles in each region.
- You can change one region without affecting others (e.g., updating North America doesn’t impact Europe).
- To add a new region, just create a new factory, no need to change existing code.
- The pattern keeps car creation separate from how they are used.
![[class_diagram_of_abstract_factory_pattern-1.webp|class_diagram_of_abstract_factory_pattern-1]]

Class Diagram

### Code of above problem statement:

### 1\. Abstract Factory Interface (CarFactory)

"CarFactory" is a Abstract Factory Interface that defines methods for creating cars and their specifications.
C++
```
/* Abstract Factory Interface */
class CarFactory {
public:
    virtual Car* createCar() = 0;
    virtual CarSpecification* createSpecification() = 0;
};
```
Java
```
/* Abstract Factory Interface */
interface CarFactory {
    Car createCar();
    CarSpecification createSpecification();
}
```
Python
```
""" Abstract Factory Interface """
from abc import ABC, abstractmethod

class CarFactory(ABC):
    @abstractmethod
    def createCar(self):
        pass

    @abstractmethod
    def createSpecification(self):
        pass
```
JavaScript
```
/* Abstract Factory Interface */
class CarFactory {
    createCar() {
        throw new Error('Method not implemented.');
    }

    createSpecification() {
        throw new Error('Method not implemented.');
    }
}
```
### 2\. Concrete Factories (NorthAmericaCarFactory and EuropeCarFactory)

"NorthAmericaCarFactory" and "EuropeCarFactory" are concrete factories that implement the abstract factory interface "CarFactory" to create cars and specifications specific to North America, Europe.
C++
```
#include <memory>
#include "Car.h"
#include "CarSpecification.h"

class NorthAmericaCarFactory : public CarFactory {
public:
    std::unique_ptr<Car> createCar() override {
        return std::make_unique<Sedan>();
    }

    std::unique_ptr<CarSpecification> createSpecification() override {
        return std::make_unique<NorthAmericaSpecification>();
    }
};

class EuropeCarFactory : public CarFactory {
public:
    std::unique_ptr<Car> createCar() override {
        return std::make_unique<Hatchback>();
    }

    std::unique_ptr<CarSpecification> createSpecification() override {
        return std::make_unique<EuropeSpecification>();
    }
};
```
Java
```
// Concrete Factory for North America Cars
class NorthAmericaCarFactory implements CarFactory {
    public Car createCar() {
        return new Sedan();
    }

    public CarSpecification createSpecification() {
        return new NorthAmericaSpecification();
    }
}

// Concrete Factory for Europe Cars
class EuropeCarFactory implements CarFactory {
    public Car createCar() {
        return new Hatchback();
    }

    public CarSpecification createSpecification() {
        return new EuropeSpecification();
    }
}
```
Python
```
# Concrete Factory for North America Cars
class NorthAmericaCarFactory(CarFactory):
    def create_car(self):
        return Sedan()

    def create_specification(self):
        return NorthAmericaSpecification()

# Concrete Factory for Europe Cars
class EuropeCarFactory(CarFactory):
    def create_car(self):
        return Hatchback()

    def create_specification(self):
        return EuropeSpecification()
```
JavaScript
```
// Concrete Factory for North America Cars
class NorthAmericaCarFactory {
    createCar() {
        return new Sedan();
    }

    createSpecification() {
        return new NorthAmericaSpecification();
    }
}

// Concrete Factory for Europe Cars
class EuropeCarFactory {
    createCar() {
        return new Hatchback();
    }

    createSpecification() {
        return new EuropeSpecification();
    }
}
```
### 3\. Abstract Products (Car and CarSpecification interfaces)

Define interfaces for cars and specifications to ensure a common structure.
C++
```
/* Abstract Product Interface for Cars */
class Car {
public:
    virtual void assemble() = 0;
};

/* Abstract Product Interface for Car Specifications */
class CarSpecification {
public:
    virtual void display() = 0;
};
```
Java
```
// Abstract Product Interface for Cars
interface Car {
    void assemble();
}

// Abstract Product Interface for Car Specifications
interface CarSpecification {
    void display();
}
```
Python
```
# Abstract Product Interface for Cars
from abc import ABC, abstractmethod

class Car(ABC):
    @abstractmethod
    def assemble(self):
        pass

# Abstract Product Interface for Car Specifications
class CarSpecification(ABC):
    @abstractmethod
    def display(self):
        pass
```
JavaScript
```
// Abstract Product Interface for Cars
class Car {
    assemble() {
        throw new Error('Method not implemented.');
    }
}

// Abstract Product Interface for Car Specifications
class CarSpecification {
    display() {
        throw new Error('Method not implemented.');
    }
}
```
### 4\. Concrete Products (Sedan, Hatchback, NorthAmericaSpecification, EuropeSpecification)

"Sedan", "Hatchback", "NorthAmericaSpecification", "EuropeSpecification" are concrete products that implement the interfaces to create specific instances of cars and specifications.
C++
```
// Concrete Product for Sedan Car
class Car {
public:
    virtual void assemble() = 0;
};

class Sedan : public Car {
public:
    void assemble() {
        std::cout << "Assembling Sedan car." << std::endl;
    }
};

// Concrete Product for Hatchback Car
class Hatchback : public Car {
public:
    void assemble() {
        std::cout << "Assembling Hatchback car." << std::endl;
    }
};

// Concrete Product for North America Car Specification
class CarSpecification {
public:
    virtual void display() = 0;
};

class NorthAmericaSpecification : public CarSpecification {
public:
    void display() {
        std::cout << "North America Car Specification: Safety features compliant with local regulations." << std::endl;
    }
};

// Concrete Product for Europe Car Specification
class EuropeSpecification : public CarSpecification {
public:
    void display() {
        std::cout << "Europe Car Specification: Fuel efficiency and emissions compliant with EU standards." << std::endl;
    }
};
```
Java
```
// Concrete Product for Sedan Car
interface Car {
    void assemble();
}

class Sedan implements Car {
    public void assemble() {
        System.out.println("Assembling Sedan car.");
    }
}

// Concrete Product for Hatchback Car
class Hatchback implements Car {
    public void assemble() {
        System.out.println("Assembling Hatchback car.");
    }
}

// Concrete Product for North America Car Specification
interface CarSpecification {
    void display();
}

class NorthAmericaSpecification implements CarSpecification {
    public void display() {
        System.out.println("North America Car Specification: Safety features compliant with local regulations.");
    }
}

// Concrete Product for Europe Car Specification
class EuropeSpecification implements CarSpecification {
    public void display() {
        System.out.println("Europe Car Specification: Fuel efficiency and emissions compliant with EU standards.");
    }
}
```
Python
```
# Concrete Product for Sedan Car
class Car:
    def assemble(self):
        pass

class Sedan(Car):
    def assemble(self):
        print("Assembling Sedan car.")

# Concrete Product for Hatchback Car
class Hatchback(Car):
    def assemble(self):
        print("Assembling Hatchback car.")

# Concrete Product for North America Car Specification
class CarSpecification:
    def display(self):
        pass

class NorthAmericaSpecification(CarSpecification):
    def display(self):
        print("North America Car Specification: Safety features compliant with local regulations.")

# Concrete Product for Europe Car Specification
class EuropeSpecification(CarSpecification):
    def display(self):
        print("Europe Car Specification: Fuel efficiency and emissions compliant with EU standards.")
```
JavaScript
```
// Concrete Product for Sedan Car
class Car {
    assemble() {
        throw new Error('Method not implemented.');
    }
}

class Sedan extends Car {
    assemble() {
        console.log('Assembling Sedan car.');
    }
}

// Concrete Product for Hatchback Car
class Hatchback extends Car {
    assemble() {
        console.log('Assembling Hatchback car.');
    }
}

// Concrete Product for North America Car Specification
class CarSpecification {
    display() {
        throw new Error('Method not implemented.');
    }
}

class NorthAmericaSpecification extends CarSpecification {
    display() {
        console.log('North America Car Specification: Safety features compliant with local regulations.');
    }
}

// Concrete Product for Europe Car Specification
class EuropeSpecification extends CarSpecification {
    display() {
        console.log('Europe Car Specification: Fuel efficiency and emissions compliant with EU standards.');
    }
}
```
### Complete code for the above example

Below is the complete code for the above example:
C++
```
#include <iostream>
#include <memory>

class Car
{
  public:
    virtual void assemble() = 0;
    virtual ~Car()
    {
    }
};

class CarSpecification
{
  public:
    virtual void display() = 0;
    virtual ~CarSpecification()
    {
    }
};

class CarFactory
{
  public:
    virtual std::unique_ptr<Car> createCar() = 0;
    virtual std::unique_ptr<CarSpecification> createSpecification() = 0;
    virtual ~CarFactory()
    {
    }
};

// Concrete Product for Sedan Car
class Sedan : public Car
{
  public:
    void assemble() override
    {
        std::cout << "Assembling Sedan car." << std::endl;
    }
};

// Concrete Product for Hatchback Car
class Hatchback : public Car
{
  public:
    void assemble() override
    {
        std::cout << "Assembling Hatchback car." << std::endl;
    }
};

// Concrete Product for North America Car Specification
class NorthAmericaSpecification : public CarSpecification
{
  public:
    void display() override
    {
        std::cout << "North America Car Specification: Safety features compliant with local regulations."
                  << std::endl;
    }
};

// Concrete Product for Europe Car Specification
class EuropeSpecification : public CarSpecification
{
  public:
    void display() override
    {
        std::cout << "Europe Car Specification: Fuel efficiency and emissions compliant with EU standards."
                  << std::endl;
    }
};

// Concrete Factory for North America Cars
class NorthAmericaCarFactory : public CarFactory
{
  public:
    std::unique_ptr<Car> createCar() override
    {
        return std::make_unique<Sedan>();
    }
    std::unique_ptr<CarSpecification> createSpecification() override
    {
        return std::make_unique<NorthAmericaSpecification>();
    }
};

// Concrete Factory for Europe Cars
class EuropeCarFactory : public CarFactory
{
  public:
    std::unique_ptr<Car> createCar() override
    {
        return std::make_unique<Hatchback>();
    }
    std::unique_ptr<CarSpecification> createSpecification() override
    {
        return std::make_unique<EuropeSpecification>();
    }
};

// Client Code
int main()
{
    // Creating cars for North America
    CarFactory *northAmericaFactory = new NorthAmericaCarFactory();
    auto northAmericaCar = northAmericaFactory->createCar();
    auto northAmericaSpec = northAmericaFactory->createSpecification();

    northAmericaCar->assemble();
    northAmericaSpec->display();

    // Creating cars for Europe
    CarFactory *europeFactory = new EuropeCarFactory();
    auto europeCar = europeFactory->createCar();
    auto europeSpec = europeFactory->createSpecification();

    europeCar->assemble();
    europeSpec->display();

    delete northAmericaFactory;
    delete europeFactory;
    return 0;
}
```
Java
```
// Abstract Factory Interface
interface CarFactory {
    Car createCar();
    CarSpecification createSpecification();
}

// Concrete Factory for North America Cars
class NorthAmericaCarFactory implements CarFactory {
    public Car createCar() { return new Sedan(); }

    public CarSpecification createSpecification()
    {
        return new NorthAmericaSpecification();
    }
}

// Concrete Factory for Europe Cars
class EuropeCarFactory implements CarFactory {
    public Car createCar() { return new Hatchback(); }

    public CarSpecification createSpecification()
    {
        return new EuropeSpecification();
    }
}

// Abstract Product Interface for Cars
interface Car {
    void assemble();
}

// Abstract Product Interface for Car Specifications
interface CarSpecification {
    void display();
}

// Concrete Product for Sedan Car
class Sedan implements Car {
    public void assemble()
    {
        System.out.println("Assembling Sedan car.");
    }
}

// Concrete Product for Hatchback Car
class Hatchback implements Car {
    public void assemble()
    {
        System.out.println("Assembling Hatchback car.");
    }
}

// Concrete Product for North America Car Specification
class NorthAmericaSpecification
    implements CarSpecification {
    public void display()
    {
        System.out.println(
            "North America Car Specification: Safety features compliant with local regulations.");
    }
}

// Concrete Product for Europe Car Specification
class EuropeSpecification implements CarSpecification {
    public void display()
    {
        System.out.println(
            "Europe Car Specification: Fuel efficiency and emissions compliant with EU standards.");
    }
}

// Client Code
public class CarFactoryClient {
    public static void main(String[] args)
    {
        // Creating cars for North America
        CarFactory northAmericaFactory
            = new NorthAmericaCarFactory();
        Car northAmericaCar
            = northAmericaFactory.createCar();
        CarSpecification northAmericaSpec
            = northAmericaFactory.createSpecification();

        northAmericaCar.assemble();
        northAmericaSpec.display();

        // Creating cars for Europe
        CarFactory europeFactory = new EuropeCarFactory();
        Car europeCar = europeFactory.createCar();
        CarSpecification europeSpec
            = europeFactory.createSpecification();

        europeCar.assemble();
        europeSpec.display();
    }
}
```
Python
```
from abc import ABC, abstractmethod

# Abstract Products
class Car(ABC):
    @abstractmethod
    def assemble(self):
        pass


class CarSpecification(ABC):
    @abstractmethod
    def display(self):
        pass

# Concrete Products


class Sedan(Car):
    def assemble(self):
        print("Assembling Sedan car.")


class Hatchback(Car):
    def assemble(self):
        print("Assembling Hatchback car.")


class NorthAmericaSpecification(CarSpecification):
    def display(self):
        print("North America Car Specification: Safety features compliant with local regulations.")


class EuropeSpecification(CarSpecification):
    def display(self):
        print("Europe Car Specification: Fuel efficiency and emissions compliant with EU standards.")

# Abstract Factory


class CarFactory(ABC):
    @abstractmethod
    def create_car(self):
        pass

    @abstractmethod
    def create_specification(self):
        pass

# Concrete Factories


class NorthAmericaCarFactory(CarFactory):
    def create_car(self):
        return Sedan()

    def create_specification(self):
        return NorthAmericaSpecification()


class EuropeCarFactory(CarFactory):
    def create_car(self):
        return Hatchback()

    def create_specification(self):
        return EuropeSpecification()

# Client Code


def main():
    factory = NorthAmericaCarFactory()
    car = factory.create_car()
    spec = factory.create_specification()
    car.assemble()
    spec.display()

    factory = EuropeCarFactory()
    car = factory.create_car()
    spec = factory.create_specification()
    car.assemble()
    spec.display()


if __name__ == "__main__":
    main()
```
JavaScript
```
// Abstract Products
class Car {
    assemble() {}
}

class CarSpecification {
    display() {}
}

// Concrete Products
class Sedan extends Car {
    assemble() {
        console.log("Assembling Sedan car.");
    }
}

class Hatchback extends Car {
    assemble() {
        console.log("Assembling Hatchback car.");
    }
}

class NorthAmericaSpecification extends CarSpecification {
    display() {
        console.log("North America Car Specification: Safety features compliant with local regulations.");
    }
}

class EuropeSpecification extends CarSpecification {
    display() {
        console.log("Europe Car Specification: Fuel efficiency and emissions compliant with EU standards.");
    }
}

// Factories
class CarFactory {
    createCar() {}
    createSpecification() {}
}

class NorthAmericaCarFactory extends CarFactory {
    createCar() {
        return new Sedan();
    }
    createSpecification() {
        return new NorthAmericaSpecification();
    }
}

class EuropeCarFactory extends CarFactory {
    createCar() {
        return new Hatchback();
    }
    createSpecification() {
        return new EuropeSpecification();
    }
}

// Client Code
const northFactory = new NorthAmericaCarFactory();
let car = northFactory.createCar();
let spec = northFactory.createSpecification();
car.assemble();
spec.display();

const europeFactory = new EuropeCarFactory();
car = europeFactory.createCar();
spec = europeFactory.createSpecification();
car.assemble();
spec.display();
```
**Output**
```
Assembling Sedan car.
North America Car Specification: Safety features compliant with local regulations.
Assembling Hatchback car.
Europe Car Specification: Fuel efficiency and emissions compliant wit...
```

## Advantages

The Abstract Factory Pattern improves modularity, flexibility, and scalability in large systems.

- Promotes loose coupling between client and product classes.
- Makes switching product families easy without modifying client code.
- Supports Open/Closed Principle.

## Disadvantages

Although powerful, Abstract Factory can introduce complexity and additional overhead.

- Increases number of classes and interfaces.
- Can make the system more complex than necessary for small projects.
- Adding a new product type requires modifying the abstract factory interface.

What does the Abstract Factory Pattern provide?

- A
	A single method to calculate factorials
- B
	An interface to create families of related objects without specifying their concrete classes.
- C
	A way to speed up object creation using caching
- D
	A design to store multiple factory methods in one class

Abstract Factory Pattern belongs to which design pattern category?

- A
	Behavioral
- B
	Structural
- C
	Creational
- D
	Reactive

Which scenario is best solved by Abstract Factory?

- A
	Choosing between different sorting algorithms.
- B
	Creating UI widgets for Windows and MacOS environments.
- C
	Managing database queries.
- D
	Writing recursive functions.

How is Abstract Factory different from Factory Method?

- A
	Factory Method creates families, Abstract Factory creates single objects.
- B
	Abstract Factory creates families of related objects, while Factory Method creates one product at a time.
- C
	Both are identical.
- D
	Abstract Factory is not a design pattern.

Which real-world analogy best describes Abstract Factory?

- A
	A coffee machine that makes only espresso
- B
	A person buying a single pen from a shop.
- C
	A restaurant menu that allows you to order a full meal set (starter, main course, dessert) based on cuisine type
- D
	A calculator solving equations.

What is the main advantage of Abstract Factory Pattern?

- A
	Provides a way to enforce consistency among related objects
- B
	Increases memory usage.
- C
	Forces all classes to be abstract.
- D
	Eliminates the need for interfaces.

Why is Abstract Factory called a “factory of factories”?

In the car manufacturing example, what represents the Concrete Factory?

![[sucess-img 1.png|success]]

Quiz Completed Successfully

Score:0/8

Accuracy:0%