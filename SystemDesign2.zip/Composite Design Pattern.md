---
title: "Composite Design Pattern"
source: "https://www.geeksforgeeks.org/system-design/composite-method-software-design-pattern/"
author:
  - "[[GeeksforGeeks]]"
published: 2023-11-08
created: 2026-09-23
description: "Your All-in-One Learning Portal: GeeksforGeeks is a comprehensive educational platform that empowers learners across domains-spanning computer science and programming, school education, upskilling, commerce, software tools, competitive exams, and more."
tags:
  - "clippings"
---
The Composite Pattern is a [structural design pattern](https://www.geeksforgeeks.org/system-design/structural-design-patterns/) that organizes objects into tree structures, enabling clients to treat individual and composite objects uniformly through a common interface.

- Treats individual objects and groups uniformly using a common interface.
- Simplifies code and supports easy extension without modifying client logic.

> ****Example:**** In a file system, files (leaf nodes) and folders (composite nodes) share a common interface, allowing operations like display or delete to be performed uniformly on both individual items and groups.

![[composite_pattern.webp|composite_pattern]]

Composite Pattern

In the Diagram

- The Client interacts with the Component interface, allowing it to work with both Leaf and Composite objects uniformly.
- Leaf represents individual objects, while Composite represents a group of objects and can contain multiple children.
- The Composite recursively calls operations on its child components, forming a tree-like structure.

## Part-Whole or Whole-Part Object hierarchies

Part-Whole (Whole-Part) hierarchies represent complex objects (wholes) composed of simpler objects (parts). This structure allows both individual objects and groups of objects to be treated uniformly, often modeled using the Composite Pattern.

> ****Example: I**** n a graphic design application, you might have shapes as individual elements (like circles and rectangles), and you can combine these shapes to create more complex shapes (like a smiley face with eyes and a mouth). The Composite Pattern lets you work with both simple shapes and complex shapes using the same set of operations, making it easier to manage and manipulate them.

****In this context:****

- The parts are individual shapes (like circles, rectangles).
- The wholes are the complex shapes (like a smiley face composed of circles and rectangles).

## Real Life Example

The Composite Patternis useful in various scenarios, such as:

1. ****Graphics and GUI Libraries:**** Building complex graphical structures like shapes and groups.
2. ****File Systems:**** Representing files, directories, and their hierarchical relationships.
3. ****Organization Structures:**** Modeling hierarchical organizational structures like departments, teams and employees.

## Component

The Composite Pattern consists of key elements that allow treating individual objects and groups uniformly.

1. ****Component:**** The Component is the common interface for all objects in the composition. It defines the methods that are common to both leaf and composite objects.
2. ****Leaf:**** The Leaf is the individual object that does not have any children. It implements the component interface and provides the specific functionality for individual objects.
3. ****Composite:**** The Composite is the container object that can hold Leaf objects as well as the other Composite objects. It implements the Component interface and provides methods for adding, removing and accessing children.
4. ****Client:**** The Client is responsible for using the Component interface to work with objects in the composition. It treats both Leaf and Composite objects uniformly.

## Working

The Composite Pattern works by defining a common interface that is shared by both individual objects and groups of objects.

- The client interacts with objects through a common Component interface.
- Leaf objects perform the actual work, while Composite objects store and manage child components.
- When an operation is called on a composite, it forwards the request to its children recursively.

## Uses

The Composite Pattern is used when dealing with hierarchical structures.

- To represent part–whole hierarchies such as trees or nested structures.
- To allow clients to treat individual objects and collections uniformly.
- To simplify client code by avoiding checks for leaf or composite objects.

## Implementation Example

> You are tasked with developing a software component to manage a hierarchical file system structure. The goal is to implement the Composite Pattern to seamlessly work with individual files and directories as part of a unified hierarchy.

The practical application of the design pattern using code.

### 1\. Component

In the file system hierarchy example, the Component is represented by the FileSystemComponent interface. This interface defines the common interface for both leaf and composite objects. It declares a method, display(), which all classes in the hierarchy must implement.
C++
```
class FileSystemComponent {
public:
    virtual void display() const = 0;
};
```
Java
```
abstract class FileSystemComponent {
    public abstract void display();
}
```
Python
```
from abc import ABC, abstractmethod

class FileSystemComponent(ABC):
    @abstractmethod
    def display(self):
        pass
```
JavaScript
```
class FileSystemComponent {
    display() {
        throw new Error('Method not implemented.');
    }
}
```
The Component serves as the foundation for all objects within the hierarchy. Whether it's file or a directory, they all must adhere to this common interface.

### 2\. Leaf

In the context of our file system hierarchy example, Leaf objects are the individual files. These are the objects that do not have any children. Here is an implementation of a leaf object, a file:
C++
```
class File : public FileSystemComponent {
public:
    File(const std::string& name, int size) : name(name), size(size) {}

    void display() const override {
        std::cout << "File: " << name << " (" << size << " bytes)" << std::endl;
    }
private:
    std::string name;
    int size;
};
```
Java
```
public class File extends FileSystemComponent {
    private String name;
    private int size;

    public File(String name, int size) {
        this.name = name;
        this.size = size;
    }

    @Override
    public void display() {
        System.out.println("File: " + name + " (" + size + " bytes)");
    }
}
```
Python
```
class File(FileSystemComponent):
    def __init__(self, name, size):
        self.name = name
        self.size = size

    def display(self):
        print(f'File: {self.name} ({self.size} bytes)')
```
JavaScript
```
class File extends FileSystemComponent {
    constructor(name, size) {
        super();
        this.name = name;
        this.size = size;
    }

    display() {
        console.log(`File: ${this.name} (${this.size} bytes)`);
    }
}
```
Here, File is a leaf object. It implements the FileSystemComponent interface by providing a display method. It contains data specific to files, such as their name and size.

### 3\. Composite

In the file system hierarchy example, Composite objects are directories. These are objects that contain other components, including both leaf objects (files) and other composite objects (subdirectories). Here's an implementation of a composite object, a directory:
C++
```
class Directory : public FileSystemComponent {
public:
    Directory(const std::string& name) : name(name) {}

    void display() const override {
        std::cout << "Directory: " << name << std::endl;
        for (const auto& component : components) {
            component->display();
        }
    }

    void addComponent(FileSystemComponent* component) {
        components.push_back(component);
    }
private:
    std::string name;
    std::vector<FileSystemComponent*> components;
};
```
Java
```
import java.util.ArrayList;
import java.util.List;

abstract class FileSystemComponent {
    abstract void display();
}

class Directory extends FileSystemComponent {
    private String name;
    private List<FileSystemComponent> components = new ArrayList<>();

    public Directory(String name) {
        this.name = name;
    }

    @Override
    void display() {
        System.out.println("Directory: " + name);
        for (FileSystemComponent component : components) {
            component.display();
        }
    }

    public void addComponent(FileSystemComponent component) {
        components.add(component);
    }
}
```
Python
```
from abc import ABC, abstractmethod

class FileSystemComponent(ABC):
    @abstractmethod
    def display(self):
        pass

class Directory(FileSystemComponent):
    def __init__(self, name):
        self.name = name
        self.components = []

    def display(self):
        print(f'Directory: {self.name}')
        for component in self.components:
            component.display()

    def add_component(self, component):
        self.components.append(component)
```
JavaScript
```
class FileSystemComponent {
    constructor() {}
    display() {
        throw new Error('Method not implemented.');
    }
}

class Directory extends FileSystemComponent {
    constructor(name) {
        super();
        this.name = name;
        this.components = [];
    }

    display() {
        console.log(`Directory: ${this.name}`);
        this.components.forEach(component => component.display());
    }

    addComponent(component) {
        this.components.push(component);
    }
}
```
- Directory acts as a composite object that implements the FileSystemComponent interface and provides its own display method.
- It maintains a collection (vector) of FileSystemComponent objects to store files and subdirectories.
- The addComponent method allows adding child components, enabling a hierarchical file system structure.

### 4\. Client

The Client code interacts with the components through the Component interface, and it doesn't need to be aware of whether it's working with a leaf or a composite object.
C++
```
#include <iostream>
#include <vector>

class FileSystemComponent {
public:
    virtual void display() = 0;
};

class File : public FileSystemComponent {
private:
    std::string name;
    int size;
public:
    File(std::string name, int size) : name(name), size(size) {}
    void display() override {
        std::cout << "File: " << name << " Size: " << size << std::endl;
    }
};

class Directory : public FileSystemComponent {
private:
    std::string name;
    std::vector<FileSystemComponent*> components;
public:
    Directory(std::string name) : name(name) {}
    void addComponent(FileSystemComponent* component) {
        components.push_back(component);
    }
    void display() override {
        std::cout << "Directory: " << name << std::endl;
        for (auto component : components) {
            component->display();
        }
    }
};

int main() {
    // Create leaf objects (files)
    FileSystemComponent* file1 = new File("document.txt", 1024);
    FileSystemComponent* file2 = new File("image.jpg", 2048);

    // Create a composite object (directory)
    Directory directory("My Documents");

    // Add leaf objects to the directory
    directory.addComponent(file1);
    directory.addComponent(file2);

    // Display the directory (including its contents)
    directory.display();

    // Clean up
    delete file1;
    delete file2;
    return 0;
}
```
Java
```
import java.util.ArrayList;

interface FileSystemComponent {
    void display();
}

class File implements FileSystemComponent {
    private String name;
    private int size;

    public File(String name, int size) {
        this.name = name;
        this.size = size;
    }

    @Override
    public void display() {
        System.out.println("File: " + name + " Size: " + size);
    }
}

class Directory implements FileSystemComponent {
    private String name;
    private ArrayList<FileSystemComponent> components;

    public Directory(String name) {
        this.name = name;
        this.components = new ArrayList<>();
    }

    public void addComponent(FileSystemComponent component) {
        components.add(component);
    }

    @Override
    public void display() {
        System.out.println("Directory: " + name);
        for (FileSystemComponent component : components) {
            component.display();
        }
    }
}

public class Main {
    public static void main(String[] args) {
        // Create leaf objects (files)
        FileSystemComponent file1 = new File("document.txt", 1024);
        FileSystemComponent file2 = new File("image.jpg", 2048);

        // Create a composite object (directory)
        Directory directory = new Directory("My Documents");

        // Add leaf objects to the directory
        directory.addComponent(file1);
        directory.addComponent(file2);

        // Display the directory (including its contents)
        directory.display();
    }
}
```
Python
```
from abc import ABC, abstractmethod

class FileSystemComponent(ABC):
    @abstractmethod
    def display(self):
        pass

class File(FileSystemComponent):
    def __init__(self, name, size):
        self.name = name
        self.size = size

    def display(self):
        print(f'File: {self.name} Size: {self.size}')

class Directory(FileSystemComponent):
    def __init__(self, name):
        self.name = name
        self.components = []

    def add_component(self, component):
        self.components.append(component)

    def display(self):
        print(f'Directory: {self.name}')
        for component in self.components:
            component.display()

if __name__ == '__main__':
    # Create leaf objects (files)
    file1 = File('document.txt', 1024)
    file2 = File('image.jpg', 2048)

    # Create a composite object (directory)
    directory = Directory('My Documents')

    # Add leaf objects to the directory
    directory.add_component(file1)
    directory.add_component(file2)

    # Display the directory (including its contents)
    directory.display()
```
JavaScript
```
from abc import ABC, abstractmethod

class FileSystemComponent(ABC):
    @abstractmethod
    def display(self):
        pass

class File(FileSystemComponent):
    def __init__(self, name, size):
        self.name = name
        self.size = size

    def display(self):
        print(f'File: {self.name} Size: {self.size}')

class Directory(FileSystemComponent):
    def __init__(self, name):
        self.name = name
        self.components = []

    def add_component(self, component):
        self.components.append(component)

    def display(self):
        print(f'Directory: {self.name}')
        for component in self.components:
            component.display()

if __name__ == '__main__':
    # Create leaf objects (files)
    file1 = File('document.txt', 1024)
    file2 = File('image.jpg', 2048)

    # Create a composite object (directory)
    directory = Directory('My Documents')

    # Add leaf objects to the directory
    directory.add_component(file1)
    directory.add_component(file2)

    # Display the directory (including its contents)
    directory.display()
```
In this client code, you can see how the client interacts with both leaf (file) and composite (directory) objects uniformly, without needing to know the specific type of each object.

### Complete code of the above Problem
C++
```
#include <bits/stdc++.h>
class FileSystemComponent {
public:
    virtual void display() const = 0;
};
class File : public FileSystemComponent {
public:
    File(const std::string& name, int size)
        : name(name)
        , size(size)
    {
    }

    void display() const override
    {
        std::cout << "File: " << name << " (" << size
                  << " bytes)" << std::endl;
    }

private:
    std::string name;
    int size;
};
class Directory : public FileSystemComponent {
public:
    Directory(const std::string& name)
        : name(name)
    {
    }

    void display() const override
    {
        std::cout << "Directory: " << name << std::endl;
        for (const auto& component : components) {
            component->display();
        }
    }

    void addComponent(FileSystemComponent* component)
    {
        components.push_back(component);
    }

private:
    std::string name;
    std::vector<FileSystemComponent*> components;
};
int main()
{
    // Create leaf objects (files)
    FileSystemComponent* file1
        = new File("document.txt", 1024);
    FileSystemComponent* file2
        = new File("image.jpg", 2048);

    // Create a composite object (directory)
    Directory* directory = new Directory("My Documents");

    // Add leaf objects to the directory
    directory->addComponent(file1);
    directory->addComponent(file2);

    // Display the directory (including its contents)
    directory->display();

    return 0;
}
```
Java
```
import java.util.ArrayList;
import java.util.List;

// Abstract class for FileSystemComponent
abstract class FileSystemComponent {
    public abstract void display();
}

// Concrete class for File
class File extends FileSystemComponent {
    private String name;
    private int size;

    public File(String name, int size) {
        this.name = name;
        this.size = size;
    }

    @Override
    public void display() {
        System.out.println("File: " + name + " (" + size + " bytes)");
    }
}

// Concrete class for Directory
class Directory extends FileSystemComponent {
    private String name;
    private List<FileSystemComponent> components;

    public Directory(String name) {
        this.name = name;
        this.components = new ArrayList<>();
    }

    @Override
    public void display() {
        System.out.println("Directory: " + name);
        for (FileSystemComponent component : components) {
            component.display();
        }
    }

    public void addComponent(FileSystemComponent component) {
        components.add(component);
    }
}

public class Main {
    public static void main(String[] args) {
        // Create leaf objects (files)
        FileSystemComponent file1 = new File("document.txt", 1024);
        FileSystemComponent file2 = new File("image.jpg", 2048);

        // Create a composite object (directory)
        Directory directory = new Directory("My Documents");

        // Add leaf objects to the directory
        directory.addComponent(file1);
        directory.addComponent(file2);

        // Display the directory (including its contents)
        directory.display();
    }
}
```
Python
```
from abc import ABC, abstractmethod

# Abstract class for FileSystemComponent
class FileSystemComponent(ABC):
    @abstractmethod
    def display(self):
        pass

# Concrete class for File
class File(FileSystemComponent):
    def __init__(self, name, size):
        self.name = name
        self.size = size

    def display(self):
        print(f'File: {self.name} ({self.size} bytes)')

# Concrete class for Directory
class Directory(FileSystemComponent):
    def __init__(self, name):
        self.name = name
        self.components = []

    def display(self):
        print(f'Directory: {self.name}')
        for component in self.components:
            component.display()

    def add_component(self, component):
        self.components.append(component)

# Main function
if __name__ == '__main__':
    # Create leaf objects (files)
    file1 = File('document.txt', 1024)
    file2 = File('image.jpg', 2048)

    # Create a composite object (directory)
    directory = Directory('My Documents')

    # Add leaf objects to the directory
    directory.add_component(file1)
    directory.add_component(file2)

    # Display the directory (including its contents)
    directory.display()
```
JavaScript
```
'use strict';

// Abstract class for FileSystemComponent
class FileSystemComponent {
    constructor() {
        if (new.target === FileSystemComponent) {
            throw new TypeError('Cannot construct FileSystemComponent instances directly');
        }
    }

    display() {
        throw new Error('Method display() must be implemented.');
    }
}

// Concrete class for File
class File extends FileSystemComponent {
    constructor(name, size) {
        super();
        this.name = name;
        this.size = size;
    }

    display() {
        console.log(`File: ${this.name} (${this.size} bytes)`);
    }
}

// Concrete class for Directory
class Directory extends FileSystemComponent {
    constructor(name) {
        super();
        this.name = name;
        this.components = [];
    }

    display() {
        console.log(`Directory: ${this.name}`);
        for (const component of this.components) {
            component.display();
        }
    }

    add_component(component) {
        this.components.push(component);
    }
}

// Main function
(function () {
    // Create leaf objects (files)
    const file1 = new File('document.txt', 1024);
    const file2 = new File('image.jpg', 2048);

    // Create a composite object (directory)
    const directory = new Directory('My Documents');

    // Add leaf objects to the directory
    directory.add_component(file1);
    directory.add_component(file2);

    // Display the directory (including its contents)
    directory.display();
})();
```
**Output**
```
Directory: My Documents
File: document.txt (1024 bytes)
File: image.jpg (2048 bytes)
```

## Advantages

The Composite Pattern offers several benefits when working with hierarchical object structures.

- ****Hierarchical Structure****: Represents objects in tree-like hierarchies, treating individuals and composites uniformly.
- ****Simplified Client Code****: Clients interact with objects without distinguishing between single or composite ones.
- ****Flexibility****: Easily add or remove objects without affecting client code.
- ****Code Reusability****: Same operations apply to both parts and wholes, reducing duplication.

## Disadvantages

Despite its benefits, the Composite Pattern also has some drawbacks.

- ****Complex Implementation****: Requires a common interface for all objects, making code more intricate.
- ****Performance Overhead****: Traversing deep hierarchies can slow operations.
- ****Limited Type Safety****: Common interface may allow invalid operations, risking runtime errors.
- ****Extra Memory Usage****: Storing child references increases memory consumption.

What does the Composite Design Pattern primarily deal with?

- A
	Object creation
- B
	Object behavior
- C
	Part-whole hierarchies
- D
	Object lifecycle

Which role defines the common interface in the Composite Pattern?

- A
	Leaf
- B
	Composite
- C
	Component
- D
	Client

Which object in the Composite Pattern can contain children?

- A
	Leaf
- B
	Composite
- C
	Component
- D
	Client

Which object represents indivisible elements in the Composite Pattern?

What is the main benefit of the Composite Pattern?

In the file system example, what role does File play?

What happens when an operation is called on a Composite object?

- A
	It ignores child components
- B
	It performs the operation and recursively calls it on its children
- C
	It deletes its children
- D
	It converts into a leaf

![[sucess-img 14.png|success]]

Quiz Completed Successfully

Score:0/7

Accuracy:0%