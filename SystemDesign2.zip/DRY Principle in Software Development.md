---
title: "DRY Principle in Software Development"
source: "https://www.geeksforgeeks.org/software-engineering/dont-repeat-yourselfdry-in-software-development/"
author:
  - "[[GeeksforGeeks]]"
published: 2024-02-14
created: 2026-09-23
description: "Your All-in-One Learning Portal: GeeksforGeeks is a comprehensive educational platform that empowers learners across domains-spanning computer science and programming, school education, upskilling, commerce, software tools, competitive exams, and more."
tags:
  - "clippings"
---
DRY (Don’t Repeat Yourself) is a [software development principle](https://www.geeksforgeeks.org/software-engineering/modern-principles-of-software-development/) that avoids duplication of logic by promoting reusable components and code. It ensures changes are made in one place, improving maintainability and consistency. DRY works with modular design and SRP to build scalable and efficient systems.

- Promotes code reuse by reducing duplication and ensuring consistency across the codebase.
- Centralizes logic to minimize errors, simplify updates, and support SRP for better system design.

> ****Example:**** Without DRY, email validation logic is duplicated in multiple functions, so any change must be made in several places. With DRY, the validation logic is written once in a single function and reused everywhere, making maintenance easier.

## Real-World Applications

In real-world applications, DRY is applied to areas where the same logic or rules are used repeatedly across the system.

- Utility and helper classes centralize commonly used functions like string handling, date formatting, or calculations.
- Validation logic and business rules are reused across multiple modules to ensure consistent behavior.
- Logging, exception handling, and configuration management are shared to avoid duplicated setup and inconsistent handling.

## Approaches to Resolving Duplication by DRY

These approaches help identify and eliminate repeated logic by promoting reuse and better code organization.

- ****Create Functions or Methods:**** Identify repeated logic and encapsulate it in functions or methods that can be called from multiple locations.
- ****Use Classes and Inheritance:**** For more complex scenarios, use classes and inheritance to create reusable components that share common functionality.
- ****Extract Constants or Configurations:**** If certain constants or configurations are repeated, centralize them to a single source to avoid redundancy.
- ****Modularization:**** Break down the code into modular components, each responsible for a specific task. This promotes reusability and modularity.

## Features

The features of the DRY principle in software development include:

![[code_reusability.webp|code_reusability]]

Features

- ****Code Reusability:**** Encourages creating reusable components, reducing redundancy across the codebase and improving development efficiency across multiple modules.
- ****Easier Maintenance:**** Centralizing logic minimizes bugs and makes updates efficient, as changes need to be made in only one place instead of multiple locations.
- ****Improved Readability:**** Eliminates repetition, making code easier to understand, navigate, and maintain for developers working on the system.
- ****Faster Development:**** Reusing code saves time, especially in large projects, by avoiding repeated implementation of the same logic.
- ****Consistency:**** Ensures uniform behavior by encapsulating functionality in one place, reducing inconsistencies across different parts of the system.
- ****Better Collaboration:**** Enables multiple developers to work independently without conflicts, as shared logic is clearly defined and reusable.
- ****Avoids Copy-Paste Errors:**** Reduces mistakes caused by duplicated code, ensuring that bugs are not repeated across multiple sections.
- ****Enhanced Testability:**** Simplifies unit testing and limits unintended side effects by isolating logic into reusable and testable components.

## Implementation Example

Consider a scenario where the same validation logic for email addresses is required in multiple parts of your code:
C++
```
#include <iostream>
#include <string>
using namespace std;

// Without DRY (duplicated logic)
bool validate_email_format_1(const string& email) {
    return email.find("@") != string::npos &&
           email.find(".") != string::npos;
}

bool validate_email_format_2(const string& email) {
    return email.find("@") != string::npos &&
           email.find(".") != string::npos;
}

// With DRY (single reusable function)
bool validate_email_format(const string& email) {
    return email.find("@") != string::npos &&
           email.find(".") != string::npos;
}

int main() {
    string email1 = "user@example.com";
    string email2 = "invalidemail";

    // Without DRY usage
    cout << "Without DRY validation 1: "
         << validate_email_format_1(email1) << endl;

    cout << "Without DRY validation 2: "
         << validate_email_format_2(email2) << endl;

    // With DRY usage
    cout << "With DRY validation: "
         << validate_email_format(email1) << endl;

    return 0;
}
```
Java
```
import java.util.*;

// Without DRY (duplicated logic)
public class Main {
    public static boolean validateEmailFormat1(String email) {
        return email.contains("@") && email.contains(".");
    }

    public static boolean validateEmailFormat2(String email) {
        return email.contains("@") && email.contains(".");
    }

    // With DRY (single reusable function)
    public static boolean validateEmailFormat(String email) {
        return email.contains("@") && email.contains(".");
    }

    public static void main(String[] args) {
        String email1 = "user@example.com";
        String email2 = "invalidemail";

        // Without DRY usage
        System.out.println("Without DRY validation 1: " + validateEmailFormat1(email1));
        System.out.println("Without DRY validation 2: " + validateEmailFormat2(email2));

        // With DRY usage
        System.out.println("With DRY validation: " + validateEmailFormat(email1));
    }
}
```
Python
```
# Without DRY (duplicated logic)
def validate_email_format_1(email):
    return '@' in email and '.' in email

def validate_email_format_2(email):
    return '@' in email and '.' in email

# With DRY (single reusable function)
def validate_email_format(email):
    return '@' in email and '.' in email

if __name__ == '__main__':
    email1 = 'user@example.com'
    email2 = 'invalidemail'

    print('Without DRY validation 1:', validate_email_format_1(email1))
    print('Without DRY validation 2:', validate_email_format_2(email2))
    print('With DRY validation:', validate_email_format(email1))
```
JavaScript
```
"use strict";

// Without DRY (duplicated logic)
function validateEmailFormat1(email) {
    return email.includes('@') && email.includes('.');
}

function validateEmailFormat2(email) {
    return email.includes('@') && email.includes('.');
}

// With DRY (single reusable function)
function validateEmailFormat(email) {
    return email.includes('@') && email.includes('.');
}

(function() {
    const email1 = 'user@example.com';
    const email2 = 'invalidemail';

    // Without DRY usage
    console.log('Without DRY validation 1:', validateEmailFormat1(email1));
    console.log('Without DRY validation 2:', validateEmailFormat2(email2));

    // With DRY usage
    console.log('With DRY validation:', validateEmailFormat(email1));
})();
```
**Output**
```
Without DRY validation 1: 1
Without DRY validation 2: 0
With DRY validation: 1
```

In the non-DRY example, the same validation logic is repeated in multiple functions. With DRY, the validation logic is encapsulated in a single function, promoting code reuse and reducing redundancy.

## DRY Violations

DRY violations occur when the same logic or knowledge is repeated in multiple places instead of being centralized. These issues often increase maintenance effort and the risk of inconsistent behavior.

- Copy-pasting the same logic into multiple methods or classes leads to multiple points of change when requirements evolve.
- Repeating the same business rules across layers like controller, service, and DAO causes inconsistency and tight coupling.
- Hard-coding the same values or configurations in different files makes updates error-prone and difficult to track.

## DRY and SOLID Principles

DRY works closely with the Single Responsibility Principle (SRP) to improve code maintainability and reduce the impact of changes. Both principles focus on organizing code so that changes are predictable and localized.

- SRP ensures that a class or module has only one reason to change.
- DRY ensures that this reason to change exists in only one place in the codebase.
- Together, they reduce ripple effects when requirements change and make refactoring safer.

## Limitations

Although DRY is important, applying it blindly can lead to over-engineering and complex designs.

- When duplication is accidental and the code is likely to change differently in the future.
- When creating abstractions adds more complexity than the duplicated code itself.
- In very small or experimental code where simplicity is more important than reuse.

Which statement best defines the DRY principle?

- A
	Writing shorter code using fewer lines
- B
	Avoiding repetition of logic or knowledge in a system
- C
	Using only object-oriented programming
- D
	Avoiding comments in code

Which practice best follows the DRY principle?

- Writing the same logic in multiple modules
- Centralizing shared logic in a reusable component
- Creating separate implementations for each feature
- Duplicating code to improve readability

Which of the following is a common DRY violation?

- A
	Creating reusable utility functions
- B
	Encapsulating validation logic in one method
- C
	Copy-pasting the same business rule in multiple layers
- D
	Using configuration files

Which approach helps implement DRY effectively?

- A
	Hard-coding values in different classes
- B
	Repeating validation logic in controllers
- C
	Writing longer methods to avoid function calls
- D
	Creating reusable functions for repeated logic

How does DRY relate to the Single Responsibility Principle (SRP)?

- A
	DRY increases code duplication to improve flexibility
- B
	Both eliminate the need for modularization
- C
	SRP ensures one reason to change, DRY ensures that change happens in one place
- D
	They are unrelated concepts

Which scenario represents proper use of DRY?

- A
	Repeating email validation logic in every service
- B
	Writing a single email validation function and reusing it everywhere
- C
	Embedding validation rules inside UI code only
- D
	Avoiding validation to reduce duplication

When should DRY be applied carefully or avoided?

![[sucess-img 34.png|success]]

Quiz Completed Successfully

Score:0/7

Accuracy:0%