---
title: "Gang of Four (GOF)  Design Patterns"
source: "https://www.geeksforgeeks.org/system-design/gang-of-four-gof-design-patterns/"
author:
  - "[[GeeksforGeeks]]"
published: 2023-09-27
created: 2026-09-23
description: "Your All-in-One Learning Portal: GeeksforGeeks is a comprehensive educational platform that empowers learners across domains-spanning computer science and programming, school education, upskilling, commerce, software tools, competitive exams, and more."
tags:
  - "clippings"
---
The Gang of Four Design Patterns is a set of solutions to common problems we encounter in software design and development. The term comes from the authors of the famous book “Design Patterns: Elements of Reusable Object-Oriented Software” by Erich Gamma, Richard Helm, Ralph Johnson, and John Vlissides, who are collectively known as Gang of Four.

- GoF introduced 23 classic design patterns that help solve common problems in object-oriented software.
- These patterns provide solutions to common design problems and help make software systems more modular, flexible and maintainable.

## Types of GOF Design Patterns

These patterns are divided into three categories:

- ****Creational:**** Deal with object creation (e.g., Singleton, Factory, Builder).
- ****Structural:**** Deal with composition of classes/objects (e.g., Adapter, Decorator, Facade).
- ****Behavioral:**** Deal with object interaction and communication (e.g., Observer, Strategy, State).

## 1\. Creational Design Patterns

[Creational Design Patterns](https://www.geeksforgeeks.org/system-design/creational-design-pattern/) are design patterns that provide standard ways to create objects while hiding the details of object creation from the client code. They make object creation more flexible, reusable, and maintainable.

> ****Real-World Example:**** Think of ordering a Pizza at a restaurant. You simply choose the type of pizza you want, such as Margherita or Farmhouse. You do not need to know how the chef prepares the dough, adds toppings, or bakes the pizza. The chef handles all these steps for you.

### Types

![[type-creation-design-pattern 1.webp|type-creation-design-pattern]]

****1\. Factory Method:**** Defines an interface for creating objects but lets subclasses decide which specific object to instantiate. This provides flexibility and reduces tight coupling between code that uses objects and code that creates them.

> *****Example:***** A payment system creates different payment objects (UPI, Card) based on user choice without exposing creation logic.

****2\. Abstract Factory:**** Provides an interface to create families of related or dependent objects without specifying their concrete classes. It ensures that products from the same family work together seamlessly.

> *****Example:*****A UI toolkit generates complete sets of components (buttons, menus) for Windows or Mac without mixing styles.

****3\. Singleton:**** Ensures a class has only one instance and provides a global point of access to it. Useful for managing shared resources or controlling access to a single object in the system.

> *****Example:***** A database connection manager ensures only one shared instance is used across the application.

****4\. Prototype:**** Creates new objects by cloning an existing instance. This is useful when creating an object from scratch is costly or complex, and you only need a slight variation of an existing object.

> *****Example:***** A user profile template is cloned to quickly create new users with similar default settings.

****5\. Builder:**** Separates the construction of a complex object from its representation, allowing you to create objects step by step. This is ideal when an object needs multiple configurations or variants.

> *****Example:***** A food ordering app lets users build a burger step-by-step with custom ingredients and options.

## 2\. Structural Design Patterns

[Structural Design Patterns](https://www.geeksforgeeks.org/system-design/structural-design-patterns/) provide standard ways to combine classes and objects to form larger and more flexible structures. They focus on how different components are connected and work together.

> ****Real-World Example:**** Think of building a house using different parts such as doors, windows, walls, and rooms. These parts are combined in a planned way so they work together as a complete house. If needed, one part can also be replaced without rebuilding the entire house.

### Types

![[types_of_STRUCTURAL 1.webp|types_of_STRUCTURAL]]

****1\. Adapter Pattern:**** Lets classes with incompatible interfaces work together by acting as a bridge. It converts one interface into another that a client expects.

> *****Example:***** A charger adapter converts one interface (Type-C) to another (Lightning) so incompatible devices can work together.

****2\. Bridge Pattern:**** Separates an object's abstraction (what it does) from its implementation (how it does it). This allows both to change independently without affecting each other.

> *****Example:***** A remote control works with different TVs, allowing both remote types and TV brands to vary independently.

****3\. Composite Pattern:**** Lets you create hierarchical structures of objects while treating individual and composite objects uniformly. Ideal for trees or part-whole hierarchies.

> *****Example:***** A file system treats files and folders uniformly, allowing nested structures to be handled the same way.

****4\. Decorator Pattern:**** Adds new behavior or responsibilities to objects without modifying their code. Think of it as layering extra functionality around an object.

> *****Example:***** Extra toppings are added to a pizza dynamically without changing the original pizza object.

****5\. Facade Pattern:**** Provides a simplified interface to a complex system, hiding its inner complexity and making it easier to use.

> *****Example:***** A booking app provides a simple interface while handling complex backend services like payment and seat allocation.

****6\. Flyweight Pattern:**** Reduces memory usage by sharing common objects instead of creating duplicates. Only new objects are created when needed.

> *****Example:***** A text editor shares common font objects instead of creating new ones for every character to save memory.

****7\. Proxy Pattern:**** Acts as a placeholder or surrogate for another object to control access, delay creation, or add extra functionality. Like a remote control for a TV.

> *****Example:***** An ATM acts as a proxy between the user and bank server, controlling access and processing requests.

## 3\. Behavioral Design Patterns

[Behavioral Design Patterns](https://www.geeksforgeeks.org/system-design/behavioral-design-patterns/) define standard ways for objects to communicate and interact with each other. They help distribute responsibilities and manage the behavior of objects in a flexible way.

> ****Real-World Example:**** Think of a restaurant where the customer, waiter, and chef have different responsibilities. The customer places an order with the waiter, and the waiter communicates it to the chef. Each person handles their own task while working together to complete the order.

### Types

![[behavioral_design_patterns.webp|behavioral_design_patterns]]

****1\. Chain of Responsibility Pattern:**** Pass a request along a chain of objects. Each object can handle it or pass it on, making the code modular and flexible.

> *****Example:***** A customer support request moves through levels (L1 -> L2 -> L3) until it gets resolved.

****2\. Command Pattern:**** Encapsulates a request as an object, decoupling the sender from the receiver and allowing actions to be managed or queued easily.

> *****Example:***** A remote control button sends commands to devices (TV, AC) without knowing how they execute them.

****3\. Interpreter Pattern:**** Defines a grammar and provides a way to interpret and evaluate expressions written in that language.

> *****Example:***** A SQL engine interprets queries and executes them based on defined grammar rules.

****4\. Iterator Pattern:**** Lets you access elements in a collection sequentially without exposing its internal structure.

> *****Example:***** A music app lets you go through songs one by one without exposing the playlist’s internal structure.

****5\. Mediator Pattern:**** Centralizes communication between objects, reducing dependencies and simplifying interactions.

> *****Example:***** An air traffic controller manages communication between planes to avoid direct complex interactions.

****6\. Memento Pattern:**** Captures an object’s state and allows it to be restored later, like saving and loading a snapshot.

> *****Example:***** A text editor saves previous states so users can undo or redo changes.

****7\. Observer Pattern:**** One object (subject) notifies multiple observers of changes, enabling dynamic updates.

> *****Example:***** Users get notified when a YouTube channel uploads a video or when stock prices change.

****8\. State Pattern:**** Lets an object change its behavior dynamically based on its current internal state.

> *****Example:***** A traffic light changes behavior (red, yellow, green) based on its current state.

****9\. Strategy Pattern:**** Defines a family of algorithms and allows switching between them at runtime for flexibility.

> *****Example:***** A payment system allows switching between payment methods like UPI, card, or wallet dynamically.

****10\. Template Method Pattern:**** Provides a fixed algorithm structure while allowing subclasses to override specific steps.

> *****Example:***** An online order follows fixed steps (select -> pay -> deliver) while allowing variations in each step.

****11\. Visitor Pattern:**** Adds new operations to object structures without modifying the objects themselves.

> *****Example:***** A tax system applies different tax calculations to items without modifying their classes.

Why were the Gang of Four (GoF) Design Patterns introduced?

- A
	To replace object-oriented programming
- B
	To provide solutions to common software design problems
- C
	To improve database performance
- D
	To reduce hardware cost

Which category of design patterns focuses on object creation?

Which pattern ensures that a class has only one instance in the system?

Which Structural Pattern provides a simplified interface to a complex subsystem?

Which pattern allows incompatible interfaces to work together?

Which Behavioral Pattern allows switching between algorithms at runtime?

![[sucess-img 48.png|success]]

Quiz Completed Successfully

Score:0/6

Accuracy:0%