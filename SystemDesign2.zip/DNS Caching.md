---
title: "DNS Caching"
source: "https://www.geeksforgeeks.org/computer-networks/what-is-dns-caching/"
author:
  - "[[GeeksforGeeks]]"
published: 2024-10-08
created: 2026-09-23
description: "Your All-in-One Learning Portal: GeeksforGeeks is a comprehensive educational platform that empowers learners across domains-spanning computer science and programming, school education, upskilling, commerce, software tools, competitive exams, and more."
tags:
  - "clippings"
---
DNS caching is a temporary storage system that stores recent domain-to-IP mappings to speed up future lookups. Instead of querying DNS servers every time, the system first checks the cache to reduce lookup time.

- Stores previously resolved domain names (e.g., google.com -> IP address) for faster access.
- Reduces DNS server load and improves overall browsing performance and efficiency.

> ****Example****
> 
> - When you visit a website like [www.GeeksforGeeks.com](http://www.geeksforgeeks.com/), your system resolves its IP (e.g., 172.217.0.46) and stores it in the DNS cache temporarily.
> - If you revisit the same site within the TTL period, the system uses the cached IP instead of querying DNS again, resulting in faster loading and reduced network traffic.

![[dns_1.webp|dns_1]]

When the DNS query is made for the first time, the DNS resolver must go through several steps to retrieve its corresponding IP address from the authoritative DNS server. Once this information is obtained, it will stored in the cache memory, so that the subsequent requests for the same domain name can serve more quickly without the need to repeat the entire lookup process.

![[dns_2.webp|dns_2]]

## Working

DNS caching temporarily stores IP addresses of domain names to speed up future requests.

- ****First Request:**** When you visit a website (e.g., example.com), your system queries a DNS server for its IP address.
- ****Cache Storage:**** The IP address is saved locally—on your device, router, or ISP’s servers—for a set duration defined by TTL (Time to Live).
- ****Subsequent Requests:**** Future visits to example.com use the cached IP, skipping the DNS lookup and making the connection faster.

## DNS Cache Hierarchy

[DNS](https://www.geeksforgeeks.org/computer-networks/domain-name-system-dns-in-application-layer/) caching occurs at multiple levels, forming a hierarchy that optimizes performance and reduces repeated DNS lookups.

- ****Browser Cache:**** The first layer of caching happens in the web browser. It stores recently accessed domain-to-IP mappings for quick retrieval.
- ****Operating System (OS) Cache:**** If the browser cache doesn’t have the record, the OS cache is checked. The OS maintains a local cache of DNS records retrieved by applications, including browsers.
- ****DNS Resolver Cache:**** If the OS cache lacks the record, the request is sent to the DNS resolver cache, usually maintained by your ISP or a third-party DNS service.
- ****Authoritative DNS Server:**** If no cache has the record, the resolver queries the authoritative DNS server, which holds the definitive DNS records for the domain.
![[dns_3.webp|dns_3]]

Hierarchy of DNS Cache

## TTL (Time to Live) in DNS Caching

TTL determines how long a DNS record remains valid in cache before it must be refreshed or discarded. It is measured in seconds and plays a key role in caching efficiency and accuracy.

****Functions of TTL in DNS Caching****: TTL (Time-to-Live) helps manage how long DNS records are stored in cache, ensuring both speed and data accuracy.

- ****Setting the TTL:**** The authoritative DNS server sets the TTL for each record.
- ****Caching and Countdown:**** Once a DNS query is resolved, the TTL countdown starts. After expiration, the cached record is discarded, triggering a fresh DNS lookup.

****Importance****: TTL plays a key role in balancing DNS lookup speed and ensuring data accuracy.

- Reduces the time needed for repeated DNS lookups
- Ensures timely updates to DNS records
- Prevents outdated data while maintaining fast access

## Benefits

The benefits of DNS caching are:

- ****Faster Website Loading Times:**** It eliminates repetitive [DNS lookups](https://www.geeksforgeeks.org/computer-networks/dns-look-up/) and allows web pages to load quickly on subsequent visits.
- ****Reduced Network Traffic:**** Caching minimizes DNS queries. This decreases the load on the both local networks and the external DNS servers.
- ****Lower Load on DNS Servers:**** With some queries reaching the authoritative DNS servers, the risk of the server overload or slow response times is minimized.

## Layers of DNS Caching

DNS caching occurs at different layers in the system to improve performance and reduce repeated DNS lookups.

- ****Router-Level DNS Caching:**** Routers cache DNS queries locally for connected devices, reducing external DNS requests and improving network efficiency.
- ****DNS Resolver (ISP/Third-Party) Caching:**** DNS resolvers cache responses for multiple users, reducing the need to query authoritative servers repeatedly and improving resolution speed.
- ****Content Delivery Network (CDN) Caching:**** CDNs cache content and help route users to the nearest server, reducing latency and improving load times.
- ****Host File Caching:**** The hosts file acts as a manual override, allowing systems to resolve domain names before making any DNS query.

## Flushing of DNS Cache

Flushing the DNS cache clears stored DNS records, helping to resolve issues like outdated or incorrect IP mappings.

****1\. Browser-Level DNS Cache Flush (Chrome)****: This clears cached DNS records stored by the browser to ensure it fetches fresh data.

- Open Chrome and go to: `chrome://net-internals/#dns`
- Click the Clear host cache button

****2\. Operating System-Level DNS Cache Flush (Windows)****: This clears the DNS records stored by the operating system to ensure that new domain resolutions are fetched.

- Open Command Prompt as an administrator
- Type `ipconfig /flushdns` and press Enter
- You should see the confirmation: **"Successfully flushed the DNS Resolver Cache"**

> Read in detail about [When and How to Flush DNS Cache](https://www.geeksforgeeks.org/blogs/how-to-flush-dns-cache/).

## Best Practices for DNS Caching Management

Effective DNS caching management ensures fast, reliable, and up-to-date domain resolution across your systems.

- ****Set Appropriate TTL Values:**** Choose TTLs that balance performance and data freshness. Shorter TTLs allow quick propagation of updates, while longer TTLs reduce DNS queries and improve caching efficiency.
- ****Regular Cache Flushing:**** Schedule periodic DNS cache flushing, especially in environments where DNS records change frequently. This helps prevent issues caused by stale or outdated records.
- ****Use Reliable DNS Servers:**** Configure multiple DNS servers to ensure redundancy and avoid single points of failure.

## DNS Caching Security

Securing DNS caching is essential to protect against attacks and ensure the integrity of domain name resolutions.

- ****Protect Against DNS Cache Poisoning:**** Use DNSSEC to verify the authenticity and integrity of DNS responses, preventing malicious alterations.
- ****Mitigate DNS Amplification Attacks:**** Implement rate limiting on DNS queries to prevent attackers from exploiting your servers for amplification attacks.
- ****Prevent Unauthorized DNS Changes:**** Ensure that only authorized personnel can modify DNS records, using secure methods like multi-factor authentication and encrypted communication channels.

What is DNS caching?

- A
	A system that permanently stores IP addresses
- B
	A temporary storage of domain-to-IP mappings for faster access
- C
	A method to block websites
- D
	A way to increase internet speed manually

What happens when you visit a website for the second time within TTL?

- A
	DNS lookup happens again from scratch
- B
	The request is blocked
- C
	The cached IP address is used
- D
	The browser crashes

What is the role of TTL in DNS caching?

- A
	It deletes websites permanently
- B
	It determines how long a DNS record stays in cache
- C
	It increases bandwidth
- D
	It encrypts DNS data

Which layer is checked first in the DNS cache hierarchy?

Why is DNS caching important?

- A
	It ensures DNS records are always up to date
- B
	It encrypts DNS queries for better security
- C
	It reduces lookup time and network traffic
- D
	It permanently stores DNS records on the device

![[sucess-img 32.png|success]]

Quiz Completed Successfully

Score:0/5

Accuracy:0%