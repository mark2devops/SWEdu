---
title: "Building AI Agents"
source: "https://www.geeksforgeeks.org/artificial-intelligence/building-ai-agents/"
author:
  - "[[GeeksforGeeks]]"
published: 2025-07-05
created: 2026-09-23
description: "Your All-in-One Learning Portal: GeeksforGeeks is a comprehensive educational platform that empowers learners across domains-spanning computer science and programming, school education, upskilling, commerce, software tools, competitive exams, and more."
tags:
  - "clippings"
---
Building AI agents means creating software that can perform tasks intelligently and autonomously. This involves defining what the agent should do, training it with data and using technologies like machine learning and natural language processing. The goal is to make the agent capable of understanding instructions, learning from experience and improving its performance over time.

## Agents & Agentic systems

- An AI agent is a system where a [large language model](https://www.geeksforgeeks.org/artificial-intelligence/large-language-model-llm/) (LLM) autonomously directs its own processes and tool usage to accomplish tasks, as opposed to a workflow, which follows predefined code paths and orchestrates LLMs and tools in a fixed sequence.
- Agents are best for tasks requiring flexibility, dynamic decision-making and adaptability, while workflows suit predictable, well-defined tasks.

## Core Principles for Building AI Agents

- ****Start Simple****: Begin with the least complex solution often a single LLM call or a basic workflow. Only introduce agentic complexity when the task requires more flexibility or dynamic decision-making.
- ****Agent vs. Workflow****: Use agents for open-ended, dynamic tasks where the steps aren’t predetermined. Use workflows for structured, predictable processes.
- ****Composable Patterns****: Build agents from simple, composable workflow patterns, which can be combined as needed for more complex applications.

## Fundamental Workflow Patterns

Anthropic identifies five foundational patterns for constructing AI agents.

### Prompt Chaining

![[Prompt-Chaining.webp|Prompt-Chaining]]

Prompt-Chaining

- Breaks a task into sequential steps, each handled by a separate LLM call.
- Useful for tasks that benefit from stepwise refinement, such as content generation or summarization.

### Routing

![[Routing-Workflow.webp|Routing-Workflow]]

Routing Workflow

- Classifies and directs inputs to specialized prompts, models or tools.
- Ideal for multi-domain systems, like CRM agents or [retrieval-augmented generation](https://www.geeksforgeeks.org/nlp/what-is-retrieval-augmented-generation-rag/) (RAG) agents.

### Parallelisation

![[Parallelisation.webp|Parallelisation]]

Parallelisation

- Executes multiple subtasks concurrently, increasing speed and diversity of outputs.
- Suitable for multi-agent workflows, coding agents or scenarios requiring diverse perspectives.

### Orchestrator-Workers

![[Orchestrator-workers.webp|Orchestrator-workers]]

Orchestrator-Workers

- An orchestrator LLM delegates subtasks to worker LLMs and synthesizes results.
- Enables dynamic task decomposition and is useful for meta-agents or debate workflows.

### Evaluator-Optimizer

![[Evaluator-optimizer.webp|Evaluator-optimizer]]

Evaluator-Optimiser

- One LLM generates output, another evaluates and refines it in a feedback loop.
- Effective for iterative improvement, such as code generation or personalized chatbots.

## Key Implementation Details

- ****LLM-Centric Design****: The LLM is the core “brain,” augmented with tools, retrieval systems and memory as needed.
- ****Tool Integration****: Agents can access external tools (APIs, databases, actions) to retrieve information or execute tasks, such as issuing refunds or updating records in customer support scenarios.
- ****Autonomy and Feedback****: Agents plan and execute actions, receive feedback from the environment (or users) and iterate until the task is complete or a stopping condition is met.
- ****Human Oversight****: For critical or ambiguous steps, agents can pause for human input or review, ensuring reliability and safety.
- ****Clear Interfaces****: Well-documented toolsets and explicit agent-computer interfaces (ACI) are essential for agent reliability and maintainability.

## Technical Features and Flexibility

- ****Customizable Prompts and Behaviors****: Agents can be reconfigured on the fly by updating system prompts or toolsets, adapting to new tasks without redeployment.
- ****Streaming and Real-Time Interaction****: Support for streaming responses and real-time updates for interactive applications.
- ****Scalability and Persistence****: Architectures using durable objects or cloud infrastructure allow agents to maintain state and scale globally.
- ****Live Monitoring and Debugging****: Real-time updates and transparent planning steps aid in debugging and building trust with users.

## Best Practices

- ****Transparency****: Make agent decisions and planning steps explicit for easier debugging and trust.
- ****Simplicity and Modularity****: Favor simple, understandable patterns that can be composed as needed.
- ****Iterative Development****: Start with basic patterns, evaluate performance and incrementally add complexity only when necessary.
- ****Robust Evaluation****: Use clear success criteria, automated tests and human feedback to measure and improve agent performance.

## Practical Applications

****Customer Support Agents****

- Combine conversational AI with tool integration.
- Access customer data, knowledge bases and perform actions (e.g., refunds).
- Success is measured by clear, user-defined resolutions; usage-based pricing models are common, charging only for successful outcomes.

****Coding Agents****

- Agents autonomously solve coding tasks, using automated tests as feedback.
- Can iterate on solutions and verify correctness through test results.
- Human review ensures solutions align with broader system requirements.

What is the main difference between agents and workflows?

- A
	Agents follow fixed steps, workflows are dynamic
- B
	Agents are slower than workflows
- C
	Agents are dynamic, workflows follow predefined steps
- D
	Both are identical

What does Prompt Chaining help achieve?

- A
	Breaking tasks into sequential steps
- B
	Parallel execution
- C
	Model training
- D
	Data storage

What is the function of an Orchestrator in AI agents?

- A
	Delegates subtasks to workers and combines results
- B
	Executes only one task
- C
	Only evaluates outputs
- D
	Stores memory

When should you prefer using an agent over a workflow?

- A
	When tasks are fixed and repetitive
- B
	When no LLM is needed
- C
	When only data storage is required
- D
	When tasks require dynamic decision-making

A developer builds an agentic AI using LangChain's create\_react\_agent. What role does the 'tools' list play in this setup?

```
from langchain_openai import ChatOpenAI
from langchain.agents import create_react_agent, AgentExecutor
from langchain_community.tools import DuckDuckGoSearchRun
from langchain_core.tools import tool
 
@tool
def calculator(expression: str) -> str:
    """Evaluates a math expression"""
    return str(eval(expression))
 
llm   = ChatOpenAI(model='gpt-4')
tools = [DuckDuckGoSearchRun(), calculator]
 
agent          = create_react_agent(llm, tools, prompt)
agent_executor = AgentExecutor(agent=agent, tools=tools, verbose=True)
```

What do the tools in this LangChain agent enable?

- A
	They give the agent real-world capabilities — web search and math — beyond pure LLM text generation
- B
	They define the model's training dataset and fine-tuning schedule
- C
	They set the tokenizer vocabulary and context window size
- D
	They configure the agent's output format and response length

![[sucess-img 13.png|success]]

Quiz Completed Successfully

Score:0/5

Accuracy:0%