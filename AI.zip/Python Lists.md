---
title: "Python Lists"
source: "https://www.geeksforgeeks.org/python/python-lists/"
author:
  - "[[GeeksforGeeks]]"
published: 2018-01-29
created: 2026-09-23
description: "Your All-in-One Learning Portal: GeeksforGeeks is a comprehensive educational platform that empowers learners across domains-spanning computer science and programming, school education, upskilling, commerce, software tools, competitive exams, and more."
tags:
  - "clippings"
---
List is a built-in data structure used to store an ordered collection of items. They are dynamic, resizable and capable of storing multiple data types.

- List elements can be changed, updated, added, or removed after the list is created.
- Elements maintain the order in which they are inserted.
- Elements are accessed using their position, starting from index 0.
![[a_.webp|a_]]

Above image demonstrates that a list can contain elements of different data types.

## Creating a List

Lists can be created in several ways, such as using square brackets \[\], the list() constructor or by repeating elements.

****1\. Using Square Brackets:**** Square brackets \[\] are used to create a list directly.
```
a = [1, 2, 3]
print(a)

b = ["apple", "banana"]
print(b)
```
**Output**
```
[1, 2, 3]
['apple', 'banana']
```

****2\. Using list() Constructor:**** A list can also be created by passing an iterable (such as [tuple](https://www.geeksforgeeks.org/python/python-tuples/), [string](https://www.geeksforgeeks.org/python/python-string/) or another list) to the [list()](https://www.geeksforgeeks.org/python/python-list-function/) constructor.
```
a = list((1, 2, 3, 'apple', 4.5))  
print(a)

b = list("GFG")
print(b)
```
**Output**
```
[1, 2, 3, 'apple', 4.5]
['G', 'F', 'G']
```

****3\. Creating List with Repeated Elements:**** A list with repeated elements can be created using the multiplication (\*) operator.
```
a = [2] * 5
b = [0] * 7

print(a)
print(b)
```
**Output**
```
[2, 2, 2, 2, 2]
[0, 0, 0, 0, 0, 0, 0]
```

## Internal Representation of Lists

Python list stores references to objects, not the actual values directly.

- The list keeps memory addresses of objects like integers, strings or booleans.
- Actual objects exist separately in memory.
- Modifying a mutable object inside a list changes the original object.
- Reassigning an immutable object creates a new object instead of changing the old one.
```
a = [1, 2, 2, "Python"]
print(a[0])   # index-based
print(a)
```
**Output**
```
1
[1, 2, 2, 'Python']
```

****Explanation:****

- a\[0\] accesses the first element of the list.
- list contains integers and a string, showing that Python lists can store multiple data types.

## Accessing Elements

Elements in a list are accessed using indexing. Python uses zero-based indexing, meaning a\[0\] represents the first element. Negative indexing is also supported, where -1 accesses the last element.
```
a = [10, 20, 30]
print(a[0])
print(a[-1])
```
**Output**
```
10
30
```

## Adding Elements

Elements can be added to a list using the following methods:

1\. ****append():**** Adds an element at the end of the list.
```
a = [1, 2]
a.append(3)
print(a)
```
**Output**
```
[1, 2, 3]
```

2\. ****insert():**** Adds an element at a specific position.
```
a = [1, 3]
a.insert(1, 2)
print(a)
```
**Output**
```
[1, 2, 3]
```

3\. ****extend():**** Adds multiple elements to the end of the list.
```
a = [1, 2]
a.extend([3, 4])
print(a)
```
**Output**
```
[1, 2, 3, 4]
```

## Updating Elements

Since lists are mutable, elements can be updated by assigning new values using their index.
```
a = [10, 20, 30, 40, 50]
a[1] = 25 
print(a)
```
**Output**
```
[10, 25, 30, 40, 50]
```

## Removing Elements

Elements can be removed from a list using the following methods:

1\. ****remove():**** Removes the first occurrence of an element.
```
a = [1, 2, 3]
a.remove(2)
print(a)
```
**Output**
```
[1, 3]
```

2\. ****pop():**** Removes the element at a specific index or the last element if no index is specified.
```
a = [1, 2, 3]
a.pop()
print(a)
```
**Output**
```
[1, 2]
```

3\. ****del statement:**** Deletes an element at a specified index.
```
a = [1, 2, 3]
del a[1]
print(a)
```
```
[1, 3]
```

4\. ****clear():**** removes all items.
```
a = [1, 2, 3]
a.clear()
print(a)
```
**Output**
```
[]
```

## Iterating Over Lists

We can use loop to [Iterate Over a list](https://www.geeksforgeeks.org/python/iterate-over-a-list-in-python/), allowing operations to be performed on each element.
```
a = ['apple', 'banana', 'cherry']
for item in a:
    print(item)
```
**Output**
```
apple
banana
cherry
```

## Nested Lists

A nested list is a list that contains another list as its element. It is commonly used to represent matrices or tabular data. Nested elements can be accessed by chaining multiple indexes.
```
a = [[1, 2], [3, 4]]
print(a[0])
print(a[1][0])
```
**Output**
```
[1, 2]
3
```

> To know more, please refer to this article: [List comprehension](https://www.geeksforgeeks.org/python/python-list-comprehension/)

How to create an empty list in Python?

- A
	list = \[\]
- B
	list = list()
- C
	list = {}
- D
	Both A and B

Which method adds an item to the end of a list?

- A
	append()
- B
	extend()
- C
	insert()
- D
	add()

Which method would you use to add multiple elements at once to an existing list in Python?

- A
	append()
- B
	insert()
- C
	extend()
- D
	combine()

What does the list.insert(0, 'a') method do?

- A
	Adds 'a' at the end of the list
- B
	Adds 'a' at the beginning of the list
- C
	Removes 'a' from the list
- D
	Replaces the first item with 'a'

Which method returns the index of the first occurrence of a substring and raises an error if not found?

- A
	index()
- B
	find()
- C
	position()
- D
	locate()

Which of the following methods will remove an element from a list without returning it?

- A
	pop()
- B
	remove()
- C
	delete()
- D
	discard()

What is the result of concatenating two lists, list1 = \[1, 2, 3\] and list2 = \[4, 5, 6\]?

- A
	\[1, 2, 3, 4, 5, 6\]
- B
	\[1, 2, 3\], \[4, 5, 6\]
- C
	\[\[1, 2, 3\], \[4, 5, 6\]\]
- D
	\[1, 2, 3 + 4, 5, 6\]

What is the output of the following code?

In Python what is the time complexity of accessing an element in a list using its index?

What does a\[-1\] return in a Python list?

![[sucess-img 53.png|success]]

Quiz Completed Successfully

Score:0/10

Accuracy:0%