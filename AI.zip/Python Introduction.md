---
title: "Python Introduction"
source: "https://www.geeksforgeeks.org/python/introduction-to-python/"
author:
  - "[[GeeksforGeeks]]"
published: 2015-11-06
created: 2026-09-23
description: "Your All-in-One Learning Portal: GeeksforGeeks is a comprehensive educational platform that empowers learners across domains-spanning computer science and programming, school education, upskilling, commerce, software tools, competitive exams, and more."
tags:
  - "clippings"
---
Python is a high-level programming language known for its simple and readable syntax. It has the following features:

- Allows writing clean code with fewer lines.
- Supports multiple programming paradigms including object-oriented, functional and procedural programming.
- Widely used in web development, automation, data analysis, artificial intelligence and many other fields.
- Dynamically typed and has automatic garbage collection

## Hello World Program

The Hello World program demonstrates the basic structure of a Python program.
```
# This is a comment. It will not be executed.
print("Hello, World!")
```
**Output**
```
Hello, World!
```

****How does this work:****

![[hello_world.webp|hello_world]]

Hello World Program

- print() is a built-in Python function that instructs the computer to display text on the screen.
- "Hello, World!" is a string enclosed within quotes (either single ' or double ").
- Python uses indentation (spaces or tabs) to define code blocks instead of braces {} in C, C++ and Java.
- \# is used to write [Python Comments](https://www.geeksforgeeks.org/python/python-comments/). Comments are ignored during execution.

Which of the following is not a feature of Python?

- A
	Dynamic typing
- B
	Interpreted language
- C
	Code readability
- D
	Low-level operations

What is the role of indentation in Python?

- A
	It is used only for code formatting and has no effect on execution
- B
	It defines code blocks such as loops, functions, and conditionals
- C
	It is required only inside functions
- D
	It is optional but recommended

What type of programming paradigms does Python support?

- A
	Only procedural programming
- B
	Only object-oriented programming
- C
	Multiple programming paradigms
- D
	Only functional programming

What is the output of the following command in Python?

- A
	Hello World
- B
	"Hello, World!"
- C
	Hello, World!
- D
	Hello, World

Which of the following is used to output data in Python?

![[sucess-img 52.png|success]]

Quiz Completed Successfully

Score:0/5

Accuracy:0%