---
title: "What is CrewAI?"
source: "https://www.geeksforgeeks.org/blogs/what-is-crewai/"
author:
  - "[[GeeksforGeeks]]"
published: 2025-02-18
created: 2026-09-23
description: "Your All-in-One Learning Portal: GeeksforGeeks is a comprehensive educational platform that empowers learners across domains-spanning computer science and programming, school education, upskilling, commerce, software tools, competitive exams, and more."
tags:
  - "clippings"
---
CrewAI is an open source framework that enables multiple AI agents to collaborate on complex tasks, where each agent has a specific role and works together efficiently with memory and context awareness.

- Uses multiple agents with defined roles to handle different parts of a task.
- Supports collaboration similar to a team working together on a shared goal.
- Maintains context and memory for smoother execution and better decisions.
- Applicable in areas like content creation, research, software development and customer support.
![[crew.webp|crew]]

CrewAI

## Setting Up Environment

To start using CrewAI, set up the environment by installing required packages and configuring API access.

### Step 1: Install CrewAI

We will install the crewai package using pip to make all the necessary functionality available

> !pip install crewai

### Step 2: Set API Key

Configure your API key (e.g., [Gemini API key](https://www.geeksforgeeks.org/artificial-intelligence/how-to-use-google-gemini-api-key/)) to enable model access and functionality.
```
import os
os.environ["GOOGLE_API_KEY"] = "your api key"
```
## Implementation

In this section, we will see how to use CrewAI by setting up a team of agents to work together on a party planning task.

### 1\. Import Required Libraries

Before we start working with CrewAI, we need to import the required libraries. These libraries provide the essential functions to define agents, tasks and crews.

- Agent defines the individual agents that perform tasks.
- Task describes the tasks assigned to agents.
- Crew groups agents and tasks together for execution.
```
from crewai import Agent, Task, Crew
```
### 2\. Define Agents

Agents in CrewAI are the entities that perform specific tasks.

- Agents are defined with key attributes including role (what the agent does), goal (the outcome it aims to achieve) and backstory (context describing its skills and expertise).
- Use allow\_delegation to control whether the agent can assign tasks to other agents.
- Set verbose=True to enable detailed explanations of the agent’s actions and reasoning.
- Create agents for roles such as party planner, food coordinator, decorator and entertainment manager.
```
party_planner = Agent(
    role="Party Planner",
    goal="Create the party plan, including the theme, timeline, and guest list.",
    backstory=(
        "You organize the vision for the party, create a timeline, and ensure all aspects are planned. "
        "You send out invitations and coordinate with the other agents."
    ),
    allow_delegation=False,
    verbose=True,
    llm="gemini/gemini-2.5-flash" 
)

food_beverage_coordinator = Agent(
    role="Food & Beverage Coordinator",
    goal="Organize the food and drinks for the party, ensuring there’s enough variety for all guests.",
    backstory=(
        "You handle the food and drink preparations, whether it’s cooking, ordering, or working with caterers. "
        "You make sure guests have plenty to eat and drink throughout the event."
    ),
    allow_delegation=False,
    verbose=True,
    llm="gemini/gemini-2.5-flash" 
)

decorator = Agent(
    role="Decorator",
    goal="Make the party venue look great, fitting the theme and making it fun for guests.",
    backstory=(
        "You decorate the venue to match the theme and create a welcoming and festive environment. "
        "You ensure the venue is ready when the guests arrive."
    ),
    allow_delegation=False,
    verbose=True,
    llm="gemini/gemini-2.5-flash" 
)

entertainment_guest_relations = Agent(
    role="Entertainment & Guest Relations Coordinator",
    goal="Organize entertainment, games, and manage guest interactions to ensure a fun party.",
    backstory=(
        "You make sure the guests have fun, whether it’s through music, games, or other activities. "
        "You also help guests with seating and ensure the event flows smoothly."
    ),
    allow_delegation=False,
    verbose=True,
    llm="gemini/gemini-2.5-flash" 
)
```
### 3\. Assigning Tasks

- Define tasks for each agent based on their role, goal and responsibilities.
- Link each task to a specific agent so it is executed accordingly.
- Ensure tasks cover different aspects like planning, food, decoration and entertainment.
- Each agent performs its assigned task using the configured LLM (e.g., Gemini) for execution.
```
party_plan_task = Task(
    description="Create a party plan including theme, timeline, and guest list.",
    expected_output="Complete party plan with theme, timeline, and invitations.",
    agent=party_planner
)

food_task = Task(
    description="Organize food and drinks menu and set up food stations.",
    expected_output="Food and drinks ready for the party.",
    agent=food_beverage_coordinator
)

decor_task = Task(
    description="Decorate the venue according to the theme.",
    expected_output="Venue decorated and ready for guests.",
    agent=decorator
)

entertainment_task = Task(
    description="Organize music, games, and manage guest interactions.",
    expected_output="A fun and engaging atmosphere with happy guests.",
    agent=entertainment_guest_relations
)
```
### 4\. Creating and Managing a Crew

- Create a Crew by combining all defined agents and their assigned tasks into a single workflow.
- This enables agents to collaborate and coordinate on the shared goal (e.g., party planning).
- The Crew manages execution flow, ensuring each agent performs its task using the configured LLM.
```
party_crew = Crew(agents=[party_planner, food_beverage_coordinator, decorator, entertainment_guest_relations], 
                  tasks=[party_plan_task, food_task, decor_task, entertainment_task], verbose=True)
```
### 5\. Executing the Workflow

- Start the Crew execution to begin the workflow.
- Agents perform their assigned tasks based on their roles and goals.
- The Crew coordinates the process and ensures tasks are completed using the configured LLM.
```
party_result = party_crew.kickoff(inputs={})
```
****Output:****

> Download full code from [here](https://media.geeksforgeeks.org/wp-content/uploads/20260327122641077680/crewAi_implementation.ipynb)

## Applications

- Supports event planning by coordinating tasks like planning, food, decoration and entertainment.
- Enhances content creation by enabling agents to research, write and review content.
- Assists in software development through code generation, review and validation.
- Enables market research by collecting data, analyzing trends and generating insights.

What is CrewAI?

- A
	A framework for developing AI-powered applications
- B
	A system for training machine learning models
- C
	A platform for hosting cloud-based AI services
- D
	A framework for coordinating multiple AI agents

Which CrewAI feature helps agents maintain information across interactions?

- A
	Memory retention and context awareness
- B
	Multi-agent coordination
- C
	Role-based task delegation
- D
	Workflow orchestration

In CrewAI, what is the role of an "Agent"?

- A
	To perform specific tasks with defined roles and goals
- B
	To store data
- C
	To execute machine learning algorithms
- D
	To manage the CrewAI framework

What is the purpose of the Crew class in CrewAI?

Which of the following is NOT a step in setting up the CrewAI environment?

![[sucess-img 79.png|success]]

Quiz Completed Successfully

Score:0/5

Accuracy:0%