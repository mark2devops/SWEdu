---
title: "Fine Tuning Large Language Model (LLM)"
source: "https://www.geeksforgeeks.org/deep-learning/fine-tuning-large-language-model-llm/"
author:
  - "[[GeeksforGeeks]]"
published: 2024-02-12
created: 2026-09-23
description: "Your All-in-One Learning Portal: GeeksforGeeks is a comprehensive educational platform that empowers learners across domains-spanning computer science and programming, school education, upskilling, commerce, software tools, competitive exams, and more."
tags:
  - "clippings"
---
Fine-tuning refers to the process of taking a pre-trained model and adapting it to a specific task by training it further on a smaller, domain-specific dataset. It refines the model’s capabilities and improves its accuracy in specialised tasks without needing a massive dataset or expensive computational resources.

- Steer the model towards performing optimally on particular tasks.
- Ensure model outputs align with expected results for real-world applications.
- Reduce model hallucinations and improve output relevance and honesty.
![[Fine-Tuning-Large-Language-Models.webp|Fine-Tuning-Large-Language-Models]]

Fine Tuning Large Language Model

## How is Fine-Tuning Performed?

1. ****Select Base Model:**** Choose a pre-trained model based on our task and compute budget.
2. ****Choose Fine-Tuning Method:**** Select the most appropriate method like [****I**** nstruction Fine-Tuning](https://www.geeksforgeeks.org/artificial-intelligence/instruction-tuning-for-large-language-models/), [Supervised Fine-Tuning](https://www.geeksforgeeks.org/artificial-intelligence/supervised-fine-tuning-sft-for-llms/), [PEFT](https://www.geeksforgeeks.org/artificial-intelligence/what-is-parameter-efficient-fine-tuning-peft/), [LoRA](https://www.geeksforgeeks.org/deep-learning/what-is-low-rank-adaptation-lora/), [QLoRA](https://www.geeksforgeeks.org/deep-learning/what-is-qlora-quantized-low-rank-adapter/), etc based on the task and dataset.
3. ****Prepare Dataset:**** Structure our data for task-specific training, ensuring the format matches the model's requirements.
4. ****Training:**** Use frameworks like TensorFlow, PyTorch or high-level libraries like [Transformers](https://www.geeksforgeeks.org/machine-learning/getting-started-with-transformers/) to fine-tune the model.
5. ****Evaluate and Iterate:**** Test the model, refine it as necessary and re-train to improve performance.

## Types of Fine Tuning Methods

![[Types-of-Fine-Tuning-Methods.webp|Types-of-Fine-Tuning-Methods]]

### 1\. Supervised Fine-Tuning

- Further trains a pre-trained model on a task-specific labeled dataset (input-output pairs).
- Updates all model weights to adapt it to the new task.
- Best for tasks like sentiment analysis and text classification where labeled data is available.

### 2\. Instruction Fine-Tuning

- Trains the model using datasets pairing instructions (prompts) with expected responses.
- Helps the model generalize to new tasks and follow natural language instructions.
- Commonly used in chatbots, question answering and open-ended tasks.

### 3\. Parameter-Efficient Fine-Tuning (PEFT)

- Adjusts only a small subset of parameters, keeping most of the model unchanged.
- Methods include training adapter layers, low-rank reparameterization (LoRA) or just prompt tokens.
- Enables efficient adaptation of large models with less memory and computation—for example, PEFT can reduce trainable parameters from tens of thousands to just a few thousand.

### 4\. Reinforcement Learning with Human Feedback (RLHF)

- Uses human ratings to teach a model to align outputs with human preferences.
- Involves three steps: generate outputs, train a reward model from human feedback and optimize model behavior using reinforcement learning (like PPO).
- Ideal for tasks requiring alignment with human values and nuanced preferences such as generating helpful, safe or ethical content.

## Implementing Fine Tuning Large Language Model using DialogSum Database

Let's fine tune a model using PEFT [LoRa Method](https://www.geeksforgeeks.org/deep-learning/what-is-low-rank-adaptation-lora/). We will use flan-t5-base model and DialogSum database.

- Flan-T5 is the instruction fine-tuned version of T5 released by Google.
- DialogSum is a large-scale dialogue summarization dataset, consisting of 13,460 (Plus 100 holdout data for topic generation) dialogues with corresponding manually labeled summaries and topics.

### Step 1: Install Necessary Libraries

The following commands install the required libraries for the task, including Hugging Face Transformers, Datasets and PEFT (Parameter-Efficient Fine-Tuning). These libraries enable model loading, training and fine-tuning.

### Step 2: Set Up Environment

Configure the device for computation, using GPU if available. Import all necessary libraries for dataset handling, model loading, tokenization and evaluation.

### Step 3: Load Dataset

Load the Hugging Face dataset for dialogue summarization. In this example, we use the "knkarthick/dialogsum" dataset.

****Output:****

![[Screenshot-2025-07-26-173403.webp|Screenshot-2025-07-26-173403]]

Loading Dataset

### Step 4: Load Pre-trained Model and Tokenizer

Use a pre-trained T5 model (google/flan-t5-base) for sequence-to-sequence learning and initialize its tokenizer.

****Output:****

![[Screenshot-2025-07-26-173357.webp|Screenshot-2025-07-26-173357]]

Loading Pre-trained Model and Tokenizer

### Step 5: Check Trainable Parameters

Define a function to calculate and print the percentage of trainable parameters in the model.

****Output:****

![[Screenshot-2025-07-26-173352.webp|Screenshot-2025-07-26-173352]]

Trainable Parameters

### Step 6: Perform Baseline Inference

Test the pre-trained model on a sample from the test set to evaluate its performance before fine-tuning.

****Output:****

![[Screenshot-2025-07-26-173346.webp|Screenshot-2025-07-26-173346]]

Baseline Inference

### Step 7: Tokenize Dataset

Tokenize the dataset to prepare it for training. The function generates input and label IDs, truncating or padding them to a fixed length.

****Output:****

![[Screenshot-2025-07-26-173336.webp|Screenshot-2025-07-26-173336]]

Tokenize Dataset

### Step 8: Apply PEFT with LoRA Configuration

Use [PEFT (Parameter-Efficient Fine-Tuning)](https://www.geeksforgeeks.org/artificial-intelligence/what-is-parameter-efficient-fine-tuning-peft/) to minimize training time and resource usage by tuning only specific layers.

****Output:****

![[Screenshot-2025-07-26-173330.webp|Screenshot-2025-07-26-173330]]

LoRA Configuration

### Step 9: Define Training Arguments

Set up training configurations, including batch size, learning rate and the number of epochs.

### Step 10: Train the Model

Use Hugging Face Trainer API to train the PEFT-enabled model.

****Output:****

### Step 11: Save the Fine-Tuned Model

Save the trained PEFT model and tokenizer for future use.

****Output:****

![[Screenshot-2025-07-26-173322.webp|Screenshot-2025-07-26-173322]]

Fine-tuned Model

### Step 12: Load and Test Fine-Tuned Model

Load the fine-tuned model and test its performance on the same input prompt.

****Output:****

![[Screenshot-2025-07-26-173308.webp|Screenshot-2025-07-26-173308]]

Testing and Result

> We can download the source code from [here](https://media.geeksforgeeks.org/wp-content/uploads/20260430165447248980/finetuning.ipynb).