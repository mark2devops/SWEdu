---
title: "Python Dictionaries (with Examples)"
source: "https://www.geeksforgeeks.org/python/python-dictionary/"
author:
  - "[[GeeksforGeeks]]"
published: 2018-01-25
created: 2026-09-23
description: "Your All-in-One Learning Portal: GeeksforGeeks is a comprehensive educational platform that empowers learners across domains-spanning computer science and programming, school education, upskilling, commerce, software tools, competitive exams, and more."
tags:
  - "clippings"
---
Dictionary is a data structure that stores information in key-value pairs. While keys must be unique and immutable (like strings or numbers), values can be of any data type, whether mutable or immutable. This makes dictionaries ideal for accessing data by a specific name rather than a numeric position like in list.

****Example:**** This example shows how a dictionary stores data using keys and values.
```
data = { "name": "Jake", "age": 22 }
print(data)
```
**Output**
```
{'name': 'Jake', 'age': 22}
```

****Explanation:**** "name" and "age" are keys, "Jake" and 22 are their values and dictionary stores data in key:value format

## Creating a Dictionary

A dictionary is created by writing key-value pairs inside { }, where each key is connected to a value using colon (:). A dictionary can also be created using [dict()](https://www.geeksforgeeks.org/python/python-dict-function/) function.
```
a = {"x": 1, "y": 2}
print(a)

b = dict(name="Sam", age=20)
print(b)
```
**Output**
```
{'x': 1, 'y': 2}
{'name': 'Sam', 'age': 20}
```

## Accessing Dictionary Items

A value in a dictionary is accessed by using its key. This can be done either with square brackets \[ \] or with the [get()](https://www.geeksforgeeks.org/python/python-dictionary-get-method/) method. Both return the value linked to the given key.
```
d = {"name": "Kat", "age": 21}

print(d["name"])     # Access using key
print(d.get("age"))  # Access using get()
```
**Output**
```
Kat
21
```

> ****Note:**** Accessing a missing key with \[ \] raises a KeyError, while get() is safer because it returns None (or a default value) instead of an error.

## Adding and Updating Dictionary Items

New items are added to a dictionary using the assignment operator (=) by giving a new key a value. If an existing key is used with the assignment operator, its value is updated with the new one.
```
d = {"name": "Sam"}

d["age"] = 21        # Adding a new key-value pair
d["name"] = "Alex"   # Updating an existing value
print(d)
```
**Output**
```
{'name': 'Alex', 'age': 21}
```

## Removing Dictionary Items

Dictionary items can be removed using built-in deletion methods that work on keys:

1\. ****del:**** [del](https://www.geeksforgeeks.org/python/python-del-to-delete-objects/) removes an item using its key
```
d = {"a": 1, "b": 2}
del d["a"]
print(d)
```
**Output**
```
{'b': 2}
```

2\. ****pop():**** [pop()](https://www.geeksforgeeks.org/python/python-list-pop-method/) removes the item with the given key and returns its value
```
d = {"a": 1, "b": 2}

val = d.pop("a")
print(val)
print(d)
```
**Output**
```
1
{'b': 2}
```

3\. ****popitem()****: [popitem()](https://www.geeksforgeeks.org/python/python-dictionary-popitem-method/) removes and returns the last inserted key-value pair
```
d = {"a": 1, "b": 2}
print(d.popitem())
```
**Output**
```
('b', 2)
```

4\. ****clear():**** [clear()](https://www.geeksforgeeks.org/python/python-list-clear-method/) removes all items from the dictionary
```
d = {"a": 1, "b": 2}
d.clear()
print(d)
```
**Output**
```
{}
```

## Iterating Through a Dictionary

A dictionary can be traversed using a for loop to access its keys, values or both key-value pairs by using the built-in methods keys(), values() and items().

****1.**** [****Iterate keys****](https://www.geeksforgeeks.org/python/python-dictionary-keys-method/)****:**** Returns all keys from the dictionary.
```
d = {"a": 1, "b": 2}
for key in d:
    print(key)
```
**Output**
```
a
b
```

****2.**** [****Iterate values****](https://www.geeksforgeeks.org/python/python-dictionary-values/)****:**** Returns all values from the dictionary.
```
d = {"a": 1, "b": 2}
for value in d.values():
    print(value)
```
**Output**
```
1
2
```

****3.**** [****Iterate key-value pairs****](https://www.geeksforgeeks.org/python/python-dictionary-items-method/)****:**** Returns all key-value pairs as tuples.
```
d = {"a": 1, "b": 2}
for key, value in d.items():
    print(key, value)
```
**Output**
```
a 1
b 2
```

> Read in detail: [Ways to Iterate Over a Dictionary](https://www.geeksforgeeks.org/python/iterate-over-a-dictionary-in-python/)

## Nested Dictionaries

A [nested dictionary](https://www.geeksforgeeks.org/python/python-nested-dictionary/) is a dictionary that contains another dictionary as one of its values. Below diagram shows how a nested dictionary works, where key 3 points to another dictionary inside the main dictionary.

![[keys.webp|keys]]

Representation of Nested Dictionary

The arrows show how each key is connected to its corresponding value.
```
d = {
    "student": {
        "name": "Sam",
        "age": 20
    }
}

print(d["student"]["name"])
```
**Output**
```
Sam
```

What is the output of the following code?
```
d = {"a": 1, "b": 2}
print(d["a"])
```
- A
	a
- B
	1
- C
	2
- D
	Error

What is the result of the following code?

- A
	{"a": 1, "b": 2}
- B
	{"a": 1, "b": 2, "c": 3}
- C
	{"a": 1, "b": 2, 3}
- D
	Error

Which method is used to remove all elements from a dictionary?

- A
	clear()
- B
	pop()
- C
	remove()
- D
	discard()

What does the following code print?

- A
	3
- B
	1
- C
	2
- D
	None

What will be the output of the following code?

Which of the following set operations returns elements that are in set1 but not in set2?

![[sucess-img 50.png|success]]

Quiz Completed Successfully

Score:0/6

Accuracy:0%