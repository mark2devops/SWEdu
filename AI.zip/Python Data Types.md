---
title: "Python Data Types"
source: "https://www.geeksforgeeks.org/python/python-data-types/"
author:
  - "[[GeeksforGeeks]]"
published: 2019-10-29
created: 2026-09-23
description: "Your All-in-One Learning Portal: GeeksforGeeks is a comprehensive educational platform that empowers learners across domains-spanning computer science and programming, school education, upskilling, commerce, software tools, competitive exams, and more."
tags:
  - "clippings"
---
Data types in Python define the type of value stored in a variable and determine the operations that can be performed on that data. Since Python treats everything as an object, each value is associated with a specific data type.

- Helps the interpreter understand how to store and process different kinds of data efficiently.
- Enables correct operations by ensuring only valid actions are performed on compatible data types.
![[Python-Data-Types.webp|Python-Data-Types]]

Python DataTypes

Below code assigns different types of values to variable x. With each new assignment, the previous value is replaced and x changes to the new data type.
```
x = 50
x = 60.5
x = "Hello World"
x = ["geeks", "for", "geeks"]
x = ("geeks", "for", "geeks")
```
## Numeric Data Types

In, [Python Numeric data](https://www.geeksforgeeks.org/python/python-numbers/) types are used to store numeric values. It can be an integer, floating number or even a complex number. It supports three main numeric types:

- ****Integers:**** value is represented by int class. It contains positive or negative whole numbers (without fractions or decimals).
- ****Float:**** value is represented by float class. It is a real number with a floating-point representation. It is specified by a decimal point.
- ****Complex:**** It is represented by a complex class. It stores numbers with real and imaginary parts. For example: 2+3j

```
a = 5
b = 5.0
c = 2 + 4j

print(type(a))
print(type(b))
print(type(c))
```
**Output**
```
<class 'int'>
<class 'float'>
<class 'complex'>
```

## Sequence Data Types

A sequence is an ordered collection of items, which can be of similar or different data types. Elements in a sequence can be accessed using indexing.

### 1\. String

[Strings](https://www.geeksforgeeks.org/python/python-string/) are used to store text data. A string is represented using the str class and can be created using single, double or triple quotes.
```
s = 'Welcome to the Geeks World'
print(s)
print(type(s))

# access string with index
print(s[1])
print(s[-1])
```
**Output**
```
Welcome to the Geeks World
<class 'str'>
e
d
```

### 2\. List

[Lists](https://www.geeksforgeeks.org/python/python-lists/) are ordered and mutable collections used to store multiple items in a single variable. Elements in a list can be of different data types and are accessed using indexing.
```
a = [1, 2, 3]
print(a)

b = ["Geeks", "For", "Geeks", 4, 5]
print(b[3])
print(b[-3])
```
**Output**
```
[1, 2, 3]
4
Geeks
```

### 3\. Tuple

[Tuples](https://www.geeksforgeeks.org/python/python-tuples/) are ordered and immutable collections used to store multiple items in a single variable. Once created, tuple elements cannot be modified and are accessed using indexing.

> ****Note:**** A tuple with a single element must include a trailing comma, otherwise Python treats it as a normal value instead of a tuple.
```
t1 = (1,)
print(type(t1))

t2 = ('Geeks', 'For', 'Geeks', 1, 2)
print(t2[3])
print(t2[-3])
```
**Output**
```
<class 'tuple'>
1
Geeks
```

## Boolean Data Type

[Boolean](https://www.geeksforgeeks.org/python/boolean-data-type-in-python/) data type represents one of two values: True or False. It is mainly used in conditions and comparisons and is represented by the bool class.
```
print(type(True))
print(type(False))
```
**Output**
```
<class 'bool'>
<class 'bool'>
```

### Truthy and Falsy Values

[truthy and falsy](https://www.geeksforgeeks.org/python/truthy-vs-falsy-values-in-python/) values are values that evaluate to True or False in a Boolean context. Truthy values behave like True, while falsy values behave like False when used in conditions.
```
if 1:
    print("1 is truthy")

if not 0:
    print("0 is falsy")
```
**Output**
```
1 is truthy
0 is falsy
```

## Set Data Type

[Sets](https://www.geeksforgeeks.org/python/sets-in-python/) are unordered and mutable collections used to store unique elements. Since sets are unordered, elements cannot be accessed using indexing. Elements are usually accessed by iterating through the set using a loop.
```
s1 = {"a", "a", "b", "c", "b"}
print(s1)

s2 = {"Geeks", "For", "Geeks"}
for i in s2:
    print(i)
```
**Output**
```
{'b', 'a', 'c'}
Geeks
For
```

> ****Note:**** Sets in Python are unordered, so the order of elements when printed may vary each time the code is run.

## Dictionary Data Type

[Dictionaries](https://www.geeksforgeeks.org/python/python-dictionary/) are used to store data in key:value pairs. Each key in a dictionary must be unique and values are accessed using their keys with square brackets \[\] or get() method.

> ****Note:**** Dictionary keys are case sensitive, the same name but different cases of Key will be treated distinctly.
```
d = {1: 'Geeks', 2: 'For', 3: 'Geeks'}
print(d[1])    
print(d.get(2))
```
**Output**
```
Geeks
For
```

Which of the following is a mutable data type in Python?

- A
	int
- B
	list
- C
	str
- D
	tuple

Which of the following is not a numeric data type in Python?

- A
	list
- B
	float
- C
	int
- D
	complex

What will be the output of the following?

- A
	float
- B
	int
- C
	bool
- D
	string

What does the bool data type represent in Python?

- A
	Numeric values
- B
	Character strings
- C
	True or False values
- D
	List items

Which data type would you use to store a collection of unique items in Python?

- A
	list
- B
	dict
- C
	set
- D
	tuple

What is the output of the following code?

- A
	{'a': 1, 'b': 2}
- B
	('a': 1, 'b': 2)
- C
	{'c': 3}
- D
	print(b)

What is the result of trying to access an index in a set in Python?

- A
	It returns None
- B
	It raises an error
- C
	It returns the first element
- D
	It returns all elements

What will the following code print?

![[sucess-img 49.png|success]]

Quiz Completed Successfully

Score:0/8

Accuracy:0%