---
title: "Python Operators"
source: "https://www.geeksforgeeks.org/python/python-operators/"
author:
  - "[[GeeksforGeeks]]"
published: 2017-11-15
created: 2026-09-23
description: "Your All-in-One Learning Portal: GeeksforGeeks is a comprehensive educational platform that empowers learners across domains-spanning computer science and programming, school education, upskilling, commerce, software tools, competitive exams, and more."
tags:
  - "clippings"
---
In Python programming, Operators in general are used to perform operations on values and variables.

- ****Operators:**** Special symbols like -, +, \*, /, etc.
- ****Operands:**** Value on which the operator is applied.

## Types of Operators in Python

![[pythiob-operators.webp|pythiob-operators]]

Python operators

## Arithmetic Operators

[Arithmetic operators](https://www.geeksforgeeks.org/python/python-arithmetic-operators/) are used to perform basic mathematical operations like addition, subtraction, multiplication and division.

In Python, the division operator (/) returns a floating-point result, while floor division (//) returns an integer result.
```
a = 15
b = 4

print("Addition:", a + b)  

print("Subtraction:", a - b) 

print("Multiplication:", a * b)  

print("Division:", a / b) 

print("Floor Division:", a // b)  

print("Modulus:", a % b) 

print("Exponentiation:", a ** b)
```
**Output**
```
Addition: 19
Subtraction: 11
Multiplication: 60
Division: 3.75
Floor Division: 3
Modulus: 3
Exponentiation: 50625
```

> ****Note:**** Refer to [Differences between / and //](https://www.geeksforgeeks.org/python/difference-between-vs-operator-in-python/).

## Comparison Operators

[Comparison](https://www.geeksforgeeks.org/python/python-object-comparison-is-vs/) (or Relational) operators compares values. It either returns True or False according to the condition.
```
a = 13
b = 33

print(a > b)
print(a < b)
print(a == b)
print(a != b)
print(a >= b)
print(a <= b)
```
**Output**
```
False
True
False
True
False
True
```

## Logical Operators

[Logical operators](https://www.geeksforgeeks.org/python/python-logical-operators/) perform ****Logical AND****, ****Logical OR**** and ****Logical NOT**** operations. It is used to combine conditional statements.

The precedence of Logical Operators in Python is as follows:

1. Logical not
2. logical and
3. logical or

```
a = True
b = False
print(a and b)
print(a or b)
print(not a)
```
**Output**
```
False
True
False
```

## Bitwise Operators

[Bitwise operators](https://www.geeksforgeeks.org/python/python-bitwise-operators/) act on bits and perform bit-by-bit operations. These are used to operate on binary numbers.

Bitwise Operators in Python are as follows:

1. Bitwise NOT
2. Bitwise Shift
3. Bitwise AND
4. Bitwise XOR
5. Bitwise OR

```
a = 10
b = 4

print(a & b)
print(a | b)
print(~a)
print(a ^ b)
print(a >> 2)
print(a << 2)
```

**Output**
```
0
14
-11
14
2
40
```

## Assignment Operators

[Assignment operators](https://www.geeksforgeeks.org/python/assignment-operators-in-python/) are used to assign values to the variables. This operator is used to assign the value of the right side of the expression to the left side operand. ****Example:****

```
a = 10
b = a
print(b)
b += a
print(b)
b -= a
print(b)
b *= a
print(b)
b <<= a
print(b)
```
**Output**
```
10
20
10
100
102400
```

## Identity Operators

" ****is"**** and " ****is not"**** are the [identity operators](https://www.geeksforgeeks.org/python/python-membership-identity-operators-not-not/) and both are used to check if two values are located on the same part of the memory. Two variables that are equal do not imply that they are identical.

> ****is**** True if the operands are identical  
> ****is not**** True if the operands are not identical
```
a = 10
b = 20
c = a

print(a is not b)
print(a is c)
```
**Output**
```
True
True
```

## Membership Operators

" ****in"**** and " ****not in"**** are the [membership operators](https://www.geeksforgeeks.org/python/python-membership-identity-operators-not-not/) that are used to test whether a value or variable is in a sequence.

> ****in**** True if value is found in the sequence  
> ****not in**** True if value is not found in the sequence

```
x = 24
y = 20
my_list = [10, 20, 30, 40, 50]

if (x not in my_list):
    print("x is NOT present in given list")
else:
    print("x is present in given list")

if (y in my_list):
    print("y is present in given list")
else:
    print("y is NOT present in given list")
```
**Output**
```
x is NOT present in given list
y is present in given list
```

## Ternary Operator

[Ternary operators](https://www.geeksforgeeks.org/python/ternary-operator-in-python/) also known as conditional expressions are operators that evaluate something based on a condition being true or false. It was added to Python in version 2.5.

It simply allows testing a condition in a single line replacing the multiline if-else, making the code compact.

> ****Syntax:**** \[on\_true\] if \[expression\] else \[on\_false\]

```
a, b = 10, 20
min = a if a < b else b

print(min)
```
**Output**
```
10
```

## Precedence and Associativity of Operators

[Operator precedence and associativity](https://www.geeksforgeeks.org/python/precedence-and-associativity-of-operators-in-python/) determine the priorities of the operator.

### Operator Precedence

This is used in an expression with more than one operator with different precedence to determine which operation to perform first.

```
expr = 10 + 20 * 30
print(expr)
name = "Alex"
age = 0

if name == "Alex" or name == "John" and age >= 2:
    print("Hello! Welcome.")
else:
    print("Good Bye!!")
```
**Output**
```
610
Hello! Welcome.
```

### Operator Associativity

If an expression contains two or more operators with the same precedence then Operator Associativity is used to determine. It can either be Left to Right or from Right to Left.

```
print(100 / 10 * 10)
print(5 - 2 + 3)
print(5 - (2 + 3))
print(2 ** 3 ** 2)
```
**Output**
```
100.0
6
0
512
```

What is the primary purpose of operators in Python programming?

- A
	To format strings
- B
	To perform operations on values and variables
- C
	To manage memory allocation
- D
	To handle exceptions

Which of the following is NOT an arithmetic operator in Python?

- A
	+
- B
	\-
- C
	\*
- D
	^

Which operator would you use to check if two variables point to the same object in memory?

- A
	\==
- B
	is
- C
	\>
- D
	in

What is the result of the expression 10 // 3 in Python?

- A
	3
- B
	3.33
- C
	4
- D
	0

Which operator is used to combine two boolean expressions in Python?

- A
	&&
- B
	||
- C
	and
- D
	&

What will be the output of the expression

- A
	True
- B
	False
- C
	1
- D
	0

What will be the output of this code?

- A
	16
- B
	13
- C
	18
- D
	10

Which of the following is a membership operator in Python?

- A
	in
- B
	is
- C
	not
- D
	and

What is the result of the bitwise operation 10 & 4 in Python?

- A
	0
- B
	2
- C
	10
- D
	14

What will be the output of this code?

![[sucess-img 54.png|success]]

Quiz Completed Successfully

Score:0/10

Accuracy:0%