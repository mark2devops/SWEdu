---
title: "Create a ChatBot with OpenAI and Streamlit in Python"
source: "https://www.geeksforgeeks.org/python/create-a-chatbot-with-openai-and-streamlit-in-python/"
author:
  - "[[GeeksforGeeks]]"
published: 2023-10-13
created: 2026-09-23
description: "Your All-in-One Learning Portal: GeeksforGeeks is a comprehensive educational platform that empowers learners across domains-spanning computer science and programming, school education, upskilling, commerce, software tools, competitive exams, and more."
tags:
  - "clippings"
---
ChatGPT is an advanced chatbot built on the powerful GPT-3.5 language model developed by OpenAI.There are numerous [Python](https://www.geeksforgeeks.org/python/python-programming-language-tutorial/) Modules and today we will be discussing [Streamlit](https://www.geeksforgeeks.org/python/a-beginners-guide-to-streamlit/) and OpenAI [Python](https://www.geeksforgeeks.org/python/python-programming-language-tutorial/) API to create a chatbot in Python streamlit. The user can input his/her query to the chatbot and it will send the response.

![OpenAI and Streamlit](https://media.geeksforgeeks.org/wp-content/uploads/20230525104813/create-a-ChatBot-with-OpenAI-and-Streamlit-in-Python.webp)

OpenAI and Streamlit

****Required Modules****

```
pip install openai
pip install streamlit
pip install streamlit-chat
```

## Steps to create a ChatBot with OpenAI and Streamlit in Python

Here we are going to see the steps to use OpenAI in Python with Streamlit to create a chatbot.

****Step 1:**** Log in to your OpenAI account after creating one.

****Step 2:**** As shown in the figure below, after logging in, select ****Personal**** from the top-right menu, and then select ****"View API keys".****

![[chat-gpt-with-python-1.webp]]

****Step 3:**** After completing step 2, a page containing API keys is displayed, and the button ****"Create new secret key"**** is visible. A secret key is generated when you click on that, copy it and ****save it**** somewhere else because it will be needed in further steps.

![[chat-gpt-with-python-2.webp]]

****Step 4:**** Import the [****openai****](https://www.geeksforgeeks.org/machine-learning/open-ai-gpt-3/)****,****[****streamlit,****](https://www.geeksforgeeks.org/python/a-beginners-guide-to-streamlit/) ****and streamlit\_chat**** library, and then do as follows. Store the created key in the below-mentioned variable.
```
import streamlit as st
import openai
from streamlit_chat import message
openai.api_key = 'API_KEY'
```
****Step 5:**** Now we define a function to generate a response from ChatGPT using the " ****create"**** endpoint of OpenAI.
```
def api_calling(prompt):
    completions = openai.Completion.create(
        engine=&quot;text-davinci-003&quot;,
        prompt=prompt,
        max_tokens=1024,
        n=1,
        stop=None,
        temperature=0.5,
    )
    message = completions.choices[0].text
    return message
```
****Step 6:**** Now we create the header for the streamlit application and we are defining the user\_input and openai\_response in the session\_state.
```
st.title(&quot;ChatGPT ChatBot With Streamlit and OpenAI&quot;)
if 'user_input' not in st.session_state:
    st.session_state['user_input'] = []

if 'openai_response' not in st.session_state:
    st.session_state['openai_response'] = []

def get_text():
    input_text = st.text_input(&quot;write here&quot;, key=&quot;input&quot;)
    return input_text

user_input = get_text()

if user_input:
    output = api_calling(user_input)
    output = output.lstrip(&quot;\n&quot;)

    # Store the output
    st.session_state.openai_response.append(user_input)
    st.session_state.user_input.append(output)
```
****Step 7:**** Here we are using the message functions to show the previous chat of the user on the right side and the chatbot response on the left side. It shows the latest chat first. The query input by the user is shown with a different avatar.
```
message_history = st.empty()

if st.session_state['user_input']:
    for i in range(len(st.session_state['user_input']) - 1, -1, -1):
        # This function displays user input
        message(st.session_state[&quot;user_input&quot;][i],
                key=str(i), avatar_style=&quot;icons&quot;)
        # This function displays OpenAI response
        message(st.session_state['openai_response'][i],
                avatar_style=&quot;miniavs&quot;, is_user=True
                , key=str(i) + 'data_by_user')
```
![[streamlittt.png|Streamlit OpenAI]]

Chat History

****Complete Code:****
```
import streamlit as st
import openai
from streamlit_chat import message

openai.api_key = &quot;YOUR_API_KEY&quot;

def api_calling(prompt):
    completions = openai.Completion.create(
        engine=&quot;text-davinci-003&quot;,
        prompt=prompt,
        max_tokens=1024,
        n=1,
        stop=None,
        temperature=0.5,
    )
    message = completions.choices[0].text
    return message

st.title(&quot;ChatGPT ChatBot With Streamlit and OpenAI&quot;)
if 'user_input' not in st.session_state:
    st.session_state['user_input'] = []

if 'openai_response' not in st.session_state:
    st.session_state['openai_response'] = []

def get_text():
    input_text = st.text_input(&quot;write here&quot;, key=&quot;input&quot;)
    return input_text

user_input = get_text()

if user_input:
    output = api_calling(user_input)
    output = output.lstrip(&quot;\n&quot;)

    # Store the output
    st.session_state.openai_response.append(user_input)
    st.session_state.user_input.append(output)

message_history = st.empty()

if st.session_state['user_input']:
    for i in range(len(st.session_state['user_input']) - 1, -1, -1):
        # This function displays user input
        message(st.session_state[&quot;user_input&quot;][i], 
                key=str(i),avatar_style=&quot;icons&quot;)
        # This function displays OpenAI response
        message(st.session_state['openai_response'][i], 
                avatar_style=&quot;miniavs&quot;,is_user=True,
                key=str(i) + 'data_by_user')
```
****Output:****

![[streamlitoutput.png|Streamlit OpenAI]]

Streamlit OpenAI Output

## Conclusion

We covered several steps in the whole article for creating a chatbot with ChatGPT API using Python which would definitely help you in successfully achieving the chatbot creation in Streamlit. There are countless uses of Chat GPT of which some we are aware and some we aren’t.

To learn more about Chat GPT, you can refer to:

[Generate Images With OpenAI in Python](https://www.geeksforgeeks.org/data-science/generate-images-with-openai-in-python/)  
[How to Use ChatGPT API in Python?](https://www.geeksforgeeks.org/python/how-to-use-chatgpt-api-in-python/)  
[ChatGPT vs Google BARD – Top Differences That You Should Know](https://www.geeksforgeeks.org/blogs/chatgpt-vs-google-bard-top-differences-that-you-should-know/)