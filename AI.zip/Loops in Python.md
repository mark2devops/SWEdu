---
title: "Loops in Python"
source: "https://www.geeksforgeeks.org/python/loops-in-python/"
author:
  - "[[GeeksforGeeks]]"
published: 2017-06-07
created: 2026-09-23
description: "Your All-in-One Learning Portal: GeeksforGeeks is a comprehensive educational platform that empowers learners across domains-spanning computer science and programming, school education, upskilling, commerce, software tools, competitive exams, and more."
tags:
  - "clippings"
---
Loops are used to execute a block of code repeatedly until a condition is met or all items in a sequence are processed. The main types are For loops (iterating over sequences) and While loops (executing code based on a condition).

## For Loop

[For loops](https://www.geeksforgeeks.org/python/python-for-loops/) is used to iterate over a sequence such as a list, tuple, string or range. It executes a block of code once for each item in the sequence.
```
n = 4
for i in range(0, n):
    print(i)
```
**Output**
```
0
1
2
3
```

****Explanation:****

- n = 4 stores the ending value for the loop.
- range(0, n) generates numbers from 0 to 3.
- for i in range(0, n): iterates through each number in the range.

Below is the flowchart of For loop:

![[image_180.webp|image_180]]

Flowchart of For Loop

### Iterating by Index of Sequences

A for loop can also iterate through sequence elements using their index values with the help of [range()](https://www.geeksforgeeks.org/python/python-range-function/) and [len()](https://www.geeksforgeeks.org/python/python-len-function/).
```
a = ["geeks", "for", "geeks"]
for idx in range(len(a)):
    print(a[idx])
```
**Output**
```
geeks
for
geeks
```

****Explanation:****

- `len(a)` returns the total number of elements in the list.
- `range(len(a))` generates index values from 0 to 2.
- `a[idx]` accesses list elements using their index.

## While Loop

[While loop](https://www.geeksforgeeks.org/python/python-while-loop/) repeatedly executes a block of code as long as the given condition remains true. When the condition becomes false, the line immediately after the loop in the program is executed.
```
cnt = 0
while (cnt < 3):
    cnt = cnt + 1
    print("Hello Geek")
```
**Output**
```
Hello Geek
Hello Geek
Hello Geek
```

****Explanation:****

- cnt = 0 initializes the counter variable.
- while (cnt < 3): runs the loop while the condition is true.
- cnt = cnt + 1 increases the counter value by 1.

Below is the flowchart of While loop:

![[ff.webp|ff]]

Flowchart of While loop

### Infinite While Loop

An infinite while loop runs continuously because its condition always remains true.

```
while (True):
    print("Hello Geek")
```

****Explanation:****

- while(True): creates a loop with a condition that is always true.
- print("Hello Geek") keeps executing repeatedly inside the loop.

> ****Note:**** It is suggested not to use this type of loop as it is a never-ending infinite loop where the condition is always true and we have to forcefully terminate the program (or loop execution).

## Nested Loops

A [nested loop](https://www.geeksforgeeks.org/python/python-nested-loops/) is a loop inside another loop. The inner loop executes completely for every iteration of the outer loop.

```
for i in range(1, 5):
    for j in range(i):
        print(i, end=' ')
    print()
```
**Output**
```
1 
2 2 
3 3 3 
4 4 4 4
```

****Explanation:****

- Outer loop for i in range(1, 5) controls the number of rows and Inner loop for j in range(i) runs i times for each row.
- print(i, end=' ') prints the value of i on the same line and print() moves output to the next line after each row.

> There is a subtle difference between the for loop and while loop, to understand it in detail, Please refer to our article, [For Loop vs While Loop](https://www.geeksforgeeks.org/python/difference-between-for-loop-and-while-loop-in-python/).

What is the value of x?

```
x = 0
while x < 100:
    x += 2
print(x)
```
- A
	101
- B
	99
- C
	98
- D
	100

What will be the output of the following code?

- A
	G F G
- B
	0 1 2
- C
	Error
- D
	No output

What will be the output of the following Python code?

- A
	1 2 3 4
- B
	0 1 2 3
- C
	Error
- D
	No output

The best command to repeat a control statement a fixed number of times?

- A
	While loop
- B
	For loop
- C
	If
- D
	Else

To solve a problem that requires the user to enter 10 numbers would use what type of iteration?

- A
	Switch
- B
	For loop
- C
	If
- D
	Else

What is the output of the following code?

- A
	Geeks!
- B
	“Geeks!”
- C
	‘Geeks!’
- D
	Geeks!  
	Geeks!  
	Geeks!  
	(Repeated infinite times)

What is the output of the following code?

- A
	1 2 3 4 5 6
- B
	1 2 3 4 5 6 7
- C
	No output
- D
	Error

What is the output of the following code?

- A
	True
- B
	False
- C
	1
- D
	None of the above

What is the output of the following nested loop?

- A
	10 Chair  
	10 Table
- B
	10 Chair  
	10 Table  
	20 Chair  
	20 Table
- C
	Error
- D
	No output

What is the value of the var after the for loop completes its execution?

- A
	20
- B
	10
- C
	30
- D
	14

What is the output of the following nested loop?

The character that must be at the end of the line for if, while, for etc.

- A
	:
- B
	;
- C
	,
- D
	.

![[sucess-img 39.png|success]]

Quiz Completed Successfully

Score:0/12

Accuracy:0%