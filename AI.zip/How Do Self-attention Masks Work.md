---
title: "How Do Self-attention Masks Work"
source: "https://www.geeksforgeeks.org/nlp/how-do-self-attention-masks-work/"
author:
  - "[[GeeksforGeeks]]"
published: 2025-03-20
created: 2026-09-23
description: "Your All-in-One Learning Portal: GeeksforGeeks is a comprehensive educational platform that empowers learners across domains-spanning computer science and programming, school education, upskilling, commerce, software tools, competitive exams, and more."
tags:
  - "clippings"
---
Self-attention masks specify which positions can participate in the attention calculation. They are commonly used to handle padding tokens and prevent access to future tokens during autoregressive generation.

![[frame_3837.webp|frame_3837]]

A causal mask allows each token to attend only to itself and preceding tokens, preventing access to future tokens during autoregressive generation.

> A mask applies these restrictions according to the requirements of the task, ensuring that invalid positions do not influence the attention output.

### Importance

- ****Ignore Padding:**** Prevents meaningless padding tokens from influencing attention.
- ****Prevent Future Information Leakage:**** Ensures autoregressive models cannot access future tokens during prediction.
- ****Control Attention Patterns:**** Allows the model to restrict attention according to the task or sequence structure.

### Types

1. ****Padding Mask:**** Prevents the model from attending to padding tokens added to make sequences in a batch the same length.
2. ****Causal Mask:**** Prevents a token from attending to future positions.

## Padding Tokens

- Padding tokens are special tokens added to sequences in [NLP](https://www.geeksforgeeks.org/nlp/introduction-to-natural-language-processing-nlp/) tasks to make all sequences the same length. This is important for many machine learning models, including neural networks, which require consistent input lengths.
- Padding tokens don't carry meaningful information, they are just placeholders to ensure uniform sequence length.

### For example

> ****Sentence:**** "The horse ran quickly."  
> ****Padded Sentence:**** "The horse ran quickly \[PAD\]"  
> Here, "\[PAD\]" is the padding token that fills the space to make both sentences the same length.

## Working

### 1\. Computing Attention Scores

- Every word in the sentence makes a "query" (a question), "key" (a label) and "value" (the content).
- The model computes attention scores depending on how well the query matches the key, this informs the model how much attention a word should pay to other words.

### 2\. Applying the Mask

- The mask blocks selected positions by assigning their attention scores a very large negative value before softmax. As a result, their final attention weights become zero.
- If the word is crucial, the mask allows the score to remain at 1, i.e. the word can pay attention to it.

### 3\. Adjusting Attention

- Having applied the mask, the model refines its attention according to the valid attention scores that have remained.
- This manner, the model leave unnecessary sections (such as padding or upcoming words) and only checks the significant sections of the input.

### 4\. Generating Final Output

- The attention weights are used to compute a weighted combination of the Value representations, producing the final self-attention output.

## Attention scores Before & After Masking

****Before applying the mask:**** Every position is allowed to participate in attention. However, different tokens can still receive different attention scores based on their Query-Key similarity.

| Token | The | cat | sat | on | the | mat |
| --- | --- | --- | --- | --- | --- | --- |
| The | 1.0 | 0.8 | 0.6 | 0.4 | 0.5 | 0.3 |
| Cat | 0.8 | 1.0 | 0.9 | 0.4 | 0.5 | 0.2 |
| Sat | 0.6 | 0.9 | 1.0 | 0.8 | 0.7 | 0.6 |

****After applying the mask:**** The model cannot "see" future tokens:

| Token | The | cat | sat | on | the | mat |
| --- | --- | --- | --- | --- | --- | --- |
| The | 1.0 | 0.8 | 0.6 | \-∞ | \-∞ | \-∞ |
| Cat | 0.8 | 1.0 | 0.9 | \-∞ | \-∞ | \-∞ |
| Sat | 0.6 | 0.9 | 1.0 | \-∞ | \-∞ | \-∞ |

## Implementation for Causal Attention

This example uses the input tensor directly to simplify the demonstration. In a complete self-attention layer, separate linear projections are typically used to create Query, Key and Value representations.

### Step 1: Initialize Input Tensor

Create a random input tensor representing token embeddings. This tensor has dimensions (batch\_size, seq\_len, embedding\_dim) where:

- ****batch\_size**** is the number of sequences in the batch.
- ****seq\_len**** is the length of each sequence.
- ****embedding\_dim**** is the dimensionality of the token embeddings (features).
```
import torch

# sequence length and batch size
seq_len = 5
batch_size = 2

# Random input tensor (batch_size, seq_len, embedding_dim)
embedding_dim = 4
x = torch.rand(batch_size, seq_len, embedding_dim)

print("Input Tensor (x):")
print(x)
```
****Output:****

![[Capture.png|Capture]]

### Step 2: Create Self-Attention Mask

Next, we create a self-attention mask that controls how each token can attend to other tokens. In this case, we use a causal mask, which ensures that tokens cannot attend to future positions (i.e., tokens ahead of them in the sequence). This is commonly used in autoregressive models where the model must not look ahead in the sequence.

The mask is an upper triangular matrix (torch.tril) where:

- 1's represent positions that are allowed to attend.
- 0's represent positions that are masked and cannot attend.
```
mask = torch.tril(torch.ones(seq_len, seq_len)).unsqueeze(0).repeat(batch_size, 1, 1)

print("\nSelf-attention Mask (Causal):")
print(mask)
```
****Output:****

![[Capture 1.png|Capture]]

### Step 3: Compute Attention Scores

Now, we compute the attention scores, which represent the similarity between each pair of tokens. This is done by performing a dot product between the input tensor (x) and its transpose. The scores are then scaled by the square root of the embedding dimension (embedding\_dim \*\* 0.5) to stabilize gradients during training.
```
attention_scores = torch.matmul(x, x.transpose(-1, -2)) / (embedding_dim ** 0.5)

print("\nAttention Scores (Before Masking):")
print(attention_scores)
```
****Output:****

![[Capture 2.png|Capture]]

### Step 4: Apply Mask to Attention Scores

In this step, we apply the mask to the attention scores. We use the mask to set the attention scores for masked positions (where the mask is 0) to a very large negative value (-1e9). This ensures that when we apply the softmax in the next step, the masked positions will have an attention weight of zero.
```
attention_scores = attention_scores.masked_fill(mask == 0, -1e9)

print("\nAttention Scores (After Masking):")
print(attention_scores)
```
****Output:****

![[Capture 3.png|Capture]]

### Step 5: Compute Attention Weights

Explanation: Once the mask is applied, we perform a softmax operation on the attention scores to get the attention weights. This operation converts the scores into probabilities, ensuring that the sum of the attention weights for each token equals 1. The softmax is applied along the sequence dimension (dim=-1), so each token's attention distribution over all other tokens is computed.
```
# Attention weights
import torch.nn.functional as F
attention_weights = F.softmax(attention_scores, dim=-1)

print("\nAttention Weights (After Softmax):")
print(attention_weights)
```
****Output:****

![[Capture 4.png|Capture]]

### Step 6: Compute Output of Self-Attention

Finally, we compute the output of the self-attention mechanism by taking a weighted sum of the input tensor (x) based on the attention weights. This is done by performing a matrix multiplication between the attention weights and the input tensor.
```
output = torch.matmul(attention_weights, x)

print("\nOutput Tensor (After Attention):")
print(output)
```
****Output:****

![[Capture 5.png|Capture]]

> You can download the complete source code from [here.](https://media.geeksforgeeks.org/wp-content/uploads/20260908102648718494/How_Do_Self_attention_Masks_Work_.ipynb)

## Example: Padding Mask

> Sequence: The cat slept \[PAD\] \[PAD\]
> 
> Mask: 1 1 1 0 0

The padding mask prevents other tokens from assigning attention to \[PAD\] positions.