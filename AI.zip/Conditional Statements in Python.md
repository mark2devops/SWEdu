---
title: "Conditional Statements in Python"
source: "https://www.geeksforgeeks.org/python/conditional-statements-in-python/"
author:
  - "[[GeeksforGeeks]]"
published: 2024-03-06
created: 2026-09-23
description: "Your All-in-One Learning Portal: GeeksforGeeks is a comprehensive educational platform that empowers learners across domains-spanning computer science and programming, school education, upskilling, commerce, software tools, competitive exams, and more."
tags:
  - "clippings"
---
Conditional statements are used to control the flow of execution in a program based on specific conditions. They allow programs to execute different blocks of code depending on whether a condition evaluates to True or False.

## If Statement

If statement is used to execute a block of code only when a specified condition evaluates to True.

![[1 1.webp|1]]

If Statement
```
age = 20
if age >= 18:
    print("Eligible to vote.")
```
**Output**
```
Eligible to vote.
```

### Short Hand if

Short-hand if is used to write if statements in a single line. It is useful when only one statement needs to be executed.
```
age = 19
if age > 18: print("Eligible to Vote.")
```
**Output**
```
Eligible to Vote.
```

## If else Statement

[If Else](https://www.geeksforgeeks.org/python/python-if-else/) statement is used to execute one block of code when the condition is True and another block when the condition is False.

![[2.webp|2]]

If else Conditional Statement
```
age = 10
if age <= 12:
    print("Travel for free.")
else:
    print("Pay for ticket.")
```
**Output**
```
Travel for free.
```

## If-elif-else Statement

elif statement is used to check multiple conditions in a program. It executes a block of code when its condition evaluates to True after previous conditions evaluate to False.
```
age = 25

if age <= 12:
    print("Child.")
elif age <= 19:
    print("Teenager.")
elif age <= 35:
    print("Young adult.")
else:
    print("Adult.")
```
**Output**
```
Young adult.
```

****Explanation:**** Since age is 25, it skips the first two conditions (age <= 12 and age <= 19) and the third condition (age <= 35) is True, so it prints "Young adult.".

## Nested if-else Statement

[Nested if-else](https://www.geeksforgeeks.org/python/nested-if-statement-in-python/) statement is an if-else statement placed inside another if or else block. It is used to check conditions within another condition.

![[6.webp|6]]

Nested If Else
```
age = 70
is_member = True

if age >= 60:
    if is_member:
        print("30% senior discount!")
    else:
        print("20% senior discount.")
else:
    print("Not eligible for a senior discount.")
```
**Output**
```
30% senior discount!
```

> ****Note:**** We can also use multiple conditions in an if statement to make decisions based on more than one condition. For detailed information on applying multiple conditions, please refer to our article, [Check Multiple conditions in if statement](https://www.geeksforgeeks.org/python/check-multiple-conditions-in-if-statement-python/).

## Conditional Expression (Ternary Operator)

Conditional Expression ([Ternary Operator](https://www.geeksforgeeks.org/python/ternary-operator-in-python/)) is a short way to write an if-else statement in a single line. It is used when choosing between two values based on a condition.
```
age = 20
s = "Adult" if age >= 18 else "Minor"
print(s)
```
**Output**
```
Adult
```

****Explanation:**** If age >= 18 is True, status is assigned "Adult". Otherwise, status is assigned "Minor".

## Match-Case Statement

[Match-Case statement](https://www.geeksforgeeks.org/python/python-match-case-statement/) is used to compare a value against multiple patterns and execute the matching block of code. It is similar to the switch-case statement available in other programming languages.
```
number = 2

match number:
    case 1:
        print("One")
    case 2 | 3:
        print("Two or Three")
    case _:
        print("Other number")
```
****Output****

> Two or Three

Which of the following is the correct syntax for a ternary conditional expression in Python?

- A
	result if condition else result
- B
	if condition then result else result
- C
	result else condition then result
- D
	if condition result else result

Which of the following statements is true about the elif keyword in Python?

- A
	It is short for "else if"
- B
	It is used to declare a variable
- C
	It is only used in loops
- D
	It indicates the end of a function

What is the purpose of the if statement in Python?

- A
	To define a function
- B
	To declare a variable
- C
	To execute a block of code conditionally
- D
	To create a loop

Which of the following operators is used for equality comparison in Python?

- A
	\==
- B
	\=
- C
	\===
- D
	\>

What will be the output of the following code snippet?

- A
	Positive
- B
	Negative
- C
	Zero
- D
	Error

How do you represent the logical AND operator in Python?

- A
	&&
- B
	and
- C
	AND
- D
	&

What is the purpose of the elif statement in Python?

- A
	To handle exceptions
- B
	To create a loop
- C
	To define a function
- D
	To check additional conditions after the initial if statement

What is the output of the following code snippet?

What does the 'else' statement do in a conditional structure?

- A
	It executes a block of code if the previous condition is true.
- B
	It executes a block of code if all conditions are false.
- C
	It defines a new function.
- D
	It creates a loop.

What is the purpose of a ternary operator in Python?

![[sucess-img 17.png|success]]

Quiz Completed Successfully

Score:0/10

Accuracy:0%